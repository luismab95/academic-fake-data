--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg120+1)
-- Dumped by pg_dump version 17.2 (Debian 17.2-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: autoridad_entidad; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.autoridad_entidad (
    id_relacion integer NOT NULL,
    id_autoridad integer NOT NULL,
    id_universidad integer,
    id_facultad integer,
    id_escuela integer
);


ALTER TABLE public.autoridad_entidad OWNER TO "ObGkVgCpKc";

--
-- Name: autoridad_entidad_id_relacion_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.autoridad_entidad_id_relacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.autoridad_entidad_id_relacion_seq OWNER TO "ObGkVgCpKc";

--
-- Name: autoridad_entidad_id_relacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.autoridad_entidad_id_relacion_seq OWNED BY public.autoridad_entidad.id_relacion;


--
-- Name: autoridades; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.autoridades (
    id_autoridad integer NOT NULL,
    cargo character varying(100) NOT NULL,
    nombre character varying(100) NOT NULL,
    apellido character varying(100) NOT NULL,
    correo character varying(100),
    telefono character varying(20),
    foto_url text
);


ALTER TABLE public.autoridades OWNER TO "ObGkVgCpKc";

--
-- Name: autoridades_id_autoridad_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.autoridades_id_autoridad_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.autoridades_id_autoridad_seq OWNER TO "ObGkVgCpKc";

--
-- Name: autoridades_id_autoridad_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.autoridades_id_autoridad_seq OWNED BY public.autoridades.id_autoridad;


--
-- Name: calificaciones; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.calificaciones (
    id_calificacion integer NOT NULL,
    id_inscripcion integer NOT NULL,
    calificacion numeric(5,2) NOT NULL,
    estado character varying(20) DEFAULT 'APROBADO'::character varying,
    CONSTRAINT calificaciones_calificacion_check CHECK (((calificacion >= (0)::numeric) AND (calificacion <= (100)::numeric))),
    CONSTRAINT calificaciones_estado_check CHECK (((estado)::text = ANY ((ARRAY['APROBADO'::character varying, 'REPROBADO'::character varying, 'EN CURSO'::character varying, 'EXONERADO'::character varying])::text[])))
);


ALTER TABLE public.calificaciones OWNER TO "ObGkVgCpKc";

--
-- Name: calificaciones_id_calificacion_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.calificaciones_id_calificacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calificaciones_id_calificacion_seq OWNER TO "ObGkVgCpKc";

--
-- Name: calificaciones_id_calificacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.calificaciones_id_calificacion_seq OWNED BY public.calificaciones.id_calificacion;


--
-- Name: escuelas; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.escuelas (
    id_escuela integer NOT NULL,
    id_facultad integer,
    nombre character varying(100) NOT NULL,
    descripcion text,
    logo_url text,
    semestres integer DEFAULT 4,
    carrera character varying NOT NULL
);


ALTER TABLE public.escuelas OWNER TO "ObGkVgCpKc";

--
-- Name: escuelas_id_escuela_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.escuelas_id_escuela_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.escuelas_id_escuela_seq OWNER TO "ObGkVgCpKc";

--
-- Name: escuelas_id_escuela_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.escuelas_id_escuela_seq OWNED BY public.escuelas.id_escuela;


--
-- Name: estudiantes; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.estudiantes (
    id_estudiante integer NOT NULL,
    nombre character varying(100) NOT NULL,
    apellido character varying(100) NOT NULL,
    matricula character varying(20) NOT NULL,
    correo character varying(100) NOT NULL,
    fecha_nacimiento date,
    direccion character varying(255),
    identificacion character varying NOT NULL,
    CONSTRAINT check_fecha_nacimiento CHECK ((fecha_nacimiento < CURRENT_DATE))
);


ALTER TABLE public.estudiantes OWNER TO "ObGkVgCpKc";

--
-- Name: estudiantes_id_estudiante_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.estudiantes_id_estudiante_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estudiantes_id_estudiante_seq OWNER TO "ObGkVgCpKc";

--
-- Name: estudiantes_id_estudiante_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.estudiantes_id_estudiante_seq OWNED BY public.estudiantes.id_estudiante;


--
-- Name: facultades; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.facultades (
    id_facultad integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text,
    logo_url text,
    id_universidad integer
);


ALTER TABLE public.facultades OWNER TO "ObGkVgCpKc";

--
-- Name: facultades_id_facultad_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.facultades_id_facultad_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.facultades_id_facultad_seq OWNER TO "ObGkVgCpKc";

--
-- Name: facultades_id_facultad_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.facultades_id_facultad_seq OWNED BY public.facultades.id_facultad;


--
-- Name: inscripciones; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.inscripciones (
    id_inscripcion integer NOT NULL,
    id_estudiante integer NOT NULL,
    id_materia integer NOT NULL,
    id_semestre integer NOT NULL
);


ALTER TABLE public.inscripciones OWNER TO "ObGkVgCpKc";

--
-- Name: inscripciones_id_inscripcion_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.inscripciones_id_inscripcion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inscripciones_id_inscripcion_seq OWNER TO "ObGkVgCpKc";

--
-- Name: inscripciones_id_inscripcion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.inscripciones_id_inscripcion_seq OWNED BY public.inscripciones.id_inscripcion;


--
-- Name: materias; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.materias (
    id_materia integer NOT NULL,
    id_escuela integer,
    nombre character varying(100) NOT NULL,
    descripcion text,
    creditos integer,
    CONSTRAINT materias_creditos_check CHECK ((creditos > 0))
);


ALTER TABLE public.materias OWNER TO "ObGkVgCpKc";

--
-- Name: materias_id_materia_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.materias_id_materia_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.materias_id_materia_seq OWNER TO "ObGkVgCpKc";

--
-- Name: materias_id_materia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.materias_id_materia_seq OWNED BY public.materias.id_materia;


--
-- Name: semestres; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.semestres (
    id_semestre integer NOT NULL,
    semestre character varying(10) NOT NULL,
    anio integer NOT NULL,
    fecha_inicio date NOT NULL,
    fecha_fin date NOT NULL,
    activo boolean DEFAULT true,
    CONSTRAINT semestres_anio_check CHECK ((anio >= 2000))
);


ALTER TABLE public.semestres OWNER TO "ObGkVgCpKc";

--
-- Name: semestres_id_semestre_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.semestres_id_semestre_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.semestres_id_semestre_seq OWNER TO "ObGkVgCpKc";

--
-- Name: semestres_id_semestre_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.semestres_id_semestre_seq OWNED BY public.semestres.id_semestre;


--
-- Name: universidad; Type: TABLE; Schema: public; Owner: ObGkVgCpKc
--

CREATE TABLE public.universidad (
    id_universidad integer NOT NULL,
    nombre character varying(255) NOT NULL,
    direccion character varying(255),
    telefono character varying(20),
    correo character varying(100),
    anio_fundacion integer,
    logo_url text
);


ALTER TABLE public.universidad OWNER TO "ObGkVgCpKc";

--
-- Name: universidad_id_universidad_seq; Type: SEQUENCE; Schema: public; Owner: ObGkVgCpKc
--

CREATE SEQUENCE public.universidad_id_universidad_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.universidad_id_universidad_seq OWNER TO "ObGkVgCpKc";

--
-- Name: universidad_id_universidad_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ObGkVgCpKc
--

ALTER SEQUENCE public.universidad_id_universidad_seq OWNED BY public.universidad.id_universidad;


--
-- Name: autoridad_entidad id_relacion; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.autoridad_entidad ALTER COLUMN id_relacion SET DEFAULT nextval('public.autoridad_entidad_id_relacion_seq'::regclass);


--
-- Name: autoridades id_autoridad; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.autoridades ALTER COLUMN id_autoridad SET DEFAULT nextval('public.autoridades_id_autoridad_seq'::regclass);


--
-- Name: calificaciones id_calificacion; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.calificaciones ALTER COLUMN id_calificacion SET DEFAULT nextval('public.calificaciones_id_calificacion_seq'::regclass);


--
-- Name: escuelas id_escuela; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.escuelas ALTER COLUMN id_escuela SET DEFAULT nextval('public.escuelas_id_escuela_seq'::regclass);


--
-- Name: estudiantes id_estudiante; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.estudiantes ALTER COLUMN id_estudiante SET DEFAULT nextval('public.estudiantes_id_estudiante_seq'::regclass);


--
-- Name: facultades id_facultad; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.facultades ALTER COLUMN id_facultad SET DEFAULT nextval('public.facultades_id_facultad_seq'::regclass);


--
-- Name: inscripciones id_inscripcion; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.inscripciones ALTER COLUMN id_inscripcion SET DEFAULT nextval('public.inscripciones_id_inscripcion_seq'::regclass);


--
-- Name: materias id_materia; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.materias ALTER COLUMN id_materia SET DEFAULT nextval('public.materias_id_materia_seq'::regclass);


--
-- Name: semestres id_semestre; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.semestres ALTER COLUMN id_semestre SET DEFAULT nextval('public.semestres_id_semestre_seq'::regclass);


--
-- Name: universidad id_universidad; Type: DEFAULT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.universidad ALTER COLUMN id_universidad SET DEFAULT nextval('public.universidad_id_universidad_seq'::regclass);


--
-- Data for Name: autoridad_entidad; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.autoridad_entidad (id_relacion, id_autoridad, id_universidad, id_facultad, id_escuela) FROM stdin;
1	1	1	\N	1
2	2	1	\N	1
3	3	1	\N	2
4	4	1	\N	2
5	5	1	\N	3
6	6	1	\N	3
7	7	1	\N	4
8	8	1	\N	4
9	9	1	\N	5
10	10	1	\N	5
11	11	1	\N	6
12	12	1	\N	6
13	13	1	\N	7
14	14	1	\N	7
15	15	1	\N	8
16	16	1	\N	8
17	17	1	\N	9
18	18	1	\N	9
19	19	1	\N	10
20	20	1	\N	10
21	21	1	\N	11
22	22	1	\N	11
23	23	1	\N	12
24	24	1	\N	12
25	25	1	\N	13
26	26	1	\N	13
27	27	1	\N	14
28	28	1	\N	14
29	29	1	\N	15
30	30	1	\N	15
31	31	1	\N	16
32	32	1	\N	16
33	33	1	\N	17
34	34	1	\N	17
35	35	1	\N	18
36	36	1	\N	18
37	37	1	\N	19
38	38	1	\N	19
39	39	1	\N	20
40	40	1	\N	20
41	41	1	\N	21
42	42	1	\N	21
43	43	1	\N	22
44	44	1	\N	22
45	45	1	\N	23
46	46	1	\N	23
47	47	1	\N	24
48	48	1	\N	24
49	49	1	\N	25
50	50	1	\N	25
51	51	1	\N	26
52	52	1	\N	26
53	53	1	\N	27
54	54	1	\N	27
55	55	1	\N	28
56	56	1	\N	28
57	57	1	\N	29
58	58	1	\N	29
59	59	1	\N	30
60	60	1	\N	30
61	61	1	1	\N
62	62	1	2	\N
63	63	1	3	\N
64	64	1	4	\N
65	65	1	5	\N
66	66	1	1	\N
67	67	1	2	\N
68	68	1	3	\N
69	69	1	4	\N
70	70	1	5	\N
71	71	1	1	\N
72	72	1	2	\N
73	73	1	3	\N
74	74	1	4	\N
75	75	1	5	\N
76	76	1	6	\N
77	77	1	7	\N
78	78	1	8	\N
79	79	1	9	\N
80	80	1	10	\N
81	81	1	6	\N
82	82	1	7	\N
83	83	1	8	\N
84	84	1	9	\N
85	85	1	10	\N
86	86	1	6	\N
87	87	1	7	\N
88	88	1	8	\N
89	89	1	9	\N
90	90	1	10	\N
91	91	1	\N	\N
92	92	1	\N	\N
93	93	1	\N	\N
\.


--
-- Data for Name: autoridades; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.autoridades (id_autoridad, cargo, nombre, apellido, correo, telefono, foto_url) FROM stdin;
1	Director	Carlos	Gutiérrez	c.gutierrez@utf.edu	+1 555-1010	https://www.ejemplo.com/fotos/carlos_gutierrez.png
2	Secretario Académico	María	López	m.lopez@utf.edu	+1 555-1011	https://www.ejemplo.com/fotos/maria_lopez.png
3	Director	Javier	Martínez	j.martinez@utf.edu	+1 555-1020	https://www.ejemplo.com/fotos/javier_martinez.png
4	Secretario Académico	Lucía	Fernández	l.fernandez@utf.edu	+1 555-1021	https://www.ejemplo.com/fotos/lucia_fernandez.png
5	Director	Raúl	Torres	r.torres@utf.edu	+1 555-1030	https://www.ejemplo.com/fotos/raul_torres.png
6	Secretario Académico	Elena	Ramírez	e.ramirez@utf.edu	+1 555-1031	https://www.ejemplo.com/fotos/elena_ramirez.png
7	Director	Federico	Sánchez	f.sanchez@utf.edu	+1 555-1040	https://www.ejemplo.com/fotos/federico_sanchez.png
8	Secretario Académico	Claudia	Morales	c.morales@utf.edu	+1 555-1041	https://www.ejemplo.com/fotos/claudia_morales.png
9	Director	Andrés	Vega	a.vega@utf.edu	+1 555-1050	https://www.ejemplo.com/fotos/andres_vega.png
10	Secretario Académico	Rosa	Gómez	r.gomez@utf.edu	+1 555-1051	https://www.ejemplo.com/fotos/rosa_gomez.png
11	Director	Manuel	Herrera	m.herrera@utf.edu	+1 555-1060	https://www.ejemplo.com/fotos/manuel_herrera.png
12	Secretario Académico	Patricia	Navarro	p.navarro@utf.edu	+1 555-1061	https://www.ejemplo.com/fotos/patricia_navarro.png
13	Director	Sergio	Mendoza	s.mendoza@utf.edu	+1 555-1070	https://www.ejemplo.com/fotos/sergio_mendoza.png
14	Secretario Académico	Gabriela	Pérez	g.perez@utf.edu	+1 555-1071	https://www.ejemplo.com/fotos/gabriela_perez.png
15	Director	Héctor	Silva	h.silva@utf.edu	+1 555-1080	https://www.ejemplo.com/fotos/hector_silva.png
16	Secretario Académico	Laura	Rojas	l.rojas@utf.edu	+1 555-1081	https://www.ejemplo.com/fotos/laura_rojas.png
17	Director	Ricardo	Castillo	r.castillo@utf.edu	+1 555-1090	https://www.ejemplo.com/fotos/ricardo_castillo.png
18	Secretario Académico	Verónica	Suárez	v.suarez@utf.edu	+1 555-1091	https://www.ejemplo.com/fotos/veronica_suarez.png
19	Director	Fernando	Ortega	f.ortega@utf.edu	+1 555-1100	https://www.ejemplo.com/fotos/fernando_ortega.png
20	Secretario Académico	Silvia	Maldonado	s.maldonado@utf.edu	+1 555-1101	https://www.ejemplo.com/fotos/silvia_maldonado.png
21	Director	Joaquín	Alonso	j.alonso@utf.edu	+1 555-1110	https://www.ejemplo.com/fotos/joaquin_alonso.png
22	Secretario Académico	Natalia	Blanco	n.blanco@utf.edu	+1 555-1111	https://www.ejemplo.com/fotos/natalia_blanco.png
23	Director	Mauricio	Reyes	m.reyes@utf.edu	+1 555-1120	https://www.ejemplo.com/fotos/mauricio_reyes.png
24	Secretario Académico	Beatriz	Cruz	b.cruz@utf.edu	+1 555-1121	https://www.ejemplo.com/fotos/beatriz_cruz.png
25	Director	Eduardo	Moreno	e.moreno@utf.edu	+1 555-1130	https://www.ejemplo.com/fotos/eduardo_moreno.png
26	Secretario Académico	Luisa	Torres	l.torres@utf.edu	+1 555-1131	https://www.ejemplo.com/fotos/luisa_torres.png
27	Director	Álvaro	Martín	a.martin@utf.edu	+1 555-1140	https://www.ejemplo.com/fotos/alvaro_martin.png
28	Secretario Académico	Sara	Vázquez	s.vazquez@utf.edu	+1 555-1141	https://www.ejemplo.com/fotos/sara_vazquez.png
29	Director	Joaquín	Ruiz	j.ruiz@utf.edu	+1 555-1150	https://www.ejemplo.com/fotos/joaquin_ruiz.png
30	Secretario Académico	Patricia	García	p.garcia@utf.edu	+1 555-1151	https://www.ejemplo.com/fotos/patricia_garcia.png
31	Director	Martín	López	m.lopez@utf.edu	+1 555-1160	https://www.ejemplo.com/fotos/martin_lopez.png
32	Secretario Académico	Helena	Jiménez	h.jimenez@utf.edu	+1 555-1161	https://www.ejemplo.com/fotos/helena_jimenez.png
33	Director	Iván	Salazar	i.salazar@utf.edu	+1 555-1170	https://www.ejemplo.com/fotos/ivan_salazar.png
34	Secretario Académico	Ana	Cordero	a.cordero@utf.edu	+1 555-1171	https://www.ejemplo.com/fotos/ana_cordero.png
35	Director	Eduardo	Ramírez	e.ramirez@utf.edu	+1 555-1180	https://www.ejemplo.com/fotos/eduardo_ramirez.png
36	Secretario Académico	María	Pérez	m.perez@utf.edu	+1 555-1181	https://www.ejemplo.com/fotos/maria_perez.png
37	Director	Antonio	García	a.garcia@utf.edu	+1 555-1190	https://www.ejemplo.com/fotos/antonio_garcia.png
38	Secretario Académico	Carolina	Alvarez	c.alvarez@utf.edu	+1 555-1191	https://www.ejemplo.com/fotos/carolina_alvarez.png
39	Director	Ricardo	González	r.gonzalez@utf.edu	+1 555-1200	https://www.ejemplo.com/fotos/ricardo_gonzalez.png
40	Secretario Académico	José	Martínez	j.martinez@utf.edu	+1 555-1201	https://www.ejemplo.com/fotos/jose_martinez.png
41	Director	Juan	Pérez	j.perez@utf.edu	+1 555-1210	https://www.ejemplo.com/fotos/juan_perez.png
42	Secretario Académico	Laura	González	l.gonzalez@utf.edu	+1 555-1211	https://www.ejemplo.com/fotos/laura_gonzalez.png
43	Director	Tomás	Vega	t.vega@utf.edu	+1 555-1220	https://www.ejemplo.com/fotos/tomas_vega.png
44	Secretario Académico	Lorena	Fuentes	l.fuentes@utf.edu	+1 555-1221	https://www.ejemplo.com/fotos/lorena_fuentes.png
45	Director	Samuel	Jiménez	s.jimenez@utf.edu	+1 555-1230	https://www.ejemplo.com/fotos/samuel_jimenez.png
46	Secretario Académico	Patricia	Mendoza	p.mendoza@utf.edu	+1 555-1231	https://www.ejemplo.com/fotos/patricia_mendoza.png
47	Director	Luis	Herrera	l.herrera@utf.edu	+1 555-1240	https://www.ejemplo.com/fotos/luis_herrera.png
48	Secretario Académico	Estela	Vega	e.vega@utf.edu	+1 555-1241	https://www.ejemplo.com/fotos/estela_vega.png
49	Director	Carlos	Serrano	c.serrano@utf.edu	+1 555-1250	https://www.ejemplo.com/fotos/carlos_serrano.png
50	Secretario Académico	Isabel	Luna	i.luna@utf.edu	+1 555-1251	https://www.ejemplo.com/fotos/isabel_luna.png
51	Director	Felipe	Ramírez	f.ramirez@utf.edu	+1 555-1260	https://www.ejemplo.com/fotos/felipe_ramirez.png
52	Secretario Académico	Patricia	Moreno	p.moreno@utf.edu	+1 555-1261	https://www.ejemplo.com/fotos/patricia_moreno.png
53	Director	Fernando	Hernández	f.hernandez@utf.edu	+1 555-1270	https://www.ejemplo.com/fotos/fernando_hernandez.png
54	Secretario Académico	Carmen	Torres	c.torres@utf.edu	+1 555-1271	https://www.ejemplo.com/fotos/carmen_torres.png
55	Director	Víctor	Jiménez	v.jimenez@utf.edu	+1 555-1280	https://www.ejemplo.com/fotos/victor_jimenez.png
56	Secretario Académico	Luisa	Pérez	l.perez@utf.edu	+1 555-1281	https://www.ejemplo.com/fotos/luisa_perez.png
57	Director	Eugenio	Alvarado	e.alvarado@utf.edu	+1 555-1290	https://www.ejemplo.com/fotos/eugenio_alvarado.png
58	Secretario Académico	María	Rivas	m.rivas@utf.edu	+1 555-1291	https://www.ejemplo.com/fotos/maria_rivas.png
59	Director	Héctor	González	h.gonzalez@utf.edu	+1 555-1300	https://www.ejemplo.com/fotos/hector_gonzalez.png
60	Secretario Académico	Ana	Méndez	a.mendez@utf.edu	+1 555-1301	https://www.ejemplo.com/fotos/ana_mendez.png
62	Secretario Académico	Verónica	Santos	v.santos@utf.edu	+1 555-1311	https://www.ejemplo.com/fotos/veronica_santos.png
64	Secretario Académico	Luis	Molina	l.molina@utf.edu	+1 555-1321	https://www.ejemplo.com/fotos/luis_molina.png
66	Secretario Académico	Sandra	García	s.garcia@utf.edu	+1 555-1331	https://www.ejemplo.com/fotos/sandra_garcia.png
68	Secretario Académico	Paula	Fernández	p.fernandez@utf.edu	+1 555-1341	https://www.ejemplo.com/fotos/paula_fernandez.png
70	Secretario Académico	Julia	Cordero	j.cordero@utf.edu	+1 555-1351	https://www.ejemplo.com/fotos/julia_cordero.png
61	Decano	Julio	Álvarez	j.alvarez@utf.edu	+1 555-1310	https://www.ejemplo.com/fotos/julio_alvarez.png
63	Decano	Carlos	Vega	c.vega@utf.edu	+1 555-1320	https://www.ejemplo.com/fotos/carlos_vega.png
65	Decano	Miguel	Martínez	m.martinez@utf.edu	+1 555-1330	https://www.ejemplo.com/fotos/miguel_martinez.png
67	Decano	Ricardo	Jiménez	r.jimenez@utf.edu	+1 555-1340	https://www.ejemplo.com/fotos/ricardo_jimenez.png
69	Decano	Luis	Ramírez	l.ramirez@utf.edu	+1 555-1350	https://www.ejemplo.com/fotos/luis_ramirez.png
71	Vicedecano	Carlos	Gómez	c.gomez@utf.edu	+1 555-1360	https://www.ejemplo.com/fotos/carlos_gomez.png
72	Vicedecano	Mariana	Torres	m.torres@utf.edu	+1 555-1370	https://www.ejemplo.com/fotos/mariana_torres.png
73	Vicedecano	Esteban	Martínez	e.martinez@utf.edu	+1 555-1380	https://www.ejemplo.com/fotos/esteban_martinez.png
74	Vicedecano	Roberto	López	r.lopez@utf.edu	+1 555-1390	https://www.ejemplo.com/fotos/roberto_lopez.png
75	Vicedecano	Isabel	Ruiz	i.ruiz@utf.edu	+1 555-1400	https://www.ejemplo.com/fotos/isabel_ruiz.png
76	Vicedecano	Ana	Pérez	a.perez@utf.edu	+1 555-1410	https://www.ejemplo.com/fotos/ana_perez.png
77	Vicedecano	José	Hernández	j.hernandez@utf.edu	+1 555-1420	https://www.ejemplo.com/fotos/jose_hernandez.png
78	Vicedecano	Miguel	García	m.garcia@utf.edu	+1 555-1430	https://www.ejemplo.com/fotos/miguel_garcia.png
79	Vicedecano	Raquel	Ramírez	r.ramirez@utf.edu	+1 555-1440	https://www.ejemplo.com/fotos/raquel_ramirez.png
80	Vicedecano	Pablo	Jiménez	p.jimenez@utf.edu	+1 555-1450	https://www.ejemplo.com/fotos/pablo_jimenez.png
81	Decano	Luis	Figueroa	l.figueroa@utf.edu	+1 555-1460	https://www.ejemplo.com/fotos/luis_figueroa.png
82	Decano	Carlos	Martínez	c.martinez@utf.edu	+1 555-1470	https://www.ejemplo.com/fotos/carlos_martinez.png
83	Decano	Sofía	Gómez	s.gomez@utf.edu	+1 555-1480	https://www.ejemplo.com/fotos/sofia_gomez.png
84	Decano	Antonio	Rodríguez	a.rodriguez@utf.edu	+1 555-1490	https://www.ejemplo.com/fotos/antonio_rodriguez.png
85	Decano	Beatriz	López	b.lopez@utf.edu	+1 555-1500	https://www.ejemplo.com/fotos/beatriz_lopez.png
86	Secretario Académico	Laura	Martínez	l.martinez@utf.edu	+1 555-1510	https://www.ejemplo.com/fotos/laura_martinez.png
87	Secretario Académico	José	Fernández	j.fernandez@utf.edu	+1 555-1520	https://www.ejemplo.com/fotos/jose_fernandez.png
88	Secretario Académico	Carmen	Sánchez	c.sanchez@utf.edu	+1 555-1530	https://www.ejemplo.com/fotos/carmen_sanchez.png
89	Secretario Académico	Martín	González	m.gonzalez@utf.edu	+1 555-1540	https://www.ejemplo.com/fotos/martin_gonzalez.png
90	Secretario Académico	Raquel	Jiménez	r.jimenez@utf.edu	+1 555-1550	https://www.ejemplo.com/fotos/raquel_jimenez.png
91	Rector	Andrés	Ramírez	a.ramirez@utf.edu	+1 555-1560	https://www.ejemplo.com/fotos/andres_ramirez.png
92	Vicerrector	Marta	Cruz	m.cruz@utf.edu	+1 555-1570	https://www.ejemplo.com/fotos/marta_cruz.png
93	Secretario General	Jorge	Morales	j.morales@utf.edu	+1 555-1580	https://www.ejemplo.com/fotos/jorge_morales.png
\.


--
-- Data for Name: calificaciones; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.calificaciones (id_calificacion, id_inscripcion, calificacion, estado) FROM stdin;
1	1	9.61	APROBADO
2	2	7.46	APROBADO
3	3	8.72	APROBADO
4	4	7.82	APROBADO
5	5	7.65	APROBADO
6	6	9.76	APROBADO
7	7	7.27	APROBADO
8	8	7.47	APROBADO
9	9	7.35	APROBADO
10	10	7.14	APROBADO
11	11	9.50	APROBADO
12	12	9.41	APROBADO
13	13	9.91	APROBADO
14	14	8.07	APROBADO
15	15	7.89	APROBADO
16	16	8.29	APROBADO
17	17	7.96	APROBADO
18	18	8.92	APROBADO
19	19	9.70	APROBADO
20	20	8.21	APROBADO
21	21	8.50	APROBADO
22	22	8.17	APROBADO
23	23	8.61	APROBADO
24	24	8.27	APROBADO
25	25	9.09	APROBADO
26	26	10.00	APROBADO
27	27	9.45	APROBADO
28	28	7.08	APROBADO
29	29	7.13	APROBADO
30	30	8.24	APROBADO
31	31	9.67	APROBADO
32	32	9.19	APROBADO
33	33	9.93	APROBADO
34	34	9.03	APROBADO
35	35	9.08	APROBADO
36	36	7.47	APROBADO
37	37	7.35	APROBADO
38	38	8.86	APROBADO
39	39	8.25	APROBADO
40	40	8.74	APROBADO
41	41	8.29	APROBADO
42	42	8.17	APROBADO
43	43	8.80	APROBADO
44	44	8.79	APROBADO
45	45	8.24	APROBADO
46	46	8.23	APROBADO
47	47	8.31	APROBADO
48	48	7.43	APROBADO
49	49	8.33	APROBADO
50	50	9.16	APROBADO
51	51	9.62	APROBADO
52	52	9.82	APROBADO
53	53	9.94	APROBADO
54	54	7.45	APROBADO
55	55	7.33	APROBADO
56	56	9.73	APROBADO
57	57	7.17	APROBADO
58	58	8.03	APROBADO
59	59	8.98	APROBADO
60	60	7.90	APROBADO
61	61	9.37	APROBADO
62	62	7.75	APROBADO
63	63	8.83	APROBADO
64	64	7.33	APROBADO
65	65	8.03	APROBADO
66	66	7.96	APROBADO
67	67	9.78	APROBADO
68	68	8.66	APROBADO
69	69	8.40	APROBADO
70	70	9.86	APROBADO
71	71	8.77	APROBADO
72	72	7.14	APROBADO
73	73	8.84	APROBADO
74	74	9.38	APROBADO
75	75	7.26	APROBADO
76	76	9.24	APROBADO
77	77	7.99	APROBADO
78	78	7.90	APROBADO
79	79	8.17	APROBADO
80	80	9.31	APROBADO
81	81	7.64	APROBADO
82	82	7.66	APROBADO
83	83	9.80	APROBADO
84	84	7.98	APROBADO
85	85	8.90	APROBADO
86	86	7.83	APROBADO
87	87	9.85	APROBADO
88	88	9.16	APROBADO
89	89	9.03	APROBADO
90	90	7.26	APROBADO
91	91	9.28	APROBADO
92	92	9.19	APROBADO
93	93	7.58	APROBADO
94	94	9.91	APROBADO
95	95	7.18	APROBADO
96	96	8.72	APROBADO
97	97	8.93	APROBADO
98	98	8.80	APROBADO
99	99	7.27	APROBADO
100	100	9.93	APROBADO
101	101	8.29	APROBADO
102	102	9.30	APROBADO
103	103	9.83	APROBADO
104	104	9.56	APROBADO
105	105	9.81	APROBADO
106	106	8.39	APROBADO
107	107	9.01	APROBADO
108	108	7.47	APROBADO
109	109	8.26	APROBADO
110	110	8.17	APROBADO
111	111	7.73	APROBADO
112	112	7.02	APROBADO
113	113	8.84	APROBADO
114	114	7.93	APROBADO
115	115	9.36	APROBADO
116	116	7.68	APROBADO
117	117	8.03	APROBADO
118	118	9.31	APROBADO
119	119	8.05	APROBADO
120	120	7.13	APROBADO
121	121	9.11	APROBADO
122	122	9.56	APROBADO
123	123	8.86	APROBADO
124	124	9.10	APROBADO
125	125	9.77	APROBADO
126	126	8.46	APROBADO
127	127	9.26	APROBADO
128	128	9.21	APROBADO
129	129	7.00	APROBADO
130	130	7.63	APROBADO
131	131	8.13	APROBADO
132	132	7.43	APROBADO
133	133	7.66	APROBADO
134	134	9.25	APROBADO
135	135	9.90	APROBADO
136	136	8.67	APROBADO
137	137	8.26	APROBADO
138	138	8.68	APROBADO
139	139	9.18	APROBADO
140	140	8.71	APROBADO
141	141	9.52	APROBADO
142	142	8.82	APROBADO
143	143	8.67	APROBADO
144	144	7.73	APROBADO
145	145	9.80	APROBADO
146	146	9.61	APROBADO
147	147	8.22	APROBADO
148	148	8.69	APROBADO
149	149	8.88	APROBADO
150	150	8.12	APROBADO
151	151	8.00	APROBADO
152	152	7.23	APROBADO
153	153	7.81	APROBADO
154	154	7.33	APROBADO
155	155	8.88	APROBADO
156	156	7.20	APROBADO
157	157	7.40	APROBADO
158	158	9.74	APROBADO
159	159	7.81	APROBADO
160	160	8.94	APROBADO
161	161	8.84	APROBADO
162	162	7.59	APROBADO
163	163	8.96	APROBADO
164	164	8.03	APROBADO
165	165	7.88	APROBADO
166	166	7.16	APROBADO
167	167	8.30	APROBADO
168	168	9.93	APROBADO
169	169	9.12	APROBADO
170	170	7.95	APROBADO
171	171	8.26	APROBADO
172	172	8.64	APROBADO
173	173	8.29	APROBADO
174	174	7.95	APROBADO
175	175	8.37	APROBADO
176	176	9.70	APROBADO
177	177	9.26	APROBADO
178	178	7.00	APROBADO
179	179	9.06	APROBADO
180	180	7.42	APROBADO
181	181	8.32	APROBADO
182	182	7.69	APROBADO
183	183	8.64	APROBADO
184	184	9.56	APROBADO
185	185	8.78	APROBADO
186	186	9.32	APROBADO
187	187	8.09	APROBADO
188	188	8.96	APROBADO
189	189	8.77	APROBADO
190	190	8.71	APROBADO
191	191	7.70	APROBADO
192	192	8.46	APROBADO
193	193	8.22	APROBADO
194	194	9.15	APROBADO
195	195	8.95	APROBADO
196	196	7.48	APROBADO
197	197	7.87	APROBADO
198	198	7.54	APROBADO
199	199	7.06	APROBADO
200	200	8.24	APROBADO
201	201	7.11	APROBADO
202	202	9.92	APROBADO
203	203	7.52	APROBADO
204	204	7.79	APROBADO
205	205	7.66	APROBADO
206	206	8.11	APROBADO
207	207	7.08	APROBADO
208	208	7.02	APROBADO
209	209	9.25	APROBADO
210	210	9.52	APROBADO
211	211	9.69	APROBADO
212	212	7.47	APROBADO
213	213	8.14	APROBADO
214	214	7.46	APROBADO
215	215	9.20	APROBADO
216	216	9.30	APROBADO
217	217	8.18	APROBADO
218	218	7.71	APROBADO
219	219	9.41	APROBADO
220	220	8.89	APROBADO
221	221	7.68	APROBADO
222	222	7.71	APROBADO
223	223	9.18	APROBADO
224	224	7.75	APROBADO
225	225	7.68	APROBADO
226	226	7.18	APROBADO
227	227	7.67	APROBADO
228	228	8.12	APROBADO
229	229	9.38	APROBADO
230	230	8.05	APROBADO
231	231	7.48	APROBADO
232	232	7.69	APROBADO
233	233	9.82	APROBADO
234	234	7.35	APROBADO
235	235	7.62	APROBADO
236	236	7.95	APROBADO
237	237	9.95	APROBADO
238	238	7.15	APROBADO
239	239	7.81	APROBADO
240	240	7.67	APROBADO
241	241	8.50	APROBADO
242	242	8.93	APROBADO
243	243	7.08	APROBADO
244	244	8.17	APROBADO
245	245	9.57	APROBADO
246	246	8.56	APROBADO
247	247	8.31	APROBADO
248	248	8.34	APROBADO
249	249	8.13	APROBADO
250	250	9.87	APROBADO
251	251	8.29	APROBADO
252	252	8.00	APROBADO
253	253	8.22	APROBADO
254	254	9.39	APROBADO
255	255	8.21	APROBADO
256	256	7.76	APROBADO
257	257	7.08	APROBADO
258	258	7.94	APROBADO
259	259	7.91	APROBADO
260	260	9.90	APROBADO
261	261	9.58	APROBADO
262	262	9.73	APROBADO
263	263	8.76	APROBADO
264	264	7.60	APROBADO
265	265	9.53	APROBADO
266	266	9.44	APROBADO
267	267	9.63	APROBADO
268	268	7.84	APROBADO
269	269	7.43	APROBADO
270	270	8.90	APROBADO
271	271	9.13	APROBADO
272	272	9.23	APROBADO
273	273	9.20	APROBADO
274	274	8.72	APROBADO
275	275	9.98	APROBADO
276	276	9.77	APROBADO
277	277	8.16	APROBADO
278	278	7.61	APROBADO
279	279	8.12	APROBADO
280	280	8.90	APROBADO
281	281	9.78	APROBADO
282	282	9.06	APROBADO
283	283	8.78	APROBADO
284	284	8.04	APROBADO
285	285	9.62	APROBADO
286	286	7.43	APROBADO
287	287	7.25	APROBADO
288	288	9.52	APROBADO
289	289	9.03	APROBADO
290	290	8.41	APROBADO
291	291	7.23	APROBADO
292	292	9.39	APROBADO
293	293	7.77	APROBADO
294	294	8.73	APROBADO
295	295	8.08	APROBADO
296	296	7.55	APROBADO
297	297	9.61	APROBADO
298	298	9.32	APROBADO
299	299	8.74	APROBADO
300	300	7.00	APROBADO
301	301	7.65	APROBADO
302	302	9.97	APROBADO
303	303	9.15	APROBADO
304	304	7.06	APROBADO
305	305	8.37	APROBADO
306	306	9.12	APROBADO
307	307	8.38	APROBADO
308	308	9.97	APROBADO
309	309	7.94	APROBADO
310	310	7.07	APROBADO
311	311	9.63	APROBADO
312	312	7.03	APROBADO
313	313	8.42	APROBADO
314	314	9.36	APROBADO
315	315	7.21	APROBADO
316	316	8.91	APROBADO
317	317	8.01	APROBADO
318	318	9.09	APROBADO
319	319	7.84	APROBADO
320	320	8.88	APROBADO
321	321	7.01	APROBADO
322	322	9.97	APROBADO
323	323	8.31	APROBADO
324	324	7.47	APROBADO
325	325	7.18	APROBADO
326	326	9.57	APROBADO
327	327	8.21	APROBADO
328	328	9.44	APROBADO
329	329	8.71	APROBADO
330	330	9.80	APROBADO
331	331	7.19	APROBADO
332	332	8.29	APROBADO
333	333	8.45	APROBADO
334	334	8.89	APROBADO
335	335	9.04	APROBADO
336	336	7.15	APROBADO
337	337	8.69	APROBADO
338	338	7.65	APROBADO
339	339	8.20	APROBADO
340	340	9.10	APROBADO
341	341	7.48	APROBADO
342	342	8.28	APROBADO
343	343	8.77	APROBADO
344	344	7.91	APROBADO
345	345	7.92	APROBADO
346	346	9.39	APROBADO
347	347	8.61	APROBADO
348	348	8.02	APROBADO
349	349	7.46	APROBADO
350	350	9.77	APROBADO
351	351	7.19	APROBADO
352	352	7.84	APROBADO
353	353	7.54	APROBADO
354	354	9.62	APROBADO
355	355	8.47	APROBADO
356	356	8.26	APROBADO
357	357	8.79	APROBADO
358	358	8.32	APROBADO
359	359	9.81	APROBADO
360	360	9.97	APROBADO
361	361	7.36	APROBADO
362	362	8.00	APROBADO
363	363	7.72	APROBADO
364	364	7.93	APROBADO
365	365	7.53	APROBADO
366	366	7.04	APROBADO
367	367	7.57	APROBADO
368	368	9.32	APROBADO
369	369	8.62	APROBADO
370	370	7.82	APROBADO
371	371	8.71	APROBADO
372	372	8.07	APROBADO
373	373	9.78	APROBADO
374	374	9.14	APROBADO
375	375	9.24	APROBADO
376	376	7.27	APROBADO
377	377	9.95	APROBADO
378	378	7.21	APROBADO
379	379	9.40	APROBADO
380	380	7.51	APROBADO
381	381	9.97	APROBADO
382	382	8.83	APROBADO
383	383	7.75	APROBADO
384	384	9.04	APROBADO
385	385	8.27	APROBADO
386	386	8.29	APROBADO
387	387	9.92	APROBADO
388	388	9.28	APROBADO
389	389	8.64	APROBADO
390	390	8.84	APROBADO
391	391	8.53	APROBADO
392	392	8.30	APROBADO
393	393	7.10	APROBADO
394	394	8.05	APROBADO
395	395	7.62	APROBADO
396	396	9.63	APROBADO
397	397	7.87	APROBADO
398	398	9.17	APROBADO
399	399	7.09	APROBADO
400	400	7.42	APROBADO
401	401	7.44	APROBADO
402	402	7.37	APROBADO
403	403	9.94	APROBADO
404	404	9.44	APROBADO
405	405	7.95	APROBADO
406	406	7.96	APROBADO
407	407	8.86	APROBADO
408	408	9.00	APROBADO
409	409	7.94	APROBADO
410	410	7.44	APROBADO
411	411	7.04	APROBADO
412	412	7.67	APROBADO
413	413	8.58	APROBADO
414	414	8.29	APROBADO
415	415	8.45	APROBADO
416	416	9.38	APROBADO
417	417	8.59	APROBADO
418	418	9.37	APROBADO
419	419	7.78	APROBADO
420	420	8.51	APROBADO
421	421	9.93	APROBADO
422	422	9.05	APROBADO
423	423	7.41	APROBADO
424	424	7.11	APROBADO
425	425	8.47	APROBADO
426	426	9.46	APROBADO
427	427	7.75	APROBADO
428	428	8.20	APROBADO
429	429	9.33	APROBADO
430	430	9.57	APROBADO
431	431	8.32	APROBADO
432	432	9.27	APROBADO
433	433	7.25	APROBADO
434	434	7.06	APROBADO
435	435	9.67	APROBADO
436	436	7.69	APROBADO
437	437	8.69	APROBADO
438	438	9.97	APROBADO
439	439	9.44	APROBADO
440	440	7.97	APROBADO
441	441	9.12	APROBADO
442	442	9.84	APROBADO
443	443	9.93	APROBADO
444	444	9.09	APROBADO
445	445	7.23	APROBADO
446	446	7.32	APROBADO
447	447	8.57	APROBADO
448	448	7.05	APROBADO
449	449	7.43	APROBADO
450	450	7.40	APROBADO
451	451	7.46	APROBADO
452	452	7.29	APROBADO
453	453	9.62	APROBADO
454	454	9.82	APROBADO
455	455	9.34	APROBADO
456	456	9.75	APROBADO
457	457	7.36	APROBADO
458	458	9.11	APROBADO
459	459	9.86	APROBADO
460	460	9.01	APROBADO
461	461	9.09	APROBADO
462	462	7.73	APROBADO
463	463	9.05	APROBADO
464	464	9.65	APROBADO
465	465	9.16	APROBADO
466	466	7.24	APROBADO
467	467	9.17	APROBADO
468	468	7.71	APROBADO
469	469	7.22	APROBADO
470	470	8.68	APROBADO
471	471	7.15	APROBADO
472	472	8.87	APROBADO
473	473	9.87	APROBADO
474	474	7.77	APROBADO
475	475	7.86	APROBADO
476	476	8.75	APROBADO
477	477	9.26	APROBADO
478	478	8.27	APROBADO
479	479	8.70	APROBADO
480	480	7.16	APROBADO
481	481	9.20	APROBADO
482	482	9.18	APROBADO
483	483	8.74	APROBADO
484	484	7.52	APROBADO
485	485	9.18	APROBADO
486	486	9.87	APROBADO
487	487	9.28	APROBADO
488	488	7.86	APROBADO
489	489	9.26	APROBADO
490	490	7.88	APROBADO
491	491	8.93	APROBADO
492	492	7.06	APROBADO
493	493	8.08	APROBADO
494	494	8.78	APROBADO
495	495	7.65	APROBADO
496	496	9.66	APROBADO
497	497	9.96	APROBADO
498	498	7.84	APROBADO
499	499	8.44	APROBADO
500	500	7.85	APROBADO
501	501	8.49	APROBADO
502	502	8.78	APROBADO
503	503	8.16	APROBADO
504	504	8.47	APROBADO
505	505	9.10	APROBADO
506	506	7.01	APROBADO
507	507	7.80	APROBADO
508	508	9.64	APROBADO
509	509	8.34	APROBADO
510	510	7.58	APROBADO
511	511	9.61	APROBADO
512	512	8.12	APROBADO
513	513	8.63	APROBADO
514	514	8.50	APROBADO
515	515	7.94	APROBADO
516	516	8.65	APROBADO
517	517	7.60	APROBADO
518	518	7.08	APROBADO
519	519	7.97	APROBADO
520	520	7.93	APROBADO
521	521	7.20	APROBADO
522	522	7.26	APROBADO
523	523	9.86	APROBADO
524	524	8.65	APROBADO
525	525	8.13	APROBADO
526	526	9.93	APROBADO
527	527	9.84	APROBADO
528	528	7.32	APROBADO
529	529	7.84	APROBADO
530	530	9.73	APROBADO
531	531	8.18	APROBADO
532	532	8.63	APROBADO
533	533	8.00	APROBADO
534	534	7.04	APROBADO
535	535	8.86	APROBADO
536	536	8.38	APROBADO
537	537	7.05	APROBADO
538	538	8.45	APROBADO
539	539	9.69	APROBADO
540	540	7.31	APROBADO
541	541	7.71	APROBADO
542	542	8.61	APROBADO
543	543	7.55	APROBADO
544	544	8.26	APROBADO
545	545	8.30	APROBADO
546	546	9.23	APROBADO
547	547	8.01	APROBADO
548	548	8.52	APROBADO
549	549	9.78	APROBADO
550	550	8.67	APROBADO
551	551	8.87	APROBADO
552	552	7.94	APROBADO
553	553	9.00	APROBADO
554	554	9.40	APROBADO
555	555	9.69	APROBADO
556	556	8.94	APROBADO
557	557	8.90	APROBADO
558	558	9.24	APROBADO
559	559	7.18	APROBADO
560	560	8.78	APROBADO
561	561	8.20	APROBADO
562	562	9.22	APROBADO
563	563	9.71	APROBADO
564	564	9.46	APROBADO
565	565	9.11	APROBADO
566	566	9.31	APROBADO
567	567	7.61	APROBADO
568	568	7.88	APROBADO
569	569	8.58	APROBADO
570	570	8.67	APROBADO
571	571	9.97	APROBADO
572	572	8.31	APROBADO
573	573	7.25	APROBADO
574	574	9.54	APROBADO
575	575	9.49	APROBADO
576	576	9.44	APROBADO
577	577	8.40	APROBADO
578	578	7.80	APROBADO
579	579	7.48	APROBADO
580	580	9.56	APROBADO
581	581	7.49	APROBADO
582	582	8.89	APROBADO
583	583	9.44	APROBADO
584	584	8.57	APROBADO
585	585	7.56	APROBADO
586	586	9.33	APROBADO
587	587	9.88	APROBADO
588	588	7.02	APROBADO
589	589	9.76	APROBADO
590	590	8.39	APROBADO
591	591	9.98	APROBADO
592	592	8.34	APROBADO
593	593	8.44	APROBADO
594	594	7.39	APROBADO
595	595	8.93	APROBADO
596	596	8.82	APROBADO
597	597	9.50	APROBADO
598	598	8.37	APROBADO
599	599	7.19	APROBADO
600	600	9.86	APROBADO
601	601	7.28	APROBADO
602	602	9.61	APROBADO
603	603	7.33	APROBADO
604	604	8.95	APROBADO
605	605	8.54	APROBADO
606	606	8.20	APROBADO
607	607	7.04	APROBADO
608	608	7.66	APROBADO
609	609	9.15	APROBADO
610	610	7.15	APROBADO
611	611	8.36	APROBADO
612	612	9.27	APROBADO
613	613	9.90	APROBADO
614	614	7.28	APROBADO
615	615	8.34	APROBADO
616	616	9.79	APROBADO
617	617	9.81	APROBADO
618	618	8.09	APROBADO
619	619	8.34	APROBADO
620	620	8.89	APROBADO
621	621	7.41	APROBADO
622	622	7.76	APROBADO
623	623	7.36	APROBADO
624	624	9.55	APROBADO
625	625	9.99	APROBADO
626	626	9.31	APROBADO
627	627	7.33	APROBADO
628	628	7.55	APROBADO
629	629	9.79	APROBADO
630	630	7.98	APROBADO
631	631	7.31	APROBADO
632	632	9.08	APROBADO
633	633	8.87	APROBADO
634	634	9.71	APROBADO
635	635	9.69	APROBADO
636	636	8.68	APROBADO
637	637	8.68	APROBADO
638	638	9.53	APROBADO
639	639	9.85	APROBADO
640	640	7.50	APROBADO
641	641	7.19	APROBADO
642	642	9.03	APROBADO
643	643	7.26	APROBADO
644	644	8.66	APROBADO
645	645	9.31	APROBADO
646	646	9.82	APROBADO
647	647	9.36	APROBADO
648	648	8.18	APROBADO
649	649	9.62	APROBADO
650	650	7.75	APROBADO
651	651	8.98	APROBADO
652	652	8.16	APROBADO
653	653	7.45	APROBADO
654	654	9.76	APROBADO
655	655	7.95	APROBADO
656	656	7.69	APROBADO
657	657	9.25	APROBADO
658	658	9.83	APROBADO
659	659	8.76	APROBADO
660	660	9.73	APROBADO
661	661	8.30	APROBADO
662	662	9.93	APROBADO
663	663	9.83	APROBADO
664	664	9.46	APROBADO
665	665	9.69	APROBADO
666	666	9.89	APROBADO
667	667	7.20	APROBADO
668	668	7.58	APROBADO
669	669	8.91	APROBADO
670	670	7.28	APROBADO
671	671	8.72	APROBADO
672	672	9.85	APROBADO
673	673	9.32	APROBADO
674	674	9.35	APROBADO
675	675	8.40	APROBADO
676	676	7.29	APROBADO
677	677	7.96	APROBADO
678	678	8.11	APROBADO
679	679	7.53	APROBADO
680	680	7.84	APROBADO
681	681	8.15	APROBADO
682	682	8.91	APROBADO
683	683	8.19	APROBADO
684	684	9.80	APROBADO
685	685	9.35	APROBADO
686	686	8.68	APROBADO
687	687	9.48	APROBADO
688	688	9.48	APROBADO
689	689	8.68	APROBADO
690	690	7.57	APROBADO
691	691	7.29	APROBADO
692	692	9.50	APROBADO
693	693	9.62	APROBADO
694	694	9.49	APROBADO
695	695	7.07	APROBADO
696	696	9.19	APROBADO
697	697	8.04	APROBADO
698	698	8.21	APROBADO
699	699	8.92	APROBADO
700	700	9.38	APROBADO
701	701	7.82	APROBADO
702	702	8.99	APROBADO
703	703	7.66	APROBADO
704	704	9.69	APROBADO
705	705	9.19	APROBADO
706	706	8.94	APROBADO
707	707	9.96	APROBADO
708	708	9.40	APROBADO
709	709	9.03	APROBADO
710	710	8.31	APROBADO
711	711	8.87	APROBADO
712	712	9.23	APROBADO
713	713	8.49	APROBADO
714	714	7.91	APROBADO
715	715	9.65	APROBADO
716	716	7.37	APROBADO
717	717	9.85	APROBADO
718	718	9.62	APROBADO
719	719	9.94	APROBADO
720	720	8.27	APROBADO
721	721	8.85	APROBADO
722	722	8.63	APROBADO
723	723	7.39	APROBADO
724	724	7.85	APROBADO
725	725	8.92	APROBADO
726	726	8.27	APROBADO
727	727	8.99	APROBADO
728	728	7.75	APROBADO
729	729	9.57	APROBADO
730	730	7.73	APROBADO
731	731	8.73	APROBADO
732	732	7.40	APROBADO
733	733	7.71	APROBADO
734	734	9.87	APROBADO
735	735	9.94	APROBADO
736	736	8.96	APROBADO
737	737	9.61	APROBADO
738	738	8.18	APROBADO
739	739	9.88	APROBADO
740	740	7.85	APROBADO
741	741	7.05	APROBADO
742	742	7.85	APROBADO
743	743	7.61	APROBADO
744	744	7.46	APROBADO
745	745	7.42	APROBADO
746	746	9.04	APROBADO
747	747	9.15	APROBADO
748	748	9.03	APROBADO
749	749	7.06	APROBADO
750	750	8.26	APROBADO
751	751	7.18	APROBADO
752	752	8.56	APROBADO
753	753	9.45	APROBADO
754	754	8.94	APROBADO
755	755	8.32	APROBADO
756	756	9.52	APROBADO
757	757	7.46	APROBADO
758	758	7.98	APROBADO
759	759	8.65	APROBADO
760	760	7.29	APROBADO
761	761	9.59	APROBADO
762	762	9.06	APROBADO
763	763	7.66	APROBADO
764	764	8.41	APROBADO
765	765	8.49	APROBADO
766	766	8.02	APROBADO
767	767	7.39	APROBADO
768	768	9.41	APROBADO
769	769	7.24	APROBADO
770	770	9.93	APROBADO
771	771	9.63	APROBADO
772	772	7.03	APROBADO
773	773	7.33	APROBADO
774	774	8.67	APROBADO
775	775	7.75	APROBADO
776	776	7.97	APROBADO
777	777	7.65	APROBADO
778	778	7.34	APROBADO
779	779	8.13	APROBADO
780	780	8.57	APROBADO
781	781	9.52	APROBADO
782	782	8.46	APROBADO
783	783	8.80	APROBADO
784	784	8.27	APROBADO
785	785	7.47	APROBADO
786	786	8.39	APROBADO
787	787	7.23	APROBADO
788	788	9.94	APROBADO
789	789	7.91	APROBADO
790	790	8.26	APROBADO
791	791	8.59	APROBADO
792	792	7.80	APROBADO
793	793	7.65	APROBADO
794	794	7.36	APROBADO
795	795	8.41	APROBADO
796	796	7.71	APROBADO
797	797	7.62	APROBADO
798	798	7.15	APROBADO
799	799	9.32	APROBADO
800	800	9.96	APROBADO
801	801	9.64	APROBADO
802	802	7.87	APROBADO
803	803	8.18	APROBADO
804	804	7.73	APROBADO
805	805	8.42	APROBADO
806	806	8.62	APROBADO
807	807	9.02	APROBADO
808	808	9.44	APROBADO
809	809	7.80	APROBADO
810	810	7.73	APROBADO
811	811	7.30	APROBADO
812	812	9.61	APROBADO
813	813	9.37	APROBADO
814	814	8.91	APROBADO
815	815	9.56	APROBADO
816	816	7.84	APROBADO
817	817	9.24	APROBADO
818	818	8.12	APROBADO
819	819	7.19	APROBADO
820	820	9.81	APROBADO
821	821	7.19	APROBADO
822	822	7.88	APROBADO
823	823	7.73	APROBADO
824	824	7.07	APROBADO
825	825	8.66	APROBADO
826	826	7.27	APROBADO
827	827	8.01	APROBADO
828	828	9.54	APROBADO
829	829	9.74	APROBADO
830	830	7.20	APROBADO
831	831	8.33	APROBADO
832	832	8.94	APROBADO
833	833	9.89	APROBADO
834	834	7.13	APROBADO
835	835	9.47	APROBADO
836	836	8.68	APROBADO
837	837	9.33	APROBADO
838	838	8.23	APROBADO
839	839	8.26	APROBADO
840	840	7.97	APROBADO
841	841	8.36	APROBADO
842	842	7.36	APROBADO
843	843	8.82	APROBADO
844	844	8.92	APROBADO
845	845	8.37	APROBADO
846	846	7.12	APROBADO
847	847	8.65	APROBADO
848	848	8.88	APROBADO
849	849	7.75	APROBADO
850	850	8.06	APROBADO
851	851	7.31	APROBADO
852	852	8.94	APROBADO
853	853	8.28	APROBADO
854	854	9.69	APROBADO
855	855	8.65	APROBADO
856	856	8.82	APROBADO
857	857	7.97	APROBADO
858	858	7.18	APROBADO
859	859	9.35	APROBADO
860	860	9.23	APROBADO
861	861	9.78	APROBADO
862	862	9.12	APROBADO
863	863	7.24	APROBADO
864	864	8.56	APROBADO
865	865	7.49	APROBADO
866	866	9.33	APROBADO
867	867	8.47	APROBADO
868	868	9.63	APROBADO
869	869	7.41	APROBADO
870	870	7.38	APROBADO
871	871	8.73	APROBADO
872	872	9.68	APROBADO
873	873	8.94	APROBADO
874	874	7.29	APROBADO
875	875	7.51	APROBADO
876	876	7.52	APROBADO
877	877	7.32	APROBADO
878	878	8.80	APROBADO
879	879	7.62	APROBADO
880	880	9.81	APROBADO
881	881	7.86	APROBADO
882	882	9.39	APROBADO
883	883	8.72	APROBADO
884	884	9.91	APROBADO
885	885	9.40	APROBADO
886	886	8.70	APROBADO
887	887	7.66	APROBADO
888	888	7.91	APROBADO
889	889	8.11	APROBADO
890	890	9.10	APROBADO
891	891	8.24	APROBADO
892	892	9.54	APROBADO
893	893	7.91	APROBADO
894	894	7.13	APROBADO
895	895	7.83	APROBADO
896	896	7.63	APROBADO
897	897	7.96	APROBADO
898	898	8.29	APROBADO
899	899	8.00	APROBADO
900	900	9.79	APROBADO
901	901	7.71	APROBADO
902	902	8.17	APROBADO
903	903	9.63	APROBADO
904	904	8.48	APROBADO
905	905	7.54	APROBADO
906	906	7.38	APROBADO
907	907	7.32	APROBADO
908	908	7.40	APROBADO
909	909	8.85	APROBADO
910	910	7.11	APROBADO
911	911	7.76	APROBADO
912	912	8.64	APROBADO
913	913	7.69	APROBADO
914	914	8.52	APROBADO
915	915	9.89	APROBADO
916	916	8.55	APROBADO
917	917	7.29	APROBADO
918	918	7.04	APROBADO
919	919	9.71	APROBADO
920	920	7.82	APROBADO
921	921	9.85	APROBADO
922	922	7.70	APROBADO
923	923	8.85	APROBADO
924	924	8.60	APROBADO
925	925	8.62	APROBADO
926	926	8.03	APROBADO
927	927	7.34	APROBADO
928	928	8.66	APROBADO
929	929	9.25	APROBADO
930	930	7.40	APROBADO
931	931	8.35	APROBADO
932	932	8.48	APROBADO
933	933	7.59	APROBADO
934	934	9.38	APROBADO
935	935	8.37	APROBADO
936	936	7.40	APROBADO
937	937	8.44	APROBADO
938	938	8.50	APROBADO
939	939	8.57	APROBADO
940	940	9.22	APROBADO
941	941	9.82	APROBADO
942	942	9.27	APROBADO
943	943	7.04	APROBADO
944	944	9.34	APROBADO
945	945	8.37	APROBADO
946	946	7.03	APROBADO
947	947	8.87	APROBADO
948	948	8.98	APROBADO
949	949	8.09	APROBADO
950	950	9.85	APROBADO
951	951	8.53	APROBADO
952	952	7.42	APROBADO
953	953	9.09	APROBADO
954	954	8.31	APROBADO
955	955	10.00	APROBADO
956	956	8.67	APROBADO
957	957	7.79	APROBADO
958	958	7.58	APROBADO
959	959	9.28	APROBADO
960	960	9.77	APROBADO
961	961	7.94	APROBADO
962	962	8.12	APROBADO
963	963	7.43	APROBADO
964	964	7.52	APROBADO
965	965	8.42	APROBADO
966	966	7.59	APROBADO
967	967	9.22	APROBADO
968	968	9.12	APROBADO
969	969	9.38	APROBADO
970	970	7.50	APROBADO
971	971	7.96	APROBADO
972	972	8.55	APROBADO
973	973	8.94	APROBADO
974	974	9.14	APROBADO
975	975	7.30	APROBADO
976	976	7.42	APROBADO
977	977	8.60	APROBADO
978	978	9.49	APROBADO
979	979	8.49	APROBADO
980	980	7.48	APROBADO
981	981	9.12	APROBADO
982	982	9.32	APROBADO
983	983	7.53	APROBADO
984	984	8.34	APROBADO
985	985	7.35	APROBADO
986	986	8.33	APROBADO
987	987	10.00	APROBADO
988	988	8.07	APROBADO
989	989	7.70	APROBADO
990	990	8.01	APROBADO
991	991	9.08	APROBADO
992	992	7.15	APROBADO
993	993	9.66	APROBADO
994	994	8.13	APROBADO
995	995	9.69	APROBADO
996	996	7.62	APROBADO
997	997	7.17	APROBADO
998	998	9.25	APROBADO
999	999	8.90	APROBADO
1000	1000	8.42	APROBADO
1001	1001	8.60	APROBADO
1002	1002	7.01	APROBADO
1003	1003	9.11	APROBADO
1004	1004	7.73	APROBADO
1005	1005	8.81	APROBADO
1006	1006	8.69	APROBADO
1007	1007	9.38	APROBADO
1008	1008	7.83	APROBADO
1009	1009	8.68	APROBADO
1010	1010	7.79	APROBADO
1011	1011	8.77	APROBADO
1012	1012	7.08	APROBADO
1013	1013	8.58	APROBADO
1014	1014	7.85	APROBADO
1015	1015	8.60	APROBADO
1016	1016	7.44	APROBADO
1017	1017	8.17	APROBADO
1018	1018	8.17	APROBADO
1019	1019	8.74	APROBADO
1020	1020	9.97	APROBADO
1021	1021	9.67	APROBADO
1022	1022	7.27	APROBADO
1023	1023	8.60	APROBADO
1024	1024	9.38	APROBADO
1025	1025	7.44	APROBADO
1026	1026	9.30	APROBADO
1027	1027	7.03	APROBADO
1028	1028	8.47	APROBADO
1029	1029	8.05	APROBADO
1030	1030	7.98	APROBADO
1031	1031	8.11	APROBADO
1032	1032	7.67	APROBADO
1033	1033	7.09	APROBADO
1034	1034	9.04	APROBADO
1035	1035	9.41	APROBADO
1036	1036	8.46	APROBADO
1037	1037	7.72	APROBADO
1038	1038	9.12	APROBADO
1039	1039	9.16	APROBADO
1040	1040	8.19	APROBADO
1041	1041	9.66	APROBADO
1042	1042	7.79	APROBADO
1043	1043	8.78	APROBADO
1044	1044	8.35	APROBADO
1045	1045	7.89	APROBADO
1046	1046	8.29	APROBADO
1047	1047	9.26	APROBADO
1048	1048	7.69	APROBADO
1049	1049	7.39	APROBADO
1050	1050	9.57	APROBADO
1051	1051	8.50	APROBADO
1052	1052	8.32	APROBADO
1053	1053	8.97	APROBADO
1054	1054	9.34	APROBADO
1055	1055	7.75	APROBADO
1056	1056	9.46	APROBADO
1057	1057	9.28	APROBADO
1058	1058	7.43	APROBADO
1059	1059	7.15	APROBADO
1060	1060	9.40	APROBADO
1061	1061	8.08	APROBADO
1062	1062	7.59	APROBADO
1063	1063	9.87	APROBADO
1064	1064	8.85	APROBADO
1065	1065	8.35	APROBADO
1066	1066	9.04	APROBADO
1067	1067	9.21	APROBADO
1068	1068	7.60	APROBADO
1069	1069	8.71	APROBADO
1070	1070	9.34	APROBADO
1071	1071	7.67	APROBADO
1072	1072	9.77	APROBADO
1073	1073	7.13	APROBADO
1074	1074	9.99	APROBADO
1075	1075	7.15	APROBADO
1076	1076	7.88	APROBADO
1077	1077	9.99	APROBADO
1078	1078	7.32	APROBADO
1079	1079	8.73	APROBADO
1080	1080	8.16	APROBADO
1081	1081	9.27	APROBADO
1082	1082	7.66	APROBADO
1083	1083	9.28	APROBADO
1084	1084	7.76	APROBADO
1085	1085	8.60	APROBADO
1086	1086	7.79	APROBADO
1087	1087	8.42	APROBADO
1088	1088	9.78	APROBADO
1089	1089	8.38	APROBADO
1090	1090	9.33	APROBADO
1091	1091	8.13	APROBADO
1092	1092	9.25	APROBADO
1093	1093	9.18	APROBADO
1094	1094	7.80	APROBADO
1095	1095	8.69	APROBADO
1096	1096	8.81	APROBADO
1097	1097	9.95	APROBADO
1098	1098	7.83	APROBADO
1099	1099	7.86	APROBADO
1100	1100	8.42	APROBADO
1101	1101	9.23	APROBADO
1102	1102	8.76	APROBADO
1103	1103	7.33	APROBADO
1104	1104	7.30	APROBADO
1105	1105	8.68	APROBADO
1106	1106	7.39	APROBADO
1107	1107	9.32	APROBADO
1108	1108	9.70	APROBADO
1109	1109	7.82	APROBADO
1110	1110	9.29	APROBADO
1111	1111	9.00	APROBADO
1112	1112	9.80	APROBADO
1113	1113	7.35	APROBADO
1114	1114	9.72	APROBADO
1115	1115	9.65	APROBADO
1116	1116	8.70	APROBADO
1117	1117	8.35	APROBADO
1118	1118	9.10	APROBADO
1119	1119	8.27	APROBADO
1120	1120	7.35	APROBADO
1121	1121	8.78	APROBADO
1122	1122	7.90	APROBADO
1123	1123	7.26	APROBADO
1124	1124	9.36	APROBADO
1125	1125	9.48	APROBADO
1126	1126	7.42	APROBADO
1127	1127	9.03	APROBADO
1128	1128	7.89	APROBADO
1129	1129	8.88	APROBADO
1130	1130	8.59	APROBADO
1131	1131	7.41	APROBADO
1132	1132	8.78	APROBADO
1133	1133	8.88	APROBADO
1134	1134	9.85	APROBADO
1135	1135	9.26	APROBADO
1136	1136	8.95	APROBADO
1137	1137	8.10	APROBADO
1138	1138	7.91	APROBADO
1139	1139	9.01	APROBADO
1140	1140	9.60	APROBADO
1141	1141	9.26	APROBADO
1142	1142	7.42	APROBADO
1143	1143	7.03	APROBADO
1144	1144	9.02	APROBADO
1145	1145	7.92	APROBADO
1146	1146	7.05	APROBADO
1147	1147	7.73	APROBADO
1148	1148	8.99	APROBADO
1149	1149	7.87	APROBADO
1150	1150	8.01	APROBADO
1151	1151	7.14	APROBADO
1152	1152	9.34	APROBADO
1153	1153	7.98	APROBADO
1154	1154	9.09	APROBADO
1155	1155	7.49	APROBADO
1156	1156	8.66	APROBADO
1157	1157	8.32	APROBADO
1158	1158	9.60	APROBADO
1159	1159	7.79	APROBADO
1160	1160	7.89	APROBADO
1161	1161	8.64	APROBADO
1162	1162	9.00	APROBADO
1163	1163	8.31	APROBADO
1164	1164	9.31	APROBADO
1165	1165	8.34	APROBADO
1166	1166	8.25	APROBADO
1167	1167	8.74	APROBADO
1168	1168	7.98	APROBADO
1169	1169	7.92	APROBADO
1170	1170	7.70	APROBADO
1171	1171	8.15	APROBADO
1172	1172	9.42	APROBADO
1173	1173	9.11	APROBADO
1174	1174	7.94	APROBADO
1175	1175	8.42	APROBADO
1176	1176	7.10	APROBADO
1177	1177	9.33	APROBADO
1178	1178	9.99	APROBADO
1179	1179	9.83	APROBADO
1180	1180	7.59	APROBADO
1181	1181	8.26	APROBADO
1182	1182	8.87	APROBADO
1183	1183	8.67	APROBADO
1184	1184	7.99	APROBADO
1185	1185	8.05	APROBADO
1186	1186	8.51	APROBADO
1187	1187	8.48	APROBADO
1188	1188	8.59	APROBADO
1189	1189	9.19	APROBADO
1190	1190	8.68	APROBADO
1191	1191	9.51	APROBADO
1192	1192	7.99	APROBADO
1193	1193	9.05	APROBADO
1194	1194	8.69	APROBADO
1195	1195	9.86	APROBADO
1196	1196	9.49	APROBADO
1197	1197	7.64	APROBADO
1198	1198	7.34	APROBADO
1199	1199	9.28	APROBADO
1200	1200	9.70	APROBADO
1201	1201	9.63	APROBADO
1202	1202	8.40	APROBADO
1203	1203	8.18	APROBADO
1204	1204	9.28	APROBADO
1205	1205	9.52	APROBADO
1206	1206	8.89	APROBADO
1207	1207	10.00	APROBADO
1208	1208	8.90	APROBADO
1209	1209	8.22	APROBADO
1210	1210	9.50	APROBADO
1211	1211	9.01	APROBADO
1212	1212	9.04	APROBADO
1213	1213	8.89	APROBADO
1214	1214	9.89	APROBADO
1215	1215	7.32	APROBADO
1216	1216	8.85	APROBADO
1217	1217	8.43	APROBADO
1218	1218	8.14	APROBADO
1219	1219	9.77	APROBADO
1220	1220	9.66	APROBADO
1221	1221	9.16	APROBADO
1222	1222	7.60	APROBADO
1223	1223	7.63	APROBADO
1224	1224	8.08	APROBADO
1225	1225	8.59	APROBADO
1226	1226	7.40	APROBADO
1227	1227	8.56	APROBADO
1228	1228	8.65	APROBADO
1229	1229	9.95	APROBADO
1230	1230	7.66	APROBADO
1231	1231	7.39	APROBADO
1232	1232	7.65	APROBADO
1233	1233	7.79	APROBADO
1234	1234	9.14	APROBADO
1235	1235	8.67	APROBADO
1236	1236	8.49	APROBADO
1237	1237	7.73	APROBADO
1238	1238	7.56	APROBADO
1239	1239	9.91	APROBADO
1240	1240	7.51	APROBADO
1241	1241	7.05	APROBADO
1242	1242	8.20	APROBADO
1243	1243	7.10	APROBADO
1244	1244	9.54	APROBADO
1245	1245	7.08	APROBADO
1246	1246	9.08	APROBADO
1247	1247	8.37	APROBADO
1248	1248	9.07	APROBADO
1249	1249	7.86	APROBADO
1250	1250	7.81	APROBADO
1251	1251	7.90	APROBADO
1252	1252	9.48	APROBADO
1253	1253	7.49	APROBADO
1254	1254	9.35	APROBADO
1255	1255	8.80	APROBADO
1256	1256	9.04	APROBADO
1257	1257	8.47	APROBADO
1258	1258	8.52	APROBADO
1259	1259	7.47	APROBADO
1260	1260	7.33	APROBADO
1261	1261	9.73	APROBADO
1262	1262	7.44	APROBADO
1263	1263	8.10	APROBADO
1264	1264	9.29	APROBADO
1265	1265	7.32	APROBADO
1266	1266	7.94	APROBADO
1267	1267	7.66	APROBADO
1268	1268	8.45	APROBADO
1269	1269	9.48	APROBADO
1270	1270	8.86	APROBADO
1271	1271	7.26	APROBADO
1272	1272	7.26	APROBADO
1273	1273	9.60	APROBADO
1274	1274	7.56	APROBADO
1275	1275	9.94	APROBADO
1276	1276	7.57	APROBADO
1277	1277	7.04	APROBADO
1278	1278	8.48	APROBADO
1279	1279	9.36	APROBADO
1280	1280	8.04	APROBADO
1281	1281	8.16	APROBADO
1282	1282	9.50	APROBADO
1283	1283	9.55	APROBADO
1284	1284	7.48	APROBADO
1285	1285	8.28	APROBADO
1286	1286	8.94	APROBADO
1287	1287	8.73	APROBADO
1288	1288	9.49	APROBADO
1289	1289	9.02	APROBADO
1290	1290	7.90	APROBADO
1291	1291	7.66	APROBADO
1292	1292	8.65	APROBADO
1293	1293	8.65	APROBADO
1294	1294	9.03	APROBADO
1295	1295	8.56	APROBADO
1296	1296	7.18	APROBADO
1297	1297	9.86	APROBADO
1298	1298	9.63	APROBADO
1299	1299	9.38	APROBADO
1300	1300	9.45	APROBADO
1301	1301	7.25	APROBADO
1302	1302	7.64	APROBADO
1303	1303	9.84	APROBADO
1304	1304	7.14	APROBADO
1305	1305	8.30	APROBADO
1306	1306	7.50	APROBADO
1307	1307	9.46	APROBADO
1308	1308	9.26	APROBADO
1309	1309	7.69	APROBADO
1310	1310	9.19	APROBADO
1311	1311	9.97	APROBADO
1312	1312	8.24	APROBADO
1313	1313	7.62	APROBADO
1314	1314	8.32	APROBADO
1315	1315	8.61	APROBADO
1316	1316	9.19	APROBADO
1317	1317	7.33	APROBADO
1318	1318	8.42	APROBADO
1319	1319	8.72	APROBADO
1320	1320	8.77	APROBADO
1321	1321	7.31	APROBADO
1322	1322	7.32	APROBADO
1323	1323	8.51	APROBADO
1324	1324	9.01	APROBADO
1325	1325	7.57	APROBADO
1326	1326	8.38	APROBADO
1327	1327	9.69	APROBADO
1328	1328	8.99	APROBADO
1329	1329	8.02	APROBADO
1330	1330	8.75	APROBADO
1331	1331	8.41	APROBADO
1332	1332	8.26	APROBADO
1333	1333	8.82	APROBADO
1334	1334	7.57	APROBADO
1335	1335	7.75	APROBADO
1336	1336	8.28	APROBADO
1337	1337	9.06	APROBADO
1338	1338	9.33	APROBADO
1339	1339	7.13	APROBADO
1340	1340	9.29	APROBADO
1341	1341	7.36	APROBADO
1342	1342	8.73	APROBADO
1343	1343	8.91	APROBADO
1344	1344	7.94	APROBADO
1345	1345	8.39	APROBADO
1346	1346	8.28	APROBADO
1347	1347	7.57	APROBADO
1348	1348	8.71	APROBADO
1349	1349	8.99	APROBADO
1350	1350	7.67	APROBADO
1351	1351	8.82	APROBADO
1352	1352	7.27	APROBADO
1353	1353	9.63	APROBADO
1354	1354	9.74	APROBADO
1355	1355	7.63	APROBADO
1356	1356	8.14	APROBADO
1357	1357	8.11	APROBADO
1358	1358	8.10	APROBADO
1359	1359	8.39	APROBADO
1360	1360	7.46	APROBADO
1361	1361	7.38	APROBADO
1362	1362	8.40	APROBADO
1363	1363	9.36	APROBADO
1364	1364	7.29	APROBADO
1365	1365	9.45	APROBADO
1366	1366	9.93	APROBADO
1367	1367	9.17	APROBADO
1368	1368	9.56	APROBADO
1369	1369	7.28	APROBADO
1370	1370	8.26	APROBADO
1371	1371	9.26	APROBADO
1372	1372	8.29	APROBADO
1373	1373	9.55	APROBADO
1374	1374	8.24	APROBADO
1375	1375	7.81	APROBADO
1376	1376	9.69	APROBADO
1377	1377	8.27	APROBADO
1378	1378	8.04	APROBADO
1379	1379	7.50	APROBADO
1380	1380	8.95	APROBADO
1381	1381	9.59	APROBADO
1382	1382	8.85	APROBADO
1383	1383	7.23	APROBADO
1384	1384	9.80	APROBADO
1385	1385	7.87	APROBADO
1386	1386	8.42	APROBADO
1387	1387	9.14	APROBADO
1388	1388	8.67	APROBADO
1389	1389	9.06	APROBADO
1390	1390	8.60	APROBADO
1391	1391	7.96	APROBADO
1392	1392	7.35	APROBADO
1393	1393	7.58	APROBADO
1394	1394	7.82	APROBADO
1395	1395	9.08	APROBADO
1396	1396	8.82	APROBADO
1397	1397	7.95	APROBADO
1398	1398	9.42	APROBADO
1399	1399	8.91	APROBADO
1400	1400	7.39	APROBADO
1401	1401	9.63	APROBADO
1402	1402	7.99	APROBADO
1403	1403	8.56	APROBADO
1404	1404	8.88	APROBADO
1405	1405	7.94	APROBADO
1406	1406	8.89	APROBADO
1407	1407	8.72	APROBADO
1408	1408	7.04	APROBADO
1409	1409	8.88	APROBADO
1410	1410	9.20	APROBADO
1411	1411	7.10	APROBADO
1412	1412	9.84	APROBADO
1413	1413	9.35	APROBADO
1414	1414	8.46	APROBADO
1415	1415	7.74	APROBADO
1416	1416	7.92	APROBADO
1417	1417	8.21	APROBADO
1418	1418	7.23	APROBADO
1419	1419	7.62	APROBADO
1420	1420	8.94	APROBADO
1421	1421	7.22	APROBADO
1422	1422	7.73	APROBADO
1423	1423	7.35	APROBADO
1424	1424	8.19	APROBADO
1425	1425	8.13	APROBADO
1426	1426	7.35	APROBADO
1427	1427	9.05	APROBADO
1428	1428	8.56	APROBADO
1429	1429	8.51	APROBADO
1430	1430	7.29	APROBADO
1431	1431	9.75	APROBADO
1432	1432	8.16	APROBADO
1433	1433	7.19	APROBADO
1434	1434	9.29	APROBADO
1435	1435	8.34	APROBADO
1436	1436	7.19	APROBADO
1437	1437	9.46	APROBADO
1438	1438	9.79	APROBADO
1439	1439	9.82	APROBADO
1440	1440	7.71	APROBADO
1441	1441	9.93	APROBADO
1442	1442	7.86	APROBADO
1443	1443	7.62	APROBADO
1444	1444	8.60	APROBADO
1445	1445	8.95	APROBADO
1446	1446	8.41	APROBADO
1447	1447	7.28	APROBADO
1448	1448	7.77	APROBADO
1449	1449	7.38	APROBADO
1450	1450	8.94	APROBADO
1451	1451	7.75	APROBADO
1452	1452	9.26	APROBADO
1453	1453	9.92	APROBADO
1454	1454	9.37	APROBADO
1455	1455	9.77	APROBADO
1456	1456	7.21	APROBADO
1457	1457	8.57	APROBADO
1458	1458	7.97	APROBADO
1459	1459	8.32	APROBADO
1460	1460	8.82	APROBADO
1461	1461	7.09	APROBADO
1462	1462	8.34	APROBADO
1463	1463	9.89	APROBADO
1464	1464	9.31	APROBADO
1465	1465	7.47	APROBADO
1466	1466	9.41	APROBADO
1467	1467	7.58	APROBADO
1468	1468	9.09	APROBADO
1469	1469	9.56	APROBADO
1470	1470	7.48	APROBADO
1471	1471	7.51	APROBADO
1472	1472	9.95	APROBADO
1473	1473	7.93	APROBADO
1474	1474	9.53	APROBADO
1475	1475	9.90	APROBADO
1476	1476	9.92	APROBADO
1477	1477	7.72	APROBADO
1478	1478	9.72	APROBADO
1479	1479	9.12	APROBADO
1480	1480	9.66	APROBADO
1481	1481	7.52	APROBADO
1482	1482	8.74	APROBADO
1483	1483	9.90	APROBADO
1484	1484	8.32	APROBADO
1485	1485	8.09	APROBADO
1486	1486	8.07	APROBADO
1487	1487	9.68	APROBADO
1488	1488	9.66	APROBADO
1489	1489	8.04	APROBADO
1490	1490	8.01	APROBADO
1491	1491	7.88	APROBADO
1492	1492	9.62	APROBADO
1493	1493	8.99	APROBADO
1494	1494	7.44	APROBADO
1495	1495	9.07	APROBADO
1496	1496	8.35	APROBADO
1497	1497	7.11	APROBADO
1498	1498	8.53	APROBADO
1499	1499	9.96	APROBADO
1500	1500	8.75	APROBADO
1501	1501	7.24	APROBADO
1502	1502	8.66	APROBADO
1503	1503	8.67	APROBADO
1504	1504	8.10	APROBADO
1505	1505	7.99	APROBADO
1506	1506	9.50	APROBADO
1507	1507	9.64	APROBADO
1508	1508	9.81	APROBADO
1509	1509	9.67	APROBADO
1510	1510	7.78	APROBADO
1511	1511	7.50	APROBADO
1512	1512	7.14	APROBADO
1513	1513	8.90	APROBADO
1514	1514	8.80	APROBADO
1515	1515	9.31	APROBADO
1516	1516	7.79	APROBADO
1517	1517	8.16	APROBADO
1518	1518	8.59	APROBADO
1519	1519	9.72	APROBADO
1520	1520	8.51	APROBADO
1521	1521	9.79	APROBADO
1522	1522	8.00	APROBADO
1523	1523	8.24	APROBADO
1524	1524	9.49	APROBADO
1525	1525	9.84	APROBADO
1526	1526	7.12	APROBADO
1527	1527	9.12	APROBADO
1528	1528	7.99	APROBADO
1529	1529	8.72	APROBADO
1530	1530	9.73	APROBADO
1531	1531	9.97	APROBADO
1532	1532	9.93	APROBADO
1533	1533	8.31	APROBADO
1534	1534	8.71	APROBADO
1535	1535	9.24	APROBADO
1536	1536	8.85	APROBADO
1537	1537	8.66	APROBADO
1538	1538	8.22	APROBADO
1539	1539	9.68	APROBADO
1540	1540	7.64	APROBADO
1541	1541	8.65	APROBADO
1542	1542	7.69	APROBADO
1543	1543	7.89	APROBADO
1544	1544	9.04	APROBADO
1545	1545	7.01	APROBADO
1546	1546	7.11	APROBADO
1547	1547	8.20	APROBADO
1548	1548	9.06	APROBADO
1549	1549	9.59	APROBADO
1550	1550	8.00	APROBADO
1551	1551	7.92	APROBADO
1552	1552	8.59	APROBADO
1553	1553	9.98	APROBADO
1554	1554	8.46	APROBADO
1555	1555	9.61	APROBADO
1556	1556	8.70	APROBADO
1557	1557	7.46	APROBADO
1558	1558	7.13	APROBADO
1559	1559	8.11	APROBADO
1560	1560	7.57	APROBADO
1561	1561	7.85	APROBADO
1562	1562	9.87	APROBADO
1563	1563	7.94	APROBADO
1564	1564	7.43	APROBADO
1565	1565	8.54	APROBADO
1566	1566	8.36	APROBADO
1567	1567	7.44	APROBADO
1568	1568	9.01	APROBADO
1569	1569	7.38	APROBADO
1570	1570	7.61	APROBADO
1571	1571	7.99	APROBADO
1572	1572	7.72	APROBADO
1573	1573	7.42	APROBADO
1574	1574	9.31	APROBADO
1575	1575	9.67	APROBADO
1576	1576	9.13	APROBADO
1577	1577	9.29	APROBADO
1578	1578	8.31	APROBADO
1579	1579	9.29	APROBADO
1580	1580	7.33	APROBADO
1581	1581	7.76	APROBADO
1582	1582	9.86	APROBADO
1583	1583	7.74	APROBADO
1584	1584	8.49	APROBADO
1585	1585	7.19	APROBADO
1586	1586	8.36	APROBADO
1587	1587	8.79	APROBADO
1588	1588	9.18	APROBADO
1589	1589	7.14	APROBADO
1590	1590	7.20	APROBADO
1591	1591	9.13	APROBADO
1592	1592	8.63	APROBADO
1593	1593	9.78	APROBADO
1594	1594	8.27	APROBADO
1595	1595	9.73	APROBADO
1596	1596	8.66	APROBADO
1597	1597	7.99	APROBADO
1598	1598	8.65	APROBADO
1599	1599	8.30	APROBADO
1600	1600	7.89	APROBADO
1601	1601	8.90	APROBADO
1602	1602	8.82	APROBADO
1603	1603	7.57	APROBADO
1604	1604	9.47	APROBADO
1605	1605	8.67	APROBADO
1606	1606	7.39	APROBADO
1607	1607	8.98	APROBADO
1608	1608	9.88	APROBADO
1609	1609	9.42	APROBADO
1610	1610	8.10	APROBADO
1611	1611	8.72	APROBADO
1612	1612	8.42	APROBADO
1613	1613	9.48	APROBADO
1614	1614	8.58	APROBADO
1615	1615	8.30	APROBADO
1616	1616	8.35	APROBADO
1617	1617	9.38	APROBADO
1618	1618	7.62	APROBADO
1619	1619	9.20	APROBADO
1620	1620	9.20	APROBADO
1621	1621	7.11	APROBADO
1622	1622	7.79	APROBADO
1623	1623	8.44	APROBADO
1624	1624	7.66	APROBADO
1625	1625	7.67	APROBADO
1626	1626	8.27	APROBADO
1627	1627	8.43	APROBADO
1628	1628	7.22	APROBADO
1629	1629	9.80	APROBADO
1630	1630	8.03	APROBADO
1631	1631	7.92	APROBADO
1632	1632	8.82	APROBADO
1633	1633	7.26	APROBADO
1634	1634	8.23	APROBADO
1635	1635	8.10	APROBADO
1636	1636	9.97	APROBADO
1637	1637	7.27	APROBADO
1638	1638	8.80	APROBADO
1639	1639	8.80	APROBADO
1640	1640	9.13	APROBADO
1641	1641	9.78	APROBADO
1642	1642	9.18	APROBADO
1643	1643	9.83	APROBADO
1644	1644	9.83	APROBADO
1645	1645	9.95	APROBADO
1646	1646	7.03	APROBADO
1647	1647	8.07	APROBADO
1648	1648	9.32	APROBADO
1649	1649	8.91	APROBADO
1650	1650	9.52	APROBADO
1651	1651	7.79	APROBADO
1652	1652	9.25	APROBADO
1653	1653	8.26	APROBADO
1654	1654	7.48	APROBADO
1655	1655	7.63	APROBADO
1656	1656	9.01	APROBADO
1657	1657	7.79	APROBADO
1658	1658	7.73	APROBADO
1659	1659	9.79	APROBADO
1660	1660	9.78	APROBADO
1661	1661	9.24	APROBADO
1662	1662	9.73	APROBADO
1663	1663	7.40	APROBADO
1664	1664	9.50	APROBADO
1665	1665	9.21	APROBADO
1666	1666	8.65	APROBADO
1667	1667	8.00	APROBADO
1668	1668	8.68	APROBADO
1669	1669	8.31	APROBADO
1670	1670	9.43	APROBADO
1671	1671	9.32	APROBADO
1672	1672	8.96	APROBADO
1673	1673	7.50	APROBADO
1674	1674	9.51	APROBADO
1675	1675	9.39	APROBADO
1676	1676	9.42	APROBADO
1677	1677	7.08	APROBADO
1678	1678	7.38	APROBADO
1679	1679	8.75	APROBADO
1680	1680	7.84	APROBADO
1681	1681	7.48	APROBADO
1682	1682	8.55	APROBADO
1683	1683	7.92	APROBADO
1684	1684	8.22	APROBADO
1685	1685	7.40	APROBADO
1686	1686	8.60	APROBADO
1687	1687	9.28	APROBADO
1688	1688	8.37	APROBADO
1689	1689	7.91	APROBADO
1690	1690	8.66	APROBADO
1691	1691	8.51	APROBADO
1692	1692	9.31	APROBADO
1693	1693	9.03	APROBADO
1694	1694	8.24	APROBADO
1695	1695	8.78	APROBADO
1696	1696	8.36	APROBADO
1697	1697	8.92	APROBADO
1698	1698	9.30	APROBADO
1699	1699	7.93	APROBADO
1700	1700	9.99	APROBADO
1701	1701	9.74	APROBADO
1702	1702	9.53	APROBADO
1703	1703	8.14	APROBADO
1704	1704	9.39	APROBADO
1705	1705	8.76	APROBADO
1706	1706	9.11	APROBADO
1707	1707	7.97	APROBADO
1708	1708	8.95	APROBADO
1709	1709	9.94	APROBADO
1710	1710	8.40	APROBADO
1711	1711	9.50	APROBADO
1712	1712	7.58	APROBADO
1713	1713	9.81	APROBADO
1714	1714	8.24	APROBADO
1715	1715	8.39	APROBADO
1716	1716	9.76	APROBADO
1717	1717	8.95	APROBADO
1718	1718	9.80	APROBADO
1719	1719	7.85	APROBADO
1720	1720	7.18	APROBADO
1721	1721	8.41	APROBADO
1722	1722	7.61	APROBADO
1723	1723	7.63	APROBADO
1724	1724	9.91	APROBADO
1725	1725	8.00	APROBADO
1726	1726	9.65	APROBADO
1727	1727	8.78	APROBADO
1728	1728	7.92	APROBADO
1729	1729	7.55	APROBADO
1730	1730	8.82	APROBADO
1731	1731	9.47	APROBADO
1732	1732	9.53	APROBADO
1733	1733	9.42	APROBADO
1734	1734	9.41	APROBADO
1735	1735	8.12	APROBADO
1736	1736	7.38	APROBADO
1737	1737	7.99	APROBADO
1738	1738	7.71	APROBADO
1739	1739	7.56	APROBADO
1740	1740	8.87	APROBADO
1741	1741	9.63	APROBADO
1742	1742	7.15	APROBADO
1743	1743	9.18	APROBADO
1744	1744	8.54	APROBADO
1745	1745	9.62	APROBADO
1746	1746	9.11	APROBADO
1747	1747	9.87	APROBADO
1748	1748	8.40	APROBADO
1749	1749	9.96	APROBADO
1750	1750	8.27	APROBADO
1751	1751	7.43	APROBADO
1752	1752	9.69	APROBADO
1753	1753	9.37	APROBADO
1754	1754	7.16	APROBADO
1755	1755	9.41	APROBADO
1756	1756	9.27	APROBADO
1757	1757	7.41	APROBADO
1758	1758	7.37	APROBADO
1759	1759	8.86	APROBADO
1760	1760	7.04	APROBADO
1761	1761	7.66	APROBADO
1762	1762	9.12	APROBADO
1763	1763	8.80	APROBADO
1764	1764	9.02	APROBADO
1765	1765	8.08	APROBADO
1766	1766	9.86	APROBADO
1767	1767	8.94	APROBADO
1768	1768	7.18	APROBADO
1769	1769	7.88	APROBADO
1770	1770	9.59	APROBADO
1771	1771	7.25	APROBADO
1772	1772	7.53	APROBADO
1773	1773	8.84	APROBADO
1774	1774	7.01	APROBADO
1775	1775	9.94	APROBADO
1776	1776	7.47	APROBADO
1777	1777	8.09	APROBADO
1778	1778	7.11	APROBADO
1779	1779	8.74	APROBADO
1780	1780	9.51	APROBADO
1781	1781	9.69	APROBADO
1782	1782	9.08	APROBADO
1783	1783	7.18	APROBADO
1784	1784	9.96	APROBADO
1785	1785	8.24	APROBADO
1786	1786	9.78	APROBADO
1787	1787	9.36	APROBADO
1788	1788	7.10	APROBADO
1789	1789	7.98	APROBADO
1790	1790	9.05	APROBADO
1791	1791	9.23	APROBADO
1792	1792	9.85	APROBADO
1793	1793	8.25	APROBADO
1794	1794	9.50	APROBADO
1795	1795	9.17	APROBADO
1796	1796	8.09	APROBADO
1797	1797	8.71	APROBADO
1798	1798	9.78	APROBADO
1799	1799	9.61	APROBADO
1800	1800	8.92	APROBADO
1801	1801	9.85	APROBADO
1802	1802	8.28	APROBADO
1803	1803	7.35	APROBADO
1804	1804	7.22	APROBADO
1805	1805	7.51	APROBADO
1806	1806	9.05	APROBADO
1807	1807	7.10	APROBADO
1808	1808	8.88	APROBADO
1809	1809	8.15	APROBADO
1810	1810	8.12	APROBADO
1811	1811	8.00	APROBADO
1812	1812	7.59	APROBADO
1813	1813	9.59	APROBADO
1814	1814	7.16	APROBADO
1815	1815	8.99	APROBADO
1816	1816	7.26	APROBADO
1817	1817	9.25	APROBADO
1818	1818	8.79	APROBADO
1819	1819	7.53	APROBADO
1820	1820	9.82	APROBADO
1821	1821	8.46	APROBADO
1822	1822	8.15	APROBADO
1823	1823	8.03	APROBADO
1824	1824	8.88	APROBADO
1825	1825	9.50	APROBADO
1826	1826	9.73	APROBADO
1827	1827	7.18	APROBADO
1828	1828	8.05	APROBADO
1829	1829	8.30	APROBADO
1830	1830	9.86	APROBADO
1831	1831	7.80	APROBADO
1832	1832	7.97	APROBADO
1833	1833	8.46	APROBADO
1834	1834	9.29	APROBADO
1835	1835	9.32	APROBADO
1836	1836	7.37	APROBADO
1837	1837	9.98	APROBADO
1838	1838	8.36	APROBADO
1839	1839	7.07	APROBADO
1840	1840	9.39	APROBADO
1841	1841	7.46	APROBADO
1842	1842	9.18	APROBADO
1843	1843	8.90	APROBADO
1844	1844	9.37	APROBADO
1845	1845	9.62	APROBADO
1846	1846	8.16	APROBADO
1847	1847	8.48	APROBADO
1848	1848	8.69	APROBADO
1849	1849	8.08	APROBADO
1850	1850	7.28	APROBADO
1851	1851	7.10	APROBADO
1852	1852	7.99	APROBADO
1853	1853	8.56	APROBADO
1854	1854	8.35	APROBADO
1855	1855	8.05	APROBADO
1856	1856	8.63	APROBADO
1857	1857	7.82	APROBADO
1858	1858	9.96	APROBADO
1859	1859	8.36	APROBADO
1860	1860	7.32	APROBADO
1861	1861	7.18	APROBADO
1862	1862	7.93	APROBADO
1863	1863	8.26	APROBADO
1864	1864	8.24	APROBADO
1865	1865	9.30	APROBADO
1866	1866	8.10	APROBADO
1867	1867	9.35	APROBADO
1868	1868	9.68	APROBADO
1869	1869	9.87	APROBADO
1870	1870	7.06	APROBADO
1871	1871	8.71	APROBADO
1872	1872	9.42	APROBADO
1873	1873	7.53	APROBADO
1874	1874	8.05	APROBADO
1875	1875	7.14	APROBADO
1876	1876	7.73	APROBADO
1877	1877	9.25	APROBADO
1878	1878	8.88	APROBADO
1879	1879	8.00	APROBADO
1880	1880	7.07	APROBADO
1881	1881	9.69	APROBADO
1882	1882	9.82	APROBADO
1883	1883	9.91	APROBADO
1884	1884	7.91	APROBADO
1885	1885	7.34	APROBADO
1886	1886	8.05	APROBADO
1887	1887	8.58	APROBADO
1888	1888	7.41	APROBADO
1889	1889	7.44	APROBADO
1890	1890	8.97	APROBADO
1891	1891	9.29	APROBADO
1892	1892	7.84	APROBADO
1893	1893	8.17	APROBADO
1894	1894	7.70	APROBADO
1895	1895	7.42	APROBADO
1896	1896	9.07	APROBADO
1897	1897	9.08	APROBADO
1898	1898	7.98	APROBADO
1899	1899	7.44	APROBADO
1900	1900	7.88	APROBADO
1901	1901	8.57	APROBADO
1902	1902	10.00	APROBADO
1903	1903	7.67	APROBADO
1904	1904	7.48	APROBADO
1905	1905	9.94	APROBADO
1906	1906	8.29	APROBADO
1907	1907	8.66	APROBADO
1908	1908	9.34	APROBADO
1909	1909	7.86	APROBADO
1910	1910	9.15	APROBADO
1911	1911	7.30	APROBADO
1912	1912	7.03	APROBADO
1913	1913	7.01	APROBADO
1914	1914	7.98	APROBADO
1915	1915	9.51	APROBADO
1916	1916	7.25	APROBADO
1917	1917	8.85	APROBADO
1918	1918	7.04	APROBADO
1919	1919	8.25	APROBADO
1920	1920	8.00	APROBADO
1921	1921	9.00	APROBADO
1922	1922	7.34	APROBADO
1923	1923	7.76	APROBADO
1924	1924	9.16	APROBADO
1925	1925	7.42	APROBADO
1926	1926	7.11	APROBADO
1927	1927	9.10	APROBADO
1928	1928	7.61	APROBADO
1929	1929	8.27	APROBADO
1930	1930	9.22	APROBADO
1931	1931	8.52	APROBADO
1932	1932	9.44	APROBADO
1933	1933	8.52	APROBADO
1934	1934	8.59	APROBADO
1935	1935	8.65	APROBADO
1936	1936	9.07	APROBADO
1937	1937	9.86	APROBADO
1938	1938	9.15	APROBADO
1939	1939	9.73	APROBADO
1940	1940	7.08	APROBADO
1941	1941	7.78	APROBADO
1942	1942	9.40	APROBADO
1943	1943	8.01	APROBADO
1944	1944	9.16	APROBADO
1945	1945	9.64	APROBADO
1946	1946	7.07	APROBADO
1947	1947	8.52	APROBADO
1948	1948	8.68	APROBADO
1949	1949	8.82	APROBADO
1950	1950	9.08	APROBADO
1951	1951	8.68	APROBADO
1952	1952	7.07	APROBADO
1953	1953	7.44	APROBADO
1954	1954	9.19	APROBADO
1955	1955	9.17	APROBADO
1956	1956	7.33	APROBADO
1957	1957	8.19	APROBADO
1958	1958	9.15	APROBADO
1959	1959	7.92	APROBADO
1960	1960	7.45	APROBADO
1961	1961	7.12	APROBADO
1962	1962	8.56	APROBADO
1963	1963	9.18	APROBADO
1964	1964	7.57	APROBADO
1965	1965	8.57	APROBADO
1966	1966	9.63	APROBADO
1967	1967	9.41	APROBADO
1968	1968	8.40	APROBADO
1969	1969	9.19	APROBADO
1970	1970	9.24	APROBADO
1971	1971	8.75	APROBADO
1972	1972	7.43	APROBADO
1973	1973	9.24	APROBADO
1974	1974	9.72	APROBADO
1975	1975	7.76	APROBADO
1976	1976	9.45	APROBADO
1977	1977	8.68	APROBADO
1978	1978	9.44	APROBADO
1979	1979	9.52	APROBADO
1980	1980	7.09	APROBADO
1981	1981	9.22	APROBADO
1982	1982	7.45	APROBADO
1983	1983	7.93	APROBADO
1984	1984	7.44	APROBADO
1985	1985	9.50	APROBADO
1986	1986	7.09	APROBADO
1987	1987	8.29	APROBADO
1988	1988	9.79	APROBADO
1989	1989	7.07	APROBADO
1990	1990	9.32	APROBADO
1991	1991	9.84	APROBADO
1992	1992	7.46	APROBADO
1993	1993	7.39	APROBADO
1994	1994	9.15	APROBADO
1995	1995	7.45	APROBADO
1996	1996	9.75	APROBADO
1997	1997	7.97	APROBADO
1998	1998	9.61	APROBADO
1999	1999	7.10	APROBADO
2000	2000	7.40	APROBADO
2001	2001	8.40	APROBADO
2002	2002	7.68	APROBADO
2003	2003	7.26	APROBADO
2004	2004	9.21	APROBADO
2005	2005	7.39	APROBADO
2006	2006	9.58	APROBADO
2007	2007	7.50	APROBADO
2008	2008	7.42	APROBADO
2009	2009	9.51	APROBADO
2010	2010	9.36	APROBADO
2011	2011	8.21	APROBADO
2012	2012	9.66	APROBADO
2013	2013	8.37	APROBADO
2014	2014	8.84	APROBADO
2015	2015	8.32	APROBADO
2016	2016	8.96	APROBADO
2017	2017	7.30	APROBADO
2018	2018	8.33	APROBADO
2019	2019	7.22	APROBADO
2020	2020	9.04	APROBADO
2021	2021	7.41	APROBADO
2022	2022	8.14	APROBADO
2023	2023	7.44	APROBADO
2024	2024	7.24	APROBADO
2025	2025	7.40	APROBADO
2026	2026	9.46	APROBADO
2027	2027	7.57	APROBADO
2028	2028	8.72	APROBADO
2029	2029	8.56	APROBADO
2030	2030	8.13	APROBADO
2031	2031	7.65	APROBADO
2032	2032	7.87	APROBADO
2033	2033	8.51	APROBADO
2034	2034	7.03	APROBADO
2035	2035	8.89	APROBADO
2036	2036	7.17	APROBADO
2037	2037	9.94	APROBADO
2038	2038	8.27	APROBADO
2039	2039	7.91	APROBADO
2040	2040	9.30	APROBADO
2041	2041	8.61	APROBADO
2042	2042	9.32	APROBADO
2043	2043	8.09	APROBADO
2044	2044	7.89	APROBADO
2045	2045	8.60	APROBADO
2046	2046	9.40	APROBADO
2047	2047	7.43	APROBADO
2048	2048	9.05	APROBADO
2049	2049	8.96	APROBADO
2050	2050	9.84	APROBADO
2051	2051	7.55	APROBADO
2052	2052	8.16	APROBADO
2053	2053	8.11	APROBADO
2054	2054	8.74	APROBADO
2055	2055	8.33	APROBADO
2056	2056	9.64	APROBADO
2057	2057	8.94	APROBADO
2058	2058	7.95	APROBADO
2059	2059	8.75	APROBADO
2060	2060	7.76	APROBADO
2061	2061	8.91	APROBADO
2062	2062	9.04	APROBADO
2063	2063	7.87	APROBADO
2064	2064	7.50	APROBADO
2065	2065	7.28	APROBADO
2066	2066	7.26	APROBADO
2067	2067	7.70	APROBADO
2068	2068	7.76	APROBADO
2069	2069	9.90	APROBADO
2070	2070	7.92	APROBADO
2071	2071	7.36	APROBADO
2072	2072	9.67	APROBADO
2073	2073	7.33	APROBADO
2074	2074	9.06	APROBADO
2075	2075	9.74	APROBADO
2076	2076	9.07	APROBADO
2077	2077	9.27	APROBADO
2078	2078	7.46	APROBADO
2079	2079	8.12	APROBADO
2080	2080	9.83	APROBADO
2081	2081	7.50	APROBADO
2082	2082	7.22	APROBADO
2083	2083	7.44	APROBADO
2084	2084	8.65	APROBADO
2085	2085	7.68	APROBADO
2086	2086	7.72	APROBADO
2087	2087	9.48	APROBADO
2088	2088	7.76	APROBADO
2089	2089	7.56	APROBADO
2090	2090	9.07	APROBADO
2091	2091	9.40	APROBADO
2092	2092	8.01	APROBADO
2093	2093	9.31	APROBADO
2094	2094	8.38	APROBADO
2095	2095	8.89	APROBADO
2096	2096	9.10	APROBADO
2097	2097	9.61	APROBADO
2098	2098	7.18	APROBADO
2099	2099	7.41	APROBADO
2100	2100	8.70	APROBADO
2101	2101	7.12	APROBADO
2102	2102	8.77	APROBADO
2103	2103	8.82	APROBADO
2104	2104	7.37	APROBADO
2105	2105	8.05	APROBADO
2106	2106	8.68	APROBADO
2107	2107	9.81	APROBADO
2108	2108	7.45	APROBADO
2109	2109	7.49	APROBADO
2110	2110	9.48	APROBADO
2111	2111	8.62	APROBADO
2112	2112	7.68	APROBADO
2113	2113	9.61	APROBADO
2114	2114	7.51	APROBADO
2115	2115	9.92	APROBADO
2116	2116	9.53	APROBADO
2117	2117	9.25	APROBADO
2118	2118	9.95	APROBADO
2119	2119	7.38	APROBADO
2120	2120	8.24	APROBADO
2121	2121	8.07	APROBADO
2122	2122	9.01	APROBADO
2123	2123	8.58	APROBADO
2124	2124	7.65	APROBADO
2125	2125	9.56	APROBADO
2126	2126	7.44	APROBADO
2127	2127	7.15	APROBADO
2128	2128	9.54	APROBADO
2129	2129	7.01	APROBADO
2130	2130	7.50	APROBADO
2131	2131	7.31	APROBADO
2132	2132	8.42	APROBADO
2133	2133	8.61	APROBADO
2134	2134	8.44	APROBADO
2135	2135	8.49	APROBADO
2136	2136	9.55	APROBADO
2137	2137	8.63	APROBADO
2138	2138	8.58	APROBADO
2139	2139	9.78	APROBADO
2140	2140	9.20	APROBADO
2141	2141	9.60	APROBADO
2142	2142	9.00	APROBADO
2143	2143	8.66	APROBADO
2144	2144	8.13	APROBADO
2145	2145	7.41	APROBADO
2146	2146	7.27	APROBADO
2147	2147	9.28	APROBADO
2148	2148	7.03	APROBADO
2149	2149	9.45	APROBADO
2150	2150	9.37	APROBADO
2151	2151	8.29	APROBADO
2152	2152	7.43	APROBADO
2153	2153	8.41	APROBADO
2154	2154	9.93	APROBADO
2155	2155	9.61	APROBADO
2156	2156	9.27	APROBADO
2157	2157	9.88	APROBADO
2158	2158	8.83	APROBADO
2159	2159	9.89	APROBADO
2160	2160	9.47	APROBADO
2161	2161	8.18	APROBADO
2162	2162	8.31	APROBADO
2163	2163	9.31	APROBADO
2164	2164	7.58	APROBADO
2165	2165	7.94	APROBADO
2166	2166	9.71	APROBADO
2167	2167	9.98	APROBADO
2168	2168	9.63	APROBADO
2169	2169	7.30	APROBADO
2170	2170	7.88	APROBADO
2171	2171	7.30	APROBADO
2172	2172	9.81	APROBADO
2173	2173	7.25	APROBADO
2174	2174	8.41	APROBADO
2175	2175	8.03	APROBADO
2176	2176	7.61	APROBADO
2177	2177	7.97	APROBADO
2178	2178	7.77	APROBADO
2179	2179	7.16	APROBADO
2180	2180	9.97	APROBADO
2181	2181	9.44	APROBADO
2182	2182	7.20	APROBADO
2183	2183	9.91	APROBADO
2184	2184	9.93	APROBADO
2185	2185	7.46	APROBADO
2186	2186	8.36	APROBADO
2187	2187	8.19	APROBADO
2188	2188	8.49	APROBADO
2189	2189	7.23	APROBADO
2190	2190	8.72	APROBADO
2191	2191	7.81	APROBADO
2192	2192	8.45	APROBADO
2193	2193	8.35	APROBADO
2194	2194	7.18	APROBADO
2195	2195	9.73	APROBADO
2196	2196	8.27	APROBADO
2197	2197	9.12	APROBADO
2198	2198	7.10	APROBADO
2199	2199	9.86	APROBADO
2200	2200	8.74	APROBADO
2201	2201	9.42	APROBADO
2202	2202	9.17	APROBADO
2203	2203	9.17	APROBADO
2204	2204	9.95	APROBADO
2205	2205	9.01	APROBADO
2206	2206	8.08	APROBADO
2207	2207	7.19	APROBADO
2208	2208	9.50	APROBADO
2209	2209	8.78	APROBADO
2210	2210	7.73	APROBADO
2211	2211	7.76	APROBADO
2212	2212	7.07	APROBADO
2213	2213	8.82	APROBADO
2214	2214	8.20	APROBADO
2215	2215	9.81	APROBADO
2216	2216	9.06	APROBADO
2217	2217	8.32	APROBADO
2218	2218	7.45	APROBADO
2219	2219	7.20	APROBADO
2220	2220	9.56	APROBADO
2221	2221	7.30	APROBADO
2222	2222	7.45	APROBADO
2223	2223	9.75	APROBADO
2224	2224	9.95	APROBADO
2225	2225	7.91	APROBADO
2226	2226	7.90	APROBADO
2227	2227	9.09	APROBADO
2228	2228	8.56	APROBADO
2229	2229	8.36	APROBADO
2230	2230	8.02	APROBADO
2231	2231	8.91	APROBADO
2232	2232	8.93	APROBADO
2233	2233	8.24	APROBADO
2234	2234	7.75	APROBADO
2235	2235	9.59	APROBADO
2236	2236	8.18	APROBADO
2237	2237	8.00	APROBADO
2238	2238	9.73	APROBADO
2239	2239	8.97	APROBADO
2240	2240	7.80	APROBADO
2241	2241	9.26	APROBADO
2242	2242	9.87	APROBADO
2243	2243	7.21	APROBADO
2244	2244	7.49	APROBADO
2245	2245	8.28	APROBADO
2246	2246	7.68	APROBADO
2247	2247	8.29	APROBADO
2248	2248	9.62	APROBADO
2249	2249	9.82	APROBADO
2250	2250	7.08	APROBADO
2251	2251	9.74	APROBADO
2252	2252	9.88	APROBADO
2253	2253	7.36	APROBADO
2254	2254	9.03	APROBADO
2255	2255	7.55	APROBADO
2256	2256	7.85	APROBADO
2257	2257	9.07	APROBADO
2258	2258	8.81	APROBADO
2259	2259	8.65	APROBADO
2260	2260	7.57	APROBADO
2261	2261	7.54	APROBADO
2262	2262	7.44	APROBADO
2263	2263	9.54	APROBADO
2264	2264	8.47	APROBADO
2265	2265	7.75	APROBADO
2266	2266	7.77	APROBADO
2267	2267	9.08	APROBADO
2268	2268	9.15	APROBADO
2269	2269	8.51	APROBADO
2270	2270	7.61	APROBADO
2271	2271	8.41	APROBADO
2272	2272	8.99	APROBADO
2273	2273	9.02	APROBADO
2274	2274	9.45	APROBADO
2275	2275	7.13	APROBADO
2276	2276	8.34	APROBADO
2277	2277	7.15	APROBADO
2278	2278	7.63	APROBADO
2279	2279	7.98	APROBADO
2280	2280	9.33	APROBADO
2281	2281	7.89	APROBADO
2282	2282	7.22	APROBADO
2283	2283	8.28	APROBADO
2284	2284	9.33	APROBADO
2285	2285	8.70	APROBADO
2286	2286	9.83	APROBADO
2287	2287	8.71	APROBADO
2288	2288	9.44	APROBADO
2289	2289	9.53	APROBADO
2290	2290	9.90	APROBADO
2291	2291	8.83	APROBADO
2292	2292	9.60	APROBADO
2293	2293	7.24	APROBADO
2294	2294	8.07	APROBADO
2295	2295	7.48	APROBADO
2296	2296	8.87	APROBADO
2297	2297	8.59	APROBADO
2298	2298	7.12	APROBADO
2299	2299	7.47	APROBADO
2300	2300	7.47	APROBADO
2301	2301	9.97	APROBADO
2302	2302	9.19	APROBADO
2303	2303	8.09	APROBADO
2304	2304	8.48	APROBADO
2305	2305	8.13	APROBADO
2306	2306	7.40	APROBADO
2307	2307	9.49	APROBADO
2308	2308	7.72	APROBADO
2309	2309	8.68	APROBADO
2310	2310	7.01	APROBADO
2311	2311	9.38	APROBADO
2312	2312	8.36	APROBADO
2313	2313	7.74	APROBADO
2314	2314	8.87	APROBADO
2315	2315	7.52	APROBADO
2316	2316	7.48	APROBADO
2317	2317	7.25	APROBADO
2318	2318	9.96	APROBADO
2319	2319	7.48	APROBADO
2320	2320	7.58	APROBADO
2321	2321	9.03	APROBADO
2322	2322	7.94	APROBADO
2323	2323	9.22	APROBADO
2324	2324	7.96	APROBADO
2325	2325	9.67	APROBADO
2326	2326	7.17	APROBADO
2327	2327	8.57	APROBADO
2328	2328	8.20	APROBADO
2329	2329	9.27	APROBADO
2330	2330	9.82	APROBADO
2331	2331	7.15	APROBADO
2332	2332	7.22	APROBADO
2333	2333	7.55	APROBADO
2334	2334	8.16	APROBADO
2335	2335	7.45	APROBADO
2336	2336	9.68	APROBADO
2337	2337	9.85	APROBADO
2338	2338	9.64	APROBADO
2339	2339	8.16	APROBADO
2340	2340	8.70	APROBADO
2341	2341	7.97	APROBADO
2342	2342	8.68	APROBADO
2343	2343	9.17	APROBADO
2344	2344	9.04	APROBADO
2345	2345	9.60	APROBADO
2346	2346	8.69	APROBADO
2347	2347	9.87	APROBADO
2348	2348	9.01	APROBADO
2349	2349	8.35	APROBADO
2350	2350	8.16	APROBADO
2351	2351	8.15	APROBADO
2352	2352	8.30	APROBADO
2353	2353	7.39	APROBADO
2354	2354	7.75	APROBADO
2355	2355	7.51	APROBADO
2356	2356	7.95	APROBADO
2357	2357	7.24	APROBADO
2358	2358	7.28	APROBADO
2359	2359	7.13	APROBADO
2360	2360	9.96	APROBADO
2361	2361	7.42	APROBADO
2362	2362	9.23	APROBADO
2363	2363	9.65	APROBADO
2364	2364	8.25	APROBADO
2365	2365	8.49	APROBADO
2366	2366	7.23	APROBADO
2367	2367	8.10	APROBADO
2368	2368	8.21	APROBADO
2369	2369	9.02	APROBADO
2370	2370	9.34	APROBADO
2371	2371	7.78	APROBADO
2372	2372	9.40	APROBADO
2373	2373	8.69	APROBADO
2374	2374	8.95	APROBADO
2375	2375	8.78	APROBADO
2376	2376	9.07	APROBADO
2377	2377	9.97	APROBADO
2378	2378	8.82	APROBADO
2379	2379	9.16	APROBADO
2380	2380	9.85	APROBADO
2381	2381	8.29	APROBADO
2382	2382	9.96	APROBADO
2383	2383	8.96	APROBADO
2384	2384	8.26	APROBADO
2385	2385	7.55	APROBADO
2386	2386	9.44	APROBADO
2387	2387	9.93	APROBADO
2388	2388	9.94	APROBADO
2389	2389	8.55	APROBADO
2390	2390	8.17	APROBADO
2391	2391	9.12	APROBADO
2392	2392	7.20	APROBADO
2393	2393	9.99	APROBADO
2394	2394	9.80	APROBADO
2395	2395	9.58	APROBADO
2396	2396	9.11	APROBADO
2397	2397	7.07	APROBADO
2398	2398	8.91	APROBADO
2399	2399	8.76	APROBADO
2400	2400	8.49	APROBADO
2401	2401	7.87	APROBADO
2402	2402	9.60	APROBADO
2403	2403	9.72	APROBADO
2404	2404	9.71	APROBADO
2405	2405	7.94	APROBADO
2406	2406	9.93	APROBADO
2407	2407	7.41	APROBADO
2408	2408	9.35	APROBADO
2409	2409	8.35	APROBADO
2410	2410	7.87	APROBADO
2411	2411	7.95	APROBADO
2412	2412	7.47	APROBADO
2413	2413	7.06	APROBADO
2414	2414	7.84	APROBADO
2415	2415	9.31	APROBADO
2416	2416	9.74	APROBADO
2417	2417	7.34	APROBADO
2418	2418	9.28	APROBADO
2419	2419	8.83	APROBADO
2420	2420	7.14	APROBADO
2421	2421	8.96	APROBADO
2422	2422	8.57	APROBADO
2423	2423	9.36	APROBADO
2424	2424	9.69	APROBADO
2425	2425	9.37	APROBADO
2426	2426	8.50	APROBADO
2427	2427	9.37	APROBADO
2428	2428	9.65	APROBADO
2429	2429	8.87	APROBADO
2430	2430	9.45	APROBADO
2431	2431	8.26	APROBADO
2432	2432	9.99	APROBADO
2433	2433	7.80	APROBADO
2434	2434	9.41	APROBADO
2435	2435	8.73	APROBADO
2436	2436	7.46	APROBADO
2437	2437	8.29	APROBADO
2438	2438	7.87	APROBADO
2439	2439	7.89	APROBADO
2440	2440	8.00	APROBADO
2441	2441	9.65	APROBADO
2442	2442	7.05	APROBADO
2443	2443	8.58	APROBADO
2444	2444	9.98	APROBADO
2445	2445	7.40	APROBADO
2446	2446	9.07	APROBADO
2447	2447	9.04	APROBADO
2448	2448	8.92	APROBADO
2449	2449	9.33	APROBADO
2450	2450	8.27	APROBADO
2451	2451	8.22	APROBADO
2452	2452	8.84	APROBADO
2453	2453	9.08	APROBADO
2454	2454	7.68	APROBADO
2455	2455	8.83	APROBADO
2456	2456	7.29	APROBADO
2457	2457	9.79	APROBADO
2458	2458	7.01	APROBADO
2459	2459	8.85	APROBADO
2460	2460	8.09	APROBADO
2461	2461	7.62	APROBADO
2462	2462	9.24	APROBADO
2463	2463	9.31	APROBADO
2464	2464	7.72	APROBADO
2465	2465	7.13	APROBADO
2466	2466	9.22	APROBADO
2467	2467	9.26	APROBADO
2468	2468	9.59	APROBADO
2469	2469	8.52	APROBADO
2470	2470	9.02	APROBADO
2471	2471	7.59	APROBADO
2472	2472	9.25	APROBADO
2473	2473	8.23	APROBADO
2474	2474	7.87	APROBADO
2475	2475	9.38	APROBADO
2476	2476	9.73	APROBADO
2477	2477	8.46	APROBADO
2478	2478	9.80	APROBADO
2479	2479	9.82	APROBADO
2480	2480	7.33	APROBADO
2481	2481	9.09	APROBADO
2482	2482	8.17	APROBADO
2483	2483	9.81	APROBADO
2484	2484	8.82	APROBADO
2485	2485	8.91	APROBADO
2486	2486	7.34	APROBADO
2487	2487	8.34	APROBADO
2488	2488	7.85	APROBADO
2489	2489	9.84	APROBADO
2490	2490	9.58	APROBADO
2491	2491	9.59	APROBADO
2492	2492	7.67	APROBADO
2493	2493	7.51	APROBADO
2494	2494	9.25	APROBADO
2495	2495	9.48	APROBADO
2496	2496	7.73	APROBADO
2497	2497	9.06	APROBADO
2498	2498	7.72	APROBADO
2499	2499	7.87	APROBADO
2500	2500	9.67	APROBADO
2501	2501	9.65	APROBADO
2502	2502	9.57	APROBADO
2503	2503	7.92	APROBADO
2504	2504	8.21	APROBADO
2505	2505	9.53	APROBADO
2506	2506	8.17	APROBADO
2507	2507	8.60	APROBADO
2508	2508	7.23	APROBADO
2509	2509	7.65	APROBADO
2510	2510	8.63	APROBADO
2511	2511	7.44	APROBADO
2512	2512	8.32	APROBADO
2513	2513	9.01	APROBADO
2514	2514	8.56	APROBADO
2515	2515	8.37	APROBADO
2516	2516	7.31	APROBADO
2517	2517	7.57	APROBADO
2518	2518	7.43	APROBADO
2519	2519	9.63	APROBADO
2520	2520	9.44	APROBADO
2521	2521	8.47	APROBADO
2522	2522	8.15	APROBADO
2523	2523	7.62	APROBADO
2524	2524	7.34	APROBADO
2525	2525	7.48	APROBADO
2526	2526	8.17	APROBADO
2527	2527	7.18	APROBADO
2528	2528	8.06	APROBADO
2529	2529	8.04	APROBADO
2530	2530	7.26	APROBADO
2531	2531	7.48	APROBADO
2532	2532	7.05	APROBADO
2533	2533	7.73	APROBADO
2534	2534	9.51	APROBADO
2535	2535	8.09	APROBADO
2536	2536	9.19	APROBADO
2537	2537	9.04	APROBADO
2538	2538	9.85	APROBADO
2539	2539	7.92	APROBADO
2540	2540	8.91	APROBADO
2541	2541	7.30	APROBADO
2542	2542	9.42	APROBADO
2543	2543	9.86	APROBADO
2544	2544	9.98	APROBADO
2545	2545	8.06	APROBADO
2546	2546	9.33	APROBADO
2547	2547	9.31	APROBADO
2548	2548	8.56	APROBADO
2549	2549	9.98	APROBADO
2550	2550	7.67	APROBADO
2551	2551	9.21	APROBADO
2552	2552	7.56	APROBADO
2553	2553	9.80	APROBADO
2554	2554	9.22	APROBADO
2555	2555	9.33	APROBADO
2556	2556	7.25	APROBADO
2557	2557	9.84	APROBADO
2558	2558	8.39	APROBADO
2559	2559	8.52	APROBADO
2560	2560	7.05	APROBADO
2561	2561	9.32	APROBADO
2562	2562	7.17	APROBADO
2563	2563	9.60	APROBADO
2564	2564	9.72	APROBADO
2565	2565	7.74	APROBADO
2566	2566	7.51	APROBADO
2567	2567	8.06	APROBADO
2568	2568	7.03	APROBADO
2569	2569	7.84	APROBADO
2570	2570	9.92	APROBADO
2571	2571	8.72	APROBADO
2572	2572	7.05	APROBADO
2573	2573	8.35	APROBADO
2574	2574	7.04	APROBADO
2575	2575	8.00	APROBADO
2576	2576	7.92	APROBADO
2577	2577	9.54	APROBADO
2578	2578	9.50	APROBADO
2579	2579	8.67	APROBADO
2580	2580	9.87	APROBADO
2581	2581	8.75	APROBADO
2582	2582	7.10	APROBADO
2583	2583	9.25	APROBADO
2584	2584	9.73	APROBADO
2585	2585	8.28	APROBADO
2586	2586	7.09	APROBADO
2587	2587	9.14	APROBADO
2588	2588	7.63	APROBADO
2589	2589	9.70	APROBADO
2590	2590	9.81	APROBADO
2591	2591	9.88	APROBADO
2592	2592	9.94	APROBADO
2593	2593	7.22	APROBADO
2594	2594	8.37	APROBADO
2595	2595	8.04	APROBADO
2596	2596	9.86	APROBADO
2597	2597	9.69	APROBADO
2598	2598	7.41	APROBADO
2599	2599	8.45	APROBADO
2600	2600	9.63	APROBADO
2601	2601	9.78	APROBADO
2602	2602	8.02	APROBADO
2603	2603	7.61	APROBADO
2604	2604	7.90	APROBADO
2605	2605	7.13	APROBADO
2606	2606	9.64	APROBADO
2607	2607	8.04	APROBADO
2608	2608	8.19	APROBADO
2609	2609	7.21	APROBADO
2610	2610	9.86	APROBADO
2611	2611	9.94	APROBADO
2612	2612	9.75	APROBADO
2613	2613	7.17	APROBADO
2614	2614	9.97	APROBADO
2615	2615	9.80	APROBADO
2616	2616	8.27	APROBADO
2617	2617	9.79	APROBADO
2618	2618	8.08	APROBADO
2619	2619	9.14	APROBADO
2620	2620	7.16	APROBADO
2621	2621	9.15	APROBADO
2622	2622	7.71	APROBADO
2623	2623	9.36	APROBADO
2624	2624	8.49	APROBADO
2625	2625	9.04	APROBADO
2626	2626	7.67	APROBADO
2627	2627	7.75	APROBADO
2628	2628	8.47	APROBADO
2629	2629	7.01	APROBADO
2630	2630	7.44	APROBADO
2631	2631	9.32	APROBADO
2632	2632	8.35	APROBADO
2633	2633	7.25	APROBADO
2634	2634	7.72	APROBADO
2635	2635	7.70	APROBADO
2636	2636	9.21	APROBADO
2637	2637	7.02	APROBADO
2638	2638	8.92	APROBADO
2639	2639	7.46	APROBADO
2640	2640	7.27	APROBADO
2641	2641	9.02	APROBADO
2642	2642	9.47	APROBADO
2643	2643	7.10	APROBADO
2644	2644	8.99	APROBADO
2645	2645	8.32	APROBADO
2646	2646	7.51	APROBADO
2647	2647	7.98	APROBADO
2648	2648	9.96	APROBADO
2649	2649	7.68	APROBADO
2650	2650	7.17	APROBADO
2651	2651	9.13	APROBADO
2652	2652	8.76	APROBADO
2653	2653	8.62	APROBADO
2654	2654	8.99	APROBADO
2655	2655	8.32	APROBADO
2656	2656	9.17	APROBADO
2657	2657	9.14	APROBADO
2658	2658	8.24	APROBADO
2659	2659	7.85	APROBADO
2660	2660	9.95	APROBADO
2661	2661	7.61	APROBADO
2662	2662	9.55	APROBADO
2663	2663	7.50	APROBADO
2664	2664	8.27	APROBADO
2665	2665	7.05	APROBADO
2666	2666	7.00	APROBADO
2667	2667	9.71	APROBADO
2668	2668	9.98	APROBADO
2669	2669	7.88	APROBADO
2670	2670	8.43	APROBADO
2671	2671	9.27	APROBADO
2672	2672	7.44	APROBADO
2673	2673	8.62	APROBADO
2674	2674	8.68	APROBADO
2675	2675	7.29	APROBADO
2676	2676	9.09	APROBADO
2677	2677	7.11	APROBADO
2678	2678	8.00	APROBADO
2679	2679	8.91	APROBADO
2680	2680	7.08	APROBADO
2681	2681	8.02	APROBADO
2682	2682	9.77	APROBADO
2683	2683	7.29	APROBADO
2684	2684	8.75	APROBADO
2685	2685	7.71	APROBADO
2686	2686	7.40	APROBADO
2687	2687	7.18	APROBADO
2688	2688	7.57	APROBADO
2689	2689	9.07	APROBADO
2690	2690	8.26	APROBADO
2691	2691	8.23	APROBADO
2692	2692	8.36	APROBADO
2693	2693	7.03	APROBADO
2694	2694	8.58	APROBADO
2695	2695	8.01	APROBADO
2696	2696	8.28	APROBADO
2697	2697	9.72	APROBADO
2698	2698	8.38	APROBADO
2699	2699	7.10	APROBADO
2700	2700	7.59	APROBADO
2701	2701	8.47	APROBADO
2702	2702	9.27	APROBADO
2703	2703	9.08	APROBADO
2704	2704	9.45	APROBADO
2705	2705	7.97	APROBADO
2706	2706	8.67	APROBADO
2707	2707	8.68	APROBADO
2708	2708	9.76	APROBADO
2709	2709	7.31	APROBADO
2710	2710	9.25	APROBADO
2711	2711	9.34	APROBADO
2712	2712	7.20	APROBADO
2713	2713	7.77	APROBADO
2714	2714	8.05	APROBADO
2715	2715	7.59	APROBADO
2716	2716	7.60	APROBADO
2717	2717	7.00	APROBADO
2718	2718	8.95	APROBADO
2719	2719	8.41	APROBADO
2720	2720	7.29	APROBADO
2721	2721	7.56	APROBADO
2722	2722	9.30	APROBADO
2723	2723	9.24	APROBADO
2724	2724	8.76	APROBADO
2725	2725	8.73	APROBADO
2726	2726	7.35	APROBADO
2727	2727	9.65	APROBADO
2728	2728	9.57	APROBADO
2729	2729	9.23	APROBADO
2730	2730	9.80	APROBADO
2731	2731	7.83	APROBADO
2732	2732	7.37	APROBADO
2733	2733	7.13	APROBADO
2734	2734	9.86	APROBADO
2735	2735	9.60	APROBADO
2736	2736	8.72	APROBADO
2737	2737	7.83	APROBADO
2738	2738	8.66	APROBADO
2739	2739	8.98	APROBADO
2740	2740	9.10	APROBADO
2741	2741	7.51	APROBADO
2742	2742	8.29	APROBADO
2743	2743	8.25	APROBADO
2744	2744	8.45	APROBADO
2745	2745	9.97	APROBADO
2746	2746	7.70	APROBADO
2747	2747	7.01	APROBADO
2748	2748	7.30	APROBADO
2749	2749	9.94	APROBADO
2750	2750	7.44	APROBADO
2751	2751	8.47	APROBADO
2752	2752	8.94	APROBADO
2753	2753	9.02	APROBADO
2754	2754	7.37	APROBADO
2755	2755	9.43	APROBADO
2756	2756	9.81	APROBADO
2757	2757	9.52	APROBADO
2758	2758	8.52	APROBADO
2759	2759	7.67	APROBADO
2760	2760	8.42	APROBADO
2761	2761	8.99	APROBADO
2762	2762	9.28	APROBADO
2763	2763	7.52	APROBADO
2764	2764	7.19	APROBADO
2765	2765	8.59	APROBADO
2766	2766	9.80	APROBADO
2767	2767	8.67	APROBADO
2768	2768	7.41	APROBADO
2769	2769	7.74	APROBADO
2770	2770	7.98	APROBADO
2771	2771	7.13	APROBADO
2772	2772	9.76	APROBADO
2773	2773	8.32	APROBADO
2774	2774	8.42	APROBADO
2775	2775	9.57	APROBADO
2776	2776	8.87	APROBADO
2777	2777	9.78	APROBADO
2778	2778	7.77	APROBADO
2779	2779	8.63	APROBADO
2780	2780	7.90	APROBADO
2781	2781	9.39	APROBADO
2782	2782	8.53	APROBADO
2783	2783	8.95	APROBADO
2784	2784	9.13	APROBADO
2785	2785	7.78	APROBADO
2786	2786	8.08	APROBADO
2787	2787	8.97	APROBADO
2788	2788	7.53	APROBADO
2789	2789	7.36	APROBADO
2790	2790	7.71	APROBADO
2791	2791	8.57	APROBADO
2792	2792	9.70	APROBADO
2793	2793	7.05	APROBADO
2794	2794	8.09	APROBADO
2795	2795	7.10	APROBADO
2796	2796	8.40	APROBADO
2797	2797	9.38	APROBADO
2798	2798	7.52	APROBADO
2799	2799	8.00	APROBADO
2800	2800	7.59	APROBADO
2801	2801	7.46	APROBADO
2802	2802	7.16	APROBADO
2803	2803	9.20	APROBADO
2804	2804	7.86	APROBADO
2805	2805	7.52	APROBADO
2806	2806	8.11	APROBADO
2807	2807	9.87	APROBADO
2808	2808	8.16	APROBADO
2809	2809	8.11	APROBADO
2810	2810	8.40	APROBADO
2811	2811	7.69	APROBADO
2812	2812	7.90	APROBADO
2813	2813	7.57	APROBADO
2814	2814	7.64	APROBADO
2815	2815	7.91	APROBADO
2816	2816	8.33	APROBADO
2817	2817	7.65	APROBADO
2818	2818	9.34	APROBADO
2819	2819	9.07	APROBADO
2820	2820	7.16	APROBADO
2821	2821	7.15	APROBADO
2822	2822	7.88	APROBADO
2823	2823	9.07	APROBADO
2824	2824	8.32	APROBADO
2825	2825	7.81	APROBADO
2826	2826	7.12	APROBADO
2827	2827	8.88	APROBADO
2828	2828	9.77	APROBADO
2829	2829	8.33	APROBADO
2830	2830	9.79	APROBADO
2831	2831	9.30	APROBADO
2832	2832	7.28	APROBADO
2833	2833	8.30	APROBADO
2834	2834	9.59	APROBADO
2835	2835	8.23	APROBADO
2836	2836	7.54	APROBADO
2837	2837	8.19	APROBADO
2838	2838	7.76	APROBADO
2839	2839	7.62	APROBADO
2840	2840	9.03	APROBADO
2841	2841	8.21	APROBADO
2842	2842	8.72	APROBADO
2843	2843	8.52	APROBADO
2844	2844	8.77	APROBADO
2845	2845	8.64	APROBADO
2846	2846	9.91	APROBADO
2847	2847	7.56	APROBADO
2848	2848	8.06	APROBADO
2849	2849	9.76	APROBADO
2850	2850	7.71	APROBADO
2851	2851	7.43	APROBADO
2852	2852	8.47	APROBADO
2853	2853	9.33	APROBADO
2854	2854	9.99	APROBADO
2855	2855	8.99	APROBADO
2856	2856	8.19	APROBADO
2857	2857	7.99	APROBADO
2858	2858	8.78	APROBADO
2859	2859	7.06	APROBADO
2860	2860	9.48	APROBADO
2861	2861	9.43	APROBADO
2862	2862	8.87	APROBADO
2863	2863	9.98	APROBADO
2864	2864	8.33	APROBADO
2865	2865	7.21	APROBADO
2866	2866	8.91	APROBADO
2867	2867	9.94	APROBADO
2868	2868	8.43	APROBADO
2869	2869	9.91	APROBADO
2870	2870	9.88	APROBADO
2871	2871	9.73	APROBADO
2872	2872	8.32	APROBADO
2873	2873	7.56	APROBADO
2874	2874	9.96	APROBADO
2875	2875	8.10	APROBADO
2876	2876	9.64	APROBADO
2877	2877	8.15	APROBADO
2878	2878	9.60	APROBADO
2879	2879	8.69	APROBADO
2880	2880	9.90	APROBADO
2881	2881	7.37	APROBADO
2882	2882	8.15	APROBADO
2883	2883	8.84	APROBADO
2884	2884	7.36	APROBADO
2885	2885	9.52	APROBADO
2886	2886	7.80	APROBADO
2887	2887	8.91	APROBADO
2888	2888	9.14	APROBADO
2889	2889	7.85	APROBADO
2890	2890	8.24	APROBADO
2891	2891	9.92	APROBADO
2892	2892	8.57	APROBADO
2893	2893	9.04	APROBADO
2894	2894	8.14	APROBADO
2895	2895	9.59	APROBADO
2896	2896	8.59	APROBADO
2897	2897	8.84	APROBADO
2898	2898	9.45	APROBADO
2899	2899	9.33	APROBADO
2900	2900	8.72	APROBADO
2901	2901	7.67	APROBADO
2902	2902	7.33	APROBADO
2903	2903	8.70	APROBADO
2904	2904	7.08	APROBADO
2905	2905	9.53	APROBADO
2906	2906	9.96	APROBADO
2907	2907	8.30	APROBADO
2908	2908	9.59	APROBADO
2909	2909	7.35	APROBADO
2910	2910	7.39	APROBADO
2911	2911	8.46	APROBADO
2912	2912	8.39	APROBADO
2913	2913	8.13	APROBADO
2914	2914	8.31	APROBADO
2915	2915	8.45	APROBADO
2916	2916	7.96	APROBADO
2917	2917	8.01	APROBADO
2918	2918	7.97	APROBADO
2919	2919	9.03	APROBADO
2920	2920	8.93	APROBADO
2921	2921	8.80	APROBADO
2922	2922	7.11	APROBADO
2923	2923	8.68	APROBADO
2924	2924	8.63	APROBADO
2925	2925	9.01	APROBADO
2926	2926	8.92	APROBADO
2927	2927	7.89	APROBADO
2928	2928	7.43	APROBADO
2929	2929	9.55	APROBADO
2930	2930	8.11	APROBADO
2931	2931	9.48	APROBADO
2932	2932	8.85	APROBADO
2933	2933	7.02	APROBADO
2934	2934	9.49	APROBADO
2935	2935	7.26	APROBADO
2936	2936	7.06	APROBADO
2937	2937	7.51	APROBADO
2938	2938	8.47	APROBADO
2939	2939	8.55	APROBADO
2940	2940	7.96	APROBADO
2941	2941	9.09	APROBADO
2942	2942	8.42	APROBADO
2943	2943	9.72	APROBADO
2944	2944	9.27	APROBADO
2945	2945	8.64	APROBADO
2946	2946	7.92	APROBADO
2947	2947	9.01	APROBADO
2948	2948	9.22	APROBADO
2949	2949	8.84	APROBADO
2950	2950	8.93	APROBADO
2951	2951	8.79	APROBADO
2952	2952	7.64	APROBADO
2953	2953	8.66	APROBADO
2954	2954	9.00	APROBADO
2955	2955	8.27	APROBADO
2956	2956	9.83	APROBADO
2957	2957	8.04	APROBADO
2958	2958	7.55	APROBADO
2959	2959	9.05	APROBADO
2960	2960	9.01	APROBADO
2961	2961	7.72	APROBADO
2962	2962	8.68	APROBADO
2963	2963	7.12	APROBADO
2964	2964	7.69	APROBADO
2965	2965	8.07	APROBADO
2966	2966	9.62	APROBADO
2967	2967	9.09	APROBADO
2968	2968	8.01	APROBADO
2969	2969	9.84	APROBADO
2970	2970	9.38	APROBADO
2971	2971	8.01	APROBADO
2972	2972	7.97	APROBADO
2973	2973	9.22	APROBADO
2974	2974	7.58	APROBADO
2975	2975	9.89	APROBADO
2976	2976	9.82	APROBADO
2977	2977	9.60	APROBADO
2978	2978	7.37	APROBADO
2979	2979	9.25	APROBADO
2980	2980	7.77	APROBADO
2981	2981	7.50	APROBADO
2982	2982	7.94	APROBADO
2983	2983	9.23	APROBADO
2984	2984	8.90	APROBADO
2985	2985	7.93	APROBADO
2986	2986	8.89	APROBADO
2987	2987	8.19	APROBADO
2988	2988	9.21	APROBADO
2989	2989	9.39	APROBADO
2990	2990	8.44	APROBADO
2991	2991	7.30	APROBADO
2992	2992	7.53	APROBADO
2993	2993	7.29	APROBADO
2994	2994	9.22	APROBADO
2995	2995	7.54	APROBADO
2996	2996	9.87	APROBADO
2997	2997	9.03	APROBADO
2998	2998	7.99	APROBADO
2999	2999	9.75	APROBADO
3000	3000	8.03	APROBADO
3001	3001	8.45	APROBADO
3002	3002	7.65	APROBADO
3003	3003	9.61	APROBADO
3004	3004	8.17	APROBADO
3005	3005	8.05	APROBADO
3006	3006	8.18	APROBADO
3007	3007	8.24	APROBADO
3008	3008	8.80	APROBADO
3009	3009	7.80	APROBADO
3010	3010	9.66	APROBADO
3011	3011	8.52	APROBADO
3012	3012	7.19	APROBADO
3013	3013	9.33	APROBADO
3014	3014	8.75	APROBADO
3015	3015	8.79	APROBADO
3016	3016	8.63	APROBADO
3017	3017	9.90	APROBADO
3018	3018	9.51	APROBADO
3019	3019	9.90	APROBADO
3020	3020	7.55	APROBADO
3021	3021	8.30	APROBADO
3022	3022	9.71	APROBADO
3023	3023	8.52	APROBADO
3024	3024	8.82	APROBADO
3025	3025	7.44	APROBADO
3026	3026	8.88	APROBADO
3027	3027	7.04	APROBADO
3028	3028	8.21	APROBADO
3029	3029	7.55	APROBADO
3030	3030	9.47	APROBADO
3031	3031	9.45	APROBADO
3032	3032	7.02	APROBADO
3033	3033	7.67	APROBADO
3034	3034	9.30	APROBADO
3035	3035	7.97	APROBADO
3036	3036	8.88	APROBADO
3037	3037	8.40	APROBADO
3038	3038	8.92	APROBADO
3039	3039	8.38	APROBADO
3040	3040	9.94	APROBADO
3041	3041	9.54	APROBADO
3042	3042	8.14	APROBADO
3043	3043	8.41	APROBADO
3044	3044	8.95	APROBADO
3045	3045	9.17	APROBADO
3046	3046	8.82	APROBADO
3047	3047	9.79	APROBADO
3048	3048	7.08	APROBADO
3049	3049	9.54	APROBADO
3050	3050	9.90	APROBADO
3051	3051	7.72	APROBADO
3052	3052	10.00	APROBADO
3053	3053	9.28	APROBADO
3054	3054	7.93	APROBADO
3055	3055	8.96	APROBADO
3056	3056	8.28	APROBADO
3057	3057	9.37	APROBADO
3058	3058	8.11	APROBADO
3059	3059	8.50	APROBADO
3060	3060	7.42	APROBADO
3061	3061	7.34	APROBADO
3062	3062	8.11	APROBADO
3063	3063	7.27	APROBADO
3064	3064	9.61	APROBADO
3065	3065	9.57	APROBADO
3066	3066	7.07	APROBADO
3067	3067	7.29	APROBADO
3068	3068	9.21	APROBADO
3069	3069	7.14	APROBADO
3070	3070	9.20	APROBADO
3071	3071	9.55	APROBADO
3072	3072	7.85	APROBADO
3073	3073	7.34	APROBADO
3074	3074	7.58	APROBADO
3075	3075	8.18	APROBADO
3076	3076	7.50	APROBADO
3077	3077	9.02	APROBADO
3078	3078	8.63	APROBADO
3079	3079	8.84	APROBADO
3080	3080	9.40	APROBADO
3081	3081	8.60	APROBADO
3082	3082	9.74	APROBADO
3083	3083	7.11	APROBADO
3084	3084	7.84	APROBADO
3085	3085	8.93	APROBADO
3086	3086	9.99	APROBADO
3087	3087	9.22	APROBADO
3088	3088	8.36	APROBADO
3089	3089	7.21	APROBADO
3090	3090	7.65	APROBADO
3091	3091	7.39	APROBADO
3092	3092	8.66	APROBADO
3093	3093	9.85	APROBADO
3094	3094	7.19	APROBADO
3095	3095	8.35	APROBADO
3096	3096	8.94	APROBADO
3097	3097	9.65	APROBADO
3098	3098	9.05	APROBADO
3099	3099	7.94	APROBADO
3100	3100	9.54	APROBADO
3101	3101	7.64	APROBADO
3102	3102	7.37	APROBADO
3103	3103	7.68	APROBADO
3104	3104	7.50	APROBADO
3105	3105	8.26	APROBADO
3106	3106	9.93	APROBADO
3107	3107	7.84	APROBADO
3108	3108	8.73	APROBADO
3109	3109	9.71	APROBADO
3110	3110	8.15	APROBADO
3111	3111	8.67	APROBADO
3112	3112	8.94	APROBADO
3113	3113	8.49	APROBADO
3114	3114	7.14	APROBADO
3115	3115	9.59	APROBADO
3116	3116	8.53	APROBADO
3117	3117	8.43	APROBADO
3118	3118	9.78	APROBADO
3119	3119	9.09	APROBADO
3120	3120	7.33	APROBADO
3121	3121	7.17	APROBADO
3122	3122	9.72	APROBADO
3123	3123	9.68	APROBADO
3124	3124	7.13	APROBADO
3125	3125	8.21	APROBADO
3126	3126	8.57	APROBADO
3127	3127	7.52	APROBADO
3128	3128	9.56	APROBADO
3129	3129	9.24	APROBADO
3130	3130	7.11	APROBADO
3131	3131	7.17	APROBADO
3132	3132	8.70	APROBADO
3133	3133	7.01	APROBADO
3134	3134	7.42	APROBADO
3135	3135	9.76	APROBADO
3136	3136	8.07	APROBADO
3137	3137	8.14	APROBADO
3138	3138	7.68	APROBADO
3139	3139	9.68	APROBADO
3140	3140	9.67	APROBADO
3141	3141	7.22	APROBADO
3142	3142	7.43	APROBADO
3143	3143	8.81	APROBADO
3144	3144	7.19	APROBADO
3145	3145	9.23	APROBADO
3146	3146	7.27	APROBADO
3147	3147	8.37	APROBADO
3148	3148	9.66	APROBADO
3149	3149	9.59	APROBADO
3150	3150	8.36	APROBADO
3151	3151	7.65	APROBADO
3152	3152	8.06	APROBADO
3153	3153	9.35	APROBADO
3154	3154	7.85	APROBADO
3155	3155	8.05	APROBADO
3156	3156	7.90	APROBADO
3157	3157	7.16	APROBADO
3158	3158	9.12	APROBADO
3159	3159	9.45	APROBADO
3160	3160	7.26	APROBADO
3161	3161	9.58	APROBADO
3162	3162	9.11	APROBADO
3163	3163	9.25	APROBADO
3164	3164	7.52	APROBADO
3165	3165	9.76	APROBADO
3166	3166	9.08	APROBADO
3167	3167	9.15	APROBADO
3168	3168	9.99	APROBADO
3169	3169	8.34	APROBADO
3170	3170	7.82	APROBADO
3171	3171	9.94	APROBADO
3172	3172	9.29	APROBADO
3173	3173	9.30	APROBADO
3174	3174	8.88	APROBADO
3175	3175	7.05	APROBADO
3176	3176	9.72	APROBADO
3177	3177	9.46	APROBADO
3178	3178	8.65	APROBADO
3179	3179	8.14	APROBADO
3180	3180	8.34	APROBADO
3181	3181	9.38	APROBADO
3182	3182	9.83	APROBADO
3183	3183	7.79	APROBADO
3184	3184	9.37	APROBADO
3185	3185	9.11	APROBADO
3186	3186	7.82	APROBADO
3187	3187	8.99	APROBADO
3188	3188	7.46	APROBADO
3189	3189	8.13	APROBADO
3190	3190	8.50	APROBADO
3191	3191	9.59	APROBADO
3192	3192	9.54	APROBADO
3193	3193	9.06	APROBADO
3194	3194	8.20	APROBADO
3195	3195	9.09	APROBADO
3196	3196	8.32	APROBADO
3197	3197	9.96	APROBADO
3198	3198	7.89	APROBADO
3199	3199	7.64	APROBADO
3200	3200	9.22	APROBADO
3201	3201	9.03	APROBADO
3202	3202	8.04	APROBADO
3203	3203	8.00	APROBADO
3204	3204	8.27	APROBADO
3205	3205	8.91	APROBADO
3206	3206	7.82	APROBADO
3207	3207	7.33	APROBADO
3208	3208	9.48	APROBADO
3209	3209	8.21	APROBADO
3210	3210	8.56	APROBADO
3211	3211	9.97	APROBADO
3212	3212	9.02	APROBADO
3213	3213	8.93	APROBADO
3214	3214	8.70	APROBADO
3215	3215	7.15	APROBADO
3216	3216	8.88	APROBADO
3217	3217	9.73	APROBADO
3218	3218	8.48	APROBADO
3219	3219	9.99	APROBADO
3220	3220	7.23	APROBADO
3221	3221	7.86	APROBADO
3222	3222	9.94	APROBADO
3223	3223	7.55	APROBADO
3224	3224	7.98	APROBADO
3225	3225	9.00	APROBADO
3226	3226	9.42	APROBADO
3227	3227	8.54	APROBADO
3228	3228	9.50	APROBADO
3229	3229	9.49	APROBADO
3230	3230	7.12	APROBADO
3231	3231	9.54	APROBADO
3232	3232	7.17	APROBADO
3233	3233	9.58	APROBADO
3234	3234	8.52	APROBADO
3235	3235	9.78	APROBADO
3236	3236	7.12	APROBADO
3237	3237	7.05	APROBADO
3238	3238	9.04	APROBADO
3239	3239	7.27	APROBADO
3240	3240	8.24	APROBADO
3241	3241	7.95	APROBADO
3242	3242	9.28	APROBADO
3243	3243	9.77	APROBADO
3244	3244	7.88	APROBADO
3245	3245	8.58	APROBADO
3246	3246	8.54	APROBADO
3247	3247	9.48	APROBADO
3248	3248	8.01	APROBADO
3249	3249	8.27	APROBADO
3250	3250	8.74	APROBADO
3251	3251	7.15	APROBADO
3252	3252	9.33	APROBADO
3253	3253	7.07	APROBADO
3254	3254	7.78	APROBADO
3255	3255	7.49	APROBADO
3256	3256	7.31	APROBADO
3257	3257	8.51	APROBADO
3258	3258	9.12	APROBADO
3259	3259	8.80	APROBADO
3260	3260	9.04	APROBADO
3261	3261	7.34	APROBADO
3262	3262	7.75	APROBADO
3263	3263	7.95	APROBADO
3264	3264	7.56	APROBADO
3265	3265	9.79	APROBADO
3266	3266	9.41	APROBADO
3267	3267	9.28	APROBADO
3268	3268	7.59	APROBADO
3269	3269	8.06	APROBADO
3270	3270	9.42	APROBADO
3271	3271	8.95	APROBADO
3272	3272	9.55	APROBADO
3273	3273	9.08	APROBADO
3274	3274	8.84	APROBADO
3275	3275	7.30	APROBADO
3276	3276	8.68	APROBADO
3277	3277	9.97	APROBADO
3278	3278	7.72	APROBADO
3279	3279	7.61	APROBADO
3280	3280	8.70	APROBADO
3281	3281	8.65	APROBADO
3282	3282	7.66	APROBADO
3283	3283	8.56	APROBADO
3284	3284	9.14	APROBADO
3285	3285	8.28	APROBADO
3286	3286	9.47	APROBADO
3287	3287	9.78	APROBADO
3288	3288	8.23	APROBADO
3289	3289	8.77	APROBADO
3290	3290	7.91	APROBADO
3291	3291	7.59	APROBADO
3292	3292	7.22	APROBADO
3293	3293	8.14	APROBADO
3294	3294	8.77	APROBADO
3295	3295	9.40	APROBADO
3296	3296	8.47	APROBADO
3297	3297	8.97	APROBADO
3298	3298	7.12	APROBADO
3299	3299	8.27	APROBADO
3300	3300	7.11	APROBADO
3301	3301	8.62	APROBADO
3302	3302	8.71	APROBADO
3303	3303	9.18	APROBADO
3304	3304	7.08	APROBADO
3305	3305	9.89	APROBADO
3306	3306	8.10	APROBADO
3307	3307	7.81	APROBADO
3308	3308	7.57	APROBADO
3309	3309	9.88	APROBADO
3310	3310	7.36	APROBADO
3311	3311	9.71	APROBADO
3312	3312	8.66	APROBADO
3313	3313	9.61	APROBADO
3314	3314	8.05	APROBADO
3315	3315	9.35	APROBADO
3316	3316	7.15	APROBADO
3317	3317	8.06	APROBADO
3318	3318	8.87	APROBADO
3319	3319	7.71	APROBADO
3320	3320	7.61	APROBADO
3321	3321	9.09	APROBADO
3322	3322	7.84	APROBADO
3323	3323	9.54	APROBADO
3324	3324	9.33	APROBADO
3325	3325	8.42	APROBADO
3326	3326	7.60	APROBADO
3327	3327	9.62	APROBADO
3328	3328	8.05	APROBADO
3329	3329	8.61	APROBADO
3330	3330	9.25	APROBADO
3331	3331	9.18	APROBADO
3332	3332	8.51	APROBADO
3333	3333	7.11	APROBADO
3334	3334	9.88	APROBADO
3335	3335	8.36	APROBADO
3336	3336	8.16	APROBADO
3337	3337	7.25	APROBADO
3338	3338	8.22	APROBADO
3339	3339	9.49	APROBADO
3340	3340	8.77	APROBADO
3341	3341	9.55	APROBADO
3342	3342	9.24	APROBADO
3343	3343	8.46	APROBADO
3344	3344	9.56	APROBADO
3345	3345	8.18	APROBADO
3346	3346	7.50	APROBADO
3347	3347	9.01	APROBADO
3348	3348	7.82	APROBADO
3349	3349	7.55	APROBADO
3350	3350	8.77	APROBADO
3351	3351	7.10	APROBADO
3352	3352	8.92	APROBADO
3353	3353	9.75	APROBADO
3354	3354	7.61	APROBADO
3355	3355	8.63	APROBADO
3356	3356	8.71	APROBADO
3357	3357	7.16	APROBADO
3358	3358	7.06	APROBADO
3359	3359	9.14	APROBADO
3360	3360	9.14	APROBADO
3361	3361	7.57	APROBADO
3362	3362	7.48	APROBADO
3363	3363	7.91	APROBADO
3364	3364	8.54	APROBADO
3365	3365	8.51	APROBADO
3366	3366	9.49	APROBADO
3367	3367	8.41	APROBADO
3368	3368	8.86	APROBADO
3369	3369	8.32	APROBADO
3370	3370	9.07	APROBADO
3371	3371	9.59	APROBADO
3372	3372	7.41	APROBADO
3373	3373	7.26	APROBADO
3374	3374	9.46	APROBADO
3375	3375	8.68	APROBADO
3376	3376	9.67	APROBADO
3377	3377	8.16	APROBADO
3378	3378	8.98	APROBADO
3379	3379	7.64	APROBADO
3380	3380	8.54	APROBADO
3381	3381	7.14	APROBADO
3382	3382	7.90	APROBADO
3383	3383	9.26	APROBADO
3384	3384	8.90	APROBADO
3385	3385	8.42	APROBADO
3386	3386	8.10	APROBADO
3387	3387	7.95	APROBADO
3388	3388	9.58	APROBADO
3389	3389	7.96	APROBADO
3390	3390	8.05	APROBADO
3391	3391	7.36	APROBADO
3392	3392	7.39	APROBADO
3393	3393	7.54	APROBADO
3394	3394	9.97	APROBADO
3395	3395	8.34	APROBADO
3396	3396	7.61	APROBADO
3397	3397	7.59	APROBADO
3398	3398	7.60	APROBADO
3399	3399	9.94	APROBADO
3400	3400	8.26	APROBADO
3401	3401	7.29	APROBADO
3402	3402	8.14	APROBADO
3403	3403	8.87	APROBADO
3404	3404	8.72	APROBADO
3405	3405	7.57	APROBADO
3406	3406	9.24	APROBADO
3407	3407	8.02	APROBADO
3408	3408	7.39	APROBADO
3409	3409	9.13	APROBADO
3410	3410	7.66	APROBADO
3411	3411	7.68	APROBADO
3412	3412	9.19	APROBADO
3413	3413	8.58	APROBADO
3414	3414	7.20	APROBADO
3415	3415	8.37	APROBADO
3416	3416	8.17	APROBADO
3417	3417	9.68	APROBADO
3418	3418	8.28	APROBADO
3419	3419	8.80	APROBADO
3420	3420	8.14	APROBADO
3421	3421	9.11	APROBADO
3422	3422	8.42	APROBADO
3423	3423	8.85	APROBADO
3424	3424	9.72	APROBADO
3425	3425	9.13	APROBADO
3426	3426	8.51	APROBADO
3427	3427	9.47	APROBADO
3428	3428	9.19	APROBADO
3429	3429	9.75	APROBADO
3430	3430	7.38	APROBADO
3431	3431	9.57	APROBADO
3432	3432	9.34	APROBADO
3433	3433	8.96	APROBADO
3434	3434	7.84	APROBADO
3435	3435	7.16	APROBADO
3436	3436	7.10	APROBADO
3437	3437	7.84	APROBADO
3438	3438	10.00	APROBADO
3439	3439	8.88	APROBADO
3440	3440	9.84	APROBADO
3441	3441	9.97	APROBADO
3442	3442	8.62	APROBADO
3443	3443	9.55	APROBADO
3444	3444	8.76	APROBADO
3445	3445	7.63	APROBADO
3446	3446	9.92	APROBADO
3447	3447	9.37	APROBADO
3448	3448	7.98	APROBADO
3449	3449	7.25	APROBADO
3450	3450	8.82	APROBADO
3451	3451	7.63	APROBADO
3452	3452	7.68	APROBADO
3453	3453	7.03	APROBADO
3454	3454	9.80	APROBADO
3455	3455	8.02	APROBADO
3456	3456	8.58	APROBADO
3457	3457	9.01	APROBADO
3458	3458	8.80	APROBADO
3459	3459	7.37	APROBADO
3460	3460	9.83	APROBADO
3461	3461	7.05	APROBADO
3462	3462	8.56	APROBADO
3463	3463	8.69	APROBADO
3464	3464	9.13	APROBADO
3465	3465	7.53	APROBADO
3466	3466	7.51	APROBADO
3467	3467	8.85	APROBADO
3468	3468	7.74	APROBADO
3469	3469	7.61	APROBADO
3470	3470	9.72	APROBADO
3471	3471	7.99	APROBADO
3472	3472	8.83	APROBADO
3473	3473	9.22	APROBADO
3474	3474	7.81	APROBADO
3475	3475	9.12	APROBADO
3476	3476	9.01	APROBADO
3477	3477	8.62	APROBADO
3478	3478	8.01	APROBADO
3479	3479	8.50	APROBADO
3480	3480	9.21	APROBADO
3481	3481	7.15	APROBADO
3482	3482	9.44	APROBADO
3483	3483	9.87	APROBADO
3484	3484	9.62	APROBADO
3485	3485	8.99	APROBADO
3486	3486	7.99	APROBADO
3487	3487	9.03	APROBADO
3488	3488	8.01	APROBADO
3489	3489	7.88	APROBADO
3490	3490	8.51	APROBADO
3491	3491	7.35	APROBADO
3492	3492	7.20	APROBADO
3493	3493	7.34	APROBADO
3494	3494	8.83	APROBADO
3495	3495	8.94	APROBADO
3496	3496	7.43	APROBADO
3497	3497	8.90	APROBADO
3498	3498	7.15	APROBADO
3499	3499	9.98	APROBADO
3500	3500	8.31	APROBADO
3501	3501	8.90	APROBADO
3502	3502	8.36	APROBADO
3503	3503	8.02	APROBADO
3504	3504	9.86	APROBADO
3505	3505	7.16	APROBADO
3506	3506	8.63	APROBADO
3507	3507	9.86	APROBADO
3508	3508	7.23	APROBADO
3509	3509	9.78	APROBADO
3510	3510	9.95	APROBADO
3511	3511	9.16	APROBADO
3512	3512	8.24	APROBADO
3513	3513	9.05	APROBADO
3514	3514	7.06	APROBADO
3515	3515	7.23	APROBADO
3516	3516	9.68	APROBADO
3517	3517	8.89	APROBADO
3518	3518	7.31	APROBADO
3519	3519	8.60	APROBADO
3520	3520	7.24	APROBADO
3521	3521	8.44	APROBADO
3522	3522	9.94	APROBADO
3523	3523	8.48	APROBADO
3524	3524	9.64	APROBADO
3525	3525	8.70	APROBADO
3526	3526	9.48	APROBADO
3527	3527	7.78	APROBADO
3528	3528	9.72	APROBADO
3529	3529	8.19	APROBADO
3530	3530	7.68	APROBADO
3531	3531	8.79	APROBADO
3532	3532	8.14	APROBADO
3533	3533	7.60	APROBADO
3534	3534	8.16	APROBADO
3535	3535	7.60	APROBADO
3536	3536	7.02	APROBADO
3537	3537	7.23	APROBADO
3538	3538	7.41	APROBADO
3539	3539	8.36	APROBADO
3540	3540	8.61	APROBADO
3541	3541	8.04	APROBADO
3542	3542	7.78	APROBADO
3543	3543	7.76	APROBADO
3544	3544	9.89	APROBADO
3545	3545	7.04	APROBADO
3546	3546	8.48	APROBADO
3547	3547	7.34	APROBADO
3548	3548	8.81	APROBADO
3549	3549	9.69	APROBADO
3550	3550	7.08	APROBADO
3551	3551	7.63	APROBADO
3552	3552	9.84	APROBADO
3553	3553	8.39	APROBADO
3554	3554	7.71	APROBADO
3555	3555	7.12	APROBADO
3556	3556	7.30	APROBADO
3557	3557	7.76	APROBADO
3558	3558	8.30	APROBADO
3559	3559	7.14	APROBADO
3560	3560	9.29	APROBADO
3561	3561	9.04	APROBADO
3562	3562	9.07	APROBADO
3563	3563	8.42	APROBADO
3564	3564	7.13	APROBADO
3565	3565	8.09	APROBADO
3566	3566	7.60	APROBADO
3567	3567	7.97	APROBADO
3568	3568	9.89	APROBADO
3569	3569	8.48	APROBADO
3570	3570	7.90	APROBADO
3571	3571	7.41	APROBADO
3572	3572	9.62	APROBADO
3573	3573	9.20	APROBADO
3574	3574	8.17	APROBADO
3575	3575	9.31	APROBADO
3576	3576	8.14	APROBADO
3577	3577	7.82	APROBADO
3578	3578	8.78	APROBADO
3579	3579	8.11	APROBADO
3580	3580	9.09	APROBADO
3581	3581	7.57	APROBADO
3582	3582	8.91	APROBADO
3583	3583	7.79	APROBADO
3584	3584	7.38	APROBADO
3585	3585	8.91	APROBADO
3586	3586	8.78	APROBADO
3587	3587	8.56	APROBADO
3588	3588	8.88	APROBADO
3589	3589	7.80	APROBADO
3590	3590	8.27	APROBADO
3591	3591	7.63	APROBADO
3592	3592	8.63	APROBADO
3593	3593	9.49	APROBADO
3594	3594	7.06	APROBADO
3595	3595	7.22	APROBADO
3596	3596	8.15	APROBADO
3597	3597	7.04	APROBADO
3598	3598	7.17	APROBADO
3599	3599	9.85	APROBADO
3600	3600	9.37	APROBADO
3601	3601	7.80	APROBADO
3602	3602	7.04	APROBADO
3603	3603	8.27	APROBADO
3604	3604	7.16	APROBADO
3605	3605	7.03	APROBADO
3606	3606	8.18	APROBADO
3607	3607	8.01	APROBADO
3608	3608	9.03	APROBADO
3609	3609	7.20	APROBADO
3610	3610	8.52	APROBADO
3611	3611	7.77	APROBADO
3612	3612	9.50	APROBADO
3613	3613	9.47	APROBADO
3614	3614	8.96	APROBADO
3615	3615	8.98	APROBADO
3616	3616	9.20	APROBADO
3617	3617	8.75	APROBADO
3618	3618	9.30	APROBADO
3619	3619	7.49	APROBADO
3620	3620	9.12	APROBADO
3621	3621	8.40	APROBADO
3622	3622	8.22	APROBADO
3623	3623	9.51	APROBADO
3624	3624	9.04	APROBADO
3625	3625	8.20	APROBADO
3626	3626	7.92	APROBADO
3627	3627	9.25	APROBADO
3628	3628	8.69	APROBADO
3629	3629	8.75	APROBADO
3630	3630	7.91	APROBADO
3631	3631	7.08	APROBADO
3632	3632	8.89	APROBADO
3633	3633	9.47	APROBADO
3634	3634	8.97	APROBADO
3635	3635	9.50	APROBADO
3636	3636	7.30	APROBADO
3637	3637	7.72	APROBADO
3638	3638	9.33	APROBADO
3639	3639	8.16	APROBADO
3640	3640	7.16	APROBADO
3641	3641	9.91	APROBADO
3642	3642	8.50	APROBADO
3643	3643	8.80	APROBADO
3644	3644	10.00	APROBADO
3645	3645	9.18	APROBADO
3646	3646	8.43	APROBADO
3647	3647	7.03	APROBADO
3648	3648	8.32	APROBADO
3649	3649	8.12	APROBADO
3650	3650	7.77	APROBADO
3651	3651	8.99	APROBADO
3652	3652	8.44	APROBADO
3653	3653	8.30	APROBADO
3654	3654	9.73	APROBADO
3655	3655	7.79	APROBADO
3656	3656	8.83	APROBADO
3657	3657	7.35	APROBADO
3658	3658	8.52	APROBADO
3659	3659	9.14	APROBADO
3660	3660	7.83	APROBADO
3661	3661	8.34	APROBADO
3662	3662	7.77	APROBADO
3663	3663	9.52	APROBADO
3664	3664	9.30	APROBADO
3665	3665	8.21	APROBADO
3666	3666	8.21	APROBADO
3667	3667	8.65	APROBADO
3668	3668	9.61	APROBADO
3669	3669	8.34	APROBADO
3670	3670	7.71	APROBADO
3671	3671	7.97	APROBADO
3672	3672	9.19	APROBADO
3673	3673	8.35	APROBADO
3674	3674	9.58	APROBADO
3675	3675	8.72	APROBADO
3676	3676	7.48	APROBADO
3677	3677	8.51	APROBADO
3678	3678	9.22	APROBADO
3679	3679	9.71	APROBADO
3680	3680	7.36	APROBADO
3681	3681	8.71	APROBADO
3682	3682	9.14	APROBADO
3683	3683	9.98	APROBADO
3684	3684	9.89	APROBADO
3685	3685	9.36	APROBADO
3686	3686	9.34	APROBADO
3687	3687	8.33	APROBADO
3688	3688	8.97	APROBADO
3689	3689	9.88	APROBADO
3690	3690	9.17	APROBADO
3691	3691	9.76	APROBADO
3692	3692	7.63	APROBADO
3693	3693	8.22	APROBADO
3694	3694	9.03	APROBADO
3695	3695	9.29	APROBADO
3696	3696	9.61	APROBADO
3697	3697	8.04	APROBADO
3698	3698	7.62	APROBADO
3699	3699	7.80	APROBADO
3700	3700	8.71	APROBADO
3701	3701	7.08	APROBADO
3702	3702	9.27	APROBADO
3703	3703	9.05	APROBADO
3704	3704	8.24	APROBADO
3705	3705	7.72	APROBADO
3706	3706	8.46	APROBADO
3707	3707	9.71	APROBADO
3708	3708	8.75	APROBADO
3709	3709	8.00	APROBADO
3710	3710	7.59	APROBADO
3711	3711	7.17	APROBADO
3712	3712	7.62	APROBADO
3713	3713	7.76	APROBADO
3714	3714	7.56	APROBADO
3715	3715	7.29	APROBADO
3716	3716	8.93	APROBADO
3717	3717	7.40	APROBADO
3718	3718	9.28	APROBADO
3719	3719	7.46	APROBADO
3720	3720	8.46	APROBADO
3721	3721	7.59	APROBADO
3722	3722	8.41	APROBADO
3723	3723	7.61	APROBADO
3724	3724	8.67	APROBADO
3725	3725	9.22	APROBADO
3726	3726	8.40	APROBADO
3727	3727	9.27	APROBADO
3728	3728	7.48	APROBADO
3729	3729	8.59	APROBADO
3730	3730	7.17	APROBADO
3731	3731	9.18	APROBADO
3732	3732	9.72	APROBADO
3733	3733	8.23	APROBADO
3734	3734	8.66	APROBADO
3735	3735	8.86	APROBADO
3736	3736	7.57	APROBADO
3737	3737	7.14	APROBADO
3738	3738	8.56	APROBADO
3739	3739	7.47	APROBADO
3740	3740	8.79	APROBADO
3741	3741	7.69	APROBADO
3742	3742	7.41	APROBADO
3743	3743	8.79	APROBADO
3744	3744	9.97	APROBADO
3745	3745	8.51	APROBADO
3746	3746	7.56	APROBADO
3747	3747	9.10	APROBADO
3748	3748	9.86	APROBADO
3749	3749	9.18	APROBADO
3750	3750	8.74	APROBADO
3751	3751	9.34	APROBADO
3752	3752	7.18	APROBADO
3753	3753	9.26	APROBADO
3754	3754	8.24	APROBADO
3755	3755	7.36	APROBADO
3756	3756	9.40	APROBADO
3757	3757	8.58	APROBADO
3758	3758	7.55	APROBADO
3759	3759	9.26	APROBADO
3760	3760	9.93	APROBADO
3761	3761	8.30	APROBADO
3762	3762	9.85	APROBADO
3763	3763	9.28	APROBADO
3764	3764	7.46	APROBADO
3765	3765	7.95	APROBADO
3766	3766	9.55	APROBADO
3767	3767	8.83	APROBADO
3768	3768	9.28	APROBADO
3769	3769	8.35	APROBADO
3770	3770	8.31	APROBADO
3771	3771	9.87	APROBADO
3772	3772	8.98	APROBADO
3773	3773	9.40	APROBADO
3774	3774	8.20	APROBADO
3775	3775	9.95	APROBADO
3776	3776	8.00	APROBADO
3777	3777	7.62	APROBADO
3778	3778	9.30	APROBADO
3779	3779	9.56	APROBADO
3780	3780	8.50	APROBADO
3781	3781	9.33	APROBADO
3782	3782	7.48	APROBADO
3783	3783	9.50	APROBADO
3784	3784	9.99	APROBADO
3785	3785	9.10	APROBADO
3786	3786	9.82	APROBADO
3787	3787	8.35	APROBADO
3788	3788	7.57	APROBADO
3789	3789	8.83	APROBADO
3790	3790	9.75	APROBADO
3791	3791	8.12	APROBADO
3792	3792	9.13	APROBADO
3793	3793	9.83	APROBADO
3794	3794	8.09	APROBADO
3795	3795	9.98	APROBADO
3796	3796	9.82	APROBADO
3797	3797	9.55	APROBADO
3798	3798	8.96	APROBADO
3799	3799	7.55	APROBADO
3800	3800	8.21	APROBADO
3801	3801	7.25	APROBADO
3802	3802	8.32	APROBADO
3803	3803	8.28	APROBADO
3804	3804	8.78	APROBADO
3805	3805	9.69	APROBADO
3806	3806	7.97	APROBADO
3807	3807	8.92	APROBADO
3808	3808	8.97	APROBADO
3809	3809	8.11	APROBADO
3810	3810	9.21	APROBADO
3811	3811	7.87	APROBADO
3812	3812	8.13	APROBADO
3813	3813	9.48	APROBADO
3814	3814	9.36	APROBADO
3815	3815	7.68	APROBADO
3816	3816	9.83	APROBADO
3817	3817	7.35	APROBADO
3818	3818	8.09	APROBADO
3819	3819	8.90	APROBADO
3820	3820	8.51	APROBADO
3821	3821	8.74	APROBADO
3822	3822	7.88	APROBADO
3823	3823	7.33	APROBADO
3824	3824	7.59	APROBADO
3825	3825	7.10	APROBADO
3826	3826	8.74	APROBADO
3827	3827	8.74	APROBADO
3828	3828	8.60	APROBADO
3829	3829	8.34	APROBADO
3830	3830	8.30	APROBADO
3831	3831	9.06	APROBADO
3832	3832	7.92	APROBADO
3833	3833	7.29	APROBADO
3834	3834	7.60	APROBADO
3835	3835	7.39	APROBADO
3836	3836	8.50	APROBADO
3837	3837	7.75	APROBADO
3838	3838	9.18	APROBADO
3839	3839	7.01	APROBADO
3840	3840	7.74	APROBADO
3841	3841	9.83	APROBADO
3842	3842	7.59	APROBADO
3843	3843	8.57	APROBADO
3844	3844	7.02	APROBADO
3845	3845	8.63	APROBADO
3846	3846	8.79	APROBADO
3847	3847	9.87	APROBADO
3848	3848	7.42	APROBADO
3849	3849	8.50	APROBADO
3850	3850	9.05	APROBADO
3851	3851	8.58	APROBADO
3852	3852	7.72	APROBADO
3853	3853	8.21	APROBADO
3854	3854	9.02	APROBADO
3855	3855	9.99	APROBADO
3856	3856	7.03	APROBADO
3857	3857	7.22	APROBADO
3858	3858	7.33	APROBADO
3859	3859	7.37	APROBADO
3860	3860	9.60	APROBADO
3861	3861	7.64	APROBADO
3862	3862	8.58	APROBADO
3863	3863	9.77	APROBADO
3864	3864	7.66	APROBADO
3865	3865	8.04	APROBADO
3866	3866	8.85	APROBADO
3867	3867	8.90	APROBADO
3868	3868	9.44	APROBADO
3869	3869	8.98	APROBADO
3870	3870	8.98	APROBADO
3871	3871	8.09	APROBADO
3872	3872	9.79	APROBADO
3873	3873	9.50	APROBADO
3874	3874	9.84	APROBADO
3875	3875	7.78	APROBADO
3876	3876	7.61	APROBADO
3877	3877	7.84	APROBADO
3878	3878	8.22	APROBADO
3879	3879	7.19	APROBADO
3880	3880	8.54	APROBADO
3881	3881	8.42	APROBADO
3882	3882	9.06	APROBADO
3883	3883	7.23	APROBADO
3884	3884	8.96	APROBADO
3885	3885	8.43	APROBADO
3886	3886	7.58	APROBADO
3887	3887	9.93	APROBADO
3888	3888	9.17	APROBADO
3889	3889	7.13	APROBADO
3890	3890	8.23	APROBADO
3891	3891	8.41	APROBADO
3892	3892	8.37	APROBADO
3893	3893	8.03	APROBADO
3894	3894	7.42	APROBADO
3895	3895	9.74	APROBADO
3896	3896	9.25	APROBADO
3897	3897	9.99	APROBADO
3898	3898	9.95	APROBADO
3899	3899	7.91	APROBADO
3900	3900	9.34	APROBADO
3901	3901	8.67	APROBADO
3902	3902	8.53	APROBADO
3903	3903	7.83	APROBADO
3904	3904	9.81	APROBADO
3905	3905	8.68	APROBADO
3906	3906	7.57	APROBADO
3907	3907	7.42	APROBADO
3908	3908	9.63	APROBADO
3909	3909	8.76	APROBADO
3910	3910	8.54	APROBADO
3911	3911	8.51	APROBADO
3912	3912	8.42	APROBADO
3913	3913	7.98	APROBADO
3914	3914	8.30	APROBADO
3915	3915	8.25	APROBADO
3916	3916	8.03	APROBADO
3917	3917	8.30	APROBADO
3918	3918	9.68	APROBADO
3919	3919	8.49	APROBADO
3920	3920	8.33	APROBADO
3921	3921	9.18	APROBADO
3922	3922	7.58	APROBADO
3923	3923	7.88	APROBADO
3924	3924	7.98	APROBADO
3925	3925	7.64	APROBADO
3926	3926	9.04	APROBADO
3927	3927	9.28	APROBADO
3928	3928	7.63	APROBADO
3929	3929	7.38	APROBADO
3930	3930	9.46	APROBADO
3931	3931	8.43	APROBADO
3932	3932	9.78	APROBADO
3933	3933	8.75	APROBADO
3934	3934	8.29	APROBADO
3935	3935	9.48	APROBADO
3936	3936	8.16	APROBADO
3937	3937	7.66	APROBADO
3938	3938	7.87	APROBADO
3939	3939	8.66	APROBADO
3940	3940	9.29	APROBADO
3941	3941	7.32	APROBADO
3942	3942	9.37	APROBADO
3943	3943	7.94	APROBADO
3944	3944	7.47	APROBADO
3945	3945	9.52	APROBADO
3946	3946	9.77	APROBADO
3947	3947	8.63	APROBADO
3948	3948	9.81	APROBADO
3949	3949	9.43	APROBADO
3950	3950	8.82	APROBADO
3951	3951	9.00	APROBADO
3952	3952	9.44	APROBADO
3953	3953	9.16	APROBADO
3954	3954	8.90	APROBADO
3955	3955	8.12	APROBADO
3956	3956	9.56	APROBADO
3957	3957	9.77	APROBADO
3958	3958	8.58	APROBADO
3959	3959	8.02	APROBADO
3960	3960	7.40	APROBADO
3961	3961	7.70	APROBADO
3962	3962	8.27	APROBADO
3963	3963	7.00	APROBADO
3964	3964	7.18	APROBADO
3965	3965	7.15	APROBADO
3966	3966	9.02	APROBADO
3967	3967	7.58	APROBADO
3968	3968	9.69	APROBADO
3969	3969	9.85	APROBADO
3970	3970	7.37	APROBADO
3971	3971	9.42	APROBADO
3972	3972	9.90	APROBADO
3973	3973	7.73	APROBADO
3974	3974	9.74	APROBADO
3975	3975	8.59	APROBADO
3976	3976	9.08	APROBADO
3977	3977	7.70	APROBADO
3978	3978	9.05	APROBADO
3979	3979	9.43	APROBADO
3980	3980	7.23	APROBADO
3981	3981	7.84	APROBADO
3982	3982	7.04	APROBADO
3983	3983	8.02	APROBADO
3984	3984	7.70	APROBADO
3985	3985	9.30	APROBADO
3986	3986	9.79	APROBADO
3987	3987	8.78	APROBADO
3988	3988	9.45	APROBADO
3989	3989	9.66	APROBADO
3990	3990	7.84	APROBADO
3991	3991	9.79	APROBADO
3992	3992	9.27	APROBADO
3993	3993	7.71	APROBADO
3994	3994	9.49	APROBADO
3995	3995	8.94	APROBADO
3996	3996	7.85	APROBADO
3997	3997	9.26	APROBADO
3998	3998	7.69	APROBADO
3999	3999	9.67	APROBADO
4000	4000	7.32	APROBADO
\.


--
-- Data for Name: escuelas; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.escuelas (id_escuela, id_facultad, nombre, descripcion, logo_url, semestres, carrera) FROM stdin;
13	5	Escuela de Administración	Formación en gestión empresarial.	https://www.ejemplo.com/logos/administracion.png	10	Administración de Empresas
14	5	Escuela de Contabilidad	Análisis financiero y control de cuentas.	https://www.ejemplo.com/logos/contabilidad.png	10	Contaduría Pública
1	1	Escuela de Ingeniería Civil	Formación en construcción y estructuras.	https://www.ejemplo.com/logos/ing_civil.png	10	Ingeniería Civil
4	2	Escuela de Matemáticas	Investigación y docencia en matemáticas puras y aplicadas.	https://www.ejemplo.com/logos/matematicas.png	10	Licenciatura en Matemáticas
5	2	Escuela de Física	Estudios en mecánica cuántica, relatividad y más.	https://www.ejemplo.com/logos/fisica.png	10	Licenciatura en Física
6	2	Escuela de Química	Investigación en química orgánica e inorgánica.	https://www.ejemplo.com/logos/quimica.png	10	Licenciatura en Química
7	3	Escuela de Medicina General	Formación en diagnóstico y tratamiento de enfermedades.	https://www.ejemplo.com/logos/medicina_general.png	10	Licenciatura en Medicina
9	3	Escuela de Nutrición	Investigación en dietética y salud alimentaria.	https://www.ejemplo.com/logos/nutricion.png	10	Licenciatura en Nutrición
15	5	Escuela de Finanzas	Estudios de inversión, mercados y banca.	https://www.ejemplo.com/logos/finanzas.png	10	Licenciatura en Finanzas
16	6	Escuela de Historia	Investigación sobre hechos históricos y su impacto.	https://www.ejemplo.com/logos/historia.png	10	Licenciatura en Historia
10	4	Escuela de Derecho Penal	Estudios sobre criminología y justicia penal.	https://www.ejemplo.com/logos/derecho_penal.png	10	Licenciatura en Derecho Penal
11	4	Escuela de Derecho Civil	Especialización en normativas civiles y comerciales.	https://www.ejemplo.com/logos/derecho_civil.png	10	Licenciatura en Derecho Civil
8	3	Escuela de Enfermería	Atención y cuidado de pacientes en diferentes entornos.	https://www.ejemplo.com/logos/enfermeria.png	10	 Licenciatura en Enfermería
19	7	Escuela de Desarrollo de Software	Programación, bases de datos y arquitectura de software.	https://www.ejemplo.com/logos/desarrollo_software.png	10	 Ingeniería en Desarrollo de Software
20	7	Escuela de Inteligencia Artificial	Aprendizaje automático y redes neuronales.	https://www.ejemplo.com/logos/inteligencia_artificial.png	10	Ingeniería en Inteligencia Artificial
22	8	Escuela de Diseño Urbano	Planeamiento y desarrollo de ciudades.	https://www.ejemplo.com/logos/diseno_urbano.png	10	Diseño Urbano
23	8	Escuela de Arquitectura Sostenible	Construcciones ecológicas y amigables con el medio ambiente.	https://www.ejemplo.com/logos/arquitectura_sostenible.png	10	Arquitectura con enfoque en sostenibilidad
24	8	Escuela de Patrimonio Arquitectónico	Conservación de edificaciones históricas.	https://www.ejemplo.com/logos/patrimonio_arquitectonico.png	10	Restauración y Conservación del Patrimonio Arquitectónico
25	9	Escuela de Sociología	Estudio de la estructura y dinámica social.	https://www.ejemplo.com/logos/sociologia.png	10	Sociología
26	9	Escuela de Antropología	Investigación sobre la evolución cultural y biológica humana.	https://www.ejemplo.com/logos/antropologia.png	10	Antropología
27	9	Escuela de Relaciones Internacionales	Análisis de políticas y diplomacia global.	https://www.ejemplo.com/logos/relaciones_internacionales.png	10	Relaciones Internacionales
28	10	Escuela de Música	Formación en composición, producción y ejecución musical.	https://www.ejemplo.com/logos/musica.png	10	Música
29	10	Escuela de Artes Visuales	Estudios en pintura, escultura y diseño gráfico.	https://www.ejemplo.com/logos/artes_visuales.png	10	Artes Visuales
30	10	Escuela de Cine y Teatro	Formación en actuación, dirección y producción audiovisual.	https://www.ejemplo.com/logos/cine_teatro.png	10	Cine y Artes Escénicas
2	1	Escuela de Ingeniería Mecánica	Diseño y mantenimiento de sistemas mecánicos.	https://www.ejemplo.com/logos/ing_mecanica.png	10	Ingeniería Mecánica
3	1	Escuela de Ingeniería Electrónica	Estudios en circuitos, telecomunicaciones y más.	https://www.ejemplo.com/logos/ing_electronica.png	10	 Ingeniería Electrónica
12	4	Escuela de Derecho Internacional	Análisis de tratados y relaciones jurídicas globales.	https://www.ejemplo.com/logos/derecho_internacional.png	10	Derecho con especialización en Derecho Internacional\nEscuela de Filosofía
17	6	Escuela de Filosofía	Estudio del pensamiento humano y la lógica.	https://www.ejemplo.com/logos/filosofia.png	10	Filosofía
21	7	Escuela de Redes y Telecomunicaciones	Protección de sistemas y redes de información.	https://www.ejemplo.com/logos/ciberseguridad.png	10	Ingeniería en Redes y Telecomunicaciones
18	6	Escuela de Letras	Análisis y producción literaria en diversas lenguas.	https://www.ejemplo.com/logos/letras.png	10	Literatura o Filología
\.


--
-- Data for Name: estudiantes; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.estudiantes (id_estudiante, nombre, apellido, matricula, correo, fecha_nacimiento, direccion, identificacion) FROM stdin;
1	Juan	Pérez	20240001	juan.perez@utf.edu	2002-05-14	Av. Siempre Viva 123	ID20240001
2	María	López	20240002	maria.lopez@utf.edu	2001-09-22	Calle Falsa 456	ID20240002
3	Carlos	Gómez	20240003	carlos.gomez@utf.edu	2003-07-30	Boulevard Central 789	ID20240003
4	Ana	Torres	20240004	ana.torres@utf.edu	2002-03-10	Pasaje Los Cedros 234	ID20240004
5	Luis	Ramírez	20240005	luis.ramirez@utf.edu	2001-12-18	Callejón del Sol 567	ID20240005
6	Elena	Martínez	20240006	elena.martinez@utf.edu	2003-06-25	Av. Los Álamos 890	ID20240006
7	Pedro	Fernández	20240007	pedro.fernandez@utf.edu	2002-08-05	Carrera 45 #23-10	ID20240007
8	Lucía	Díaz	20240008	lucia.diaz@utf.edu	2001-11-15	Calle Primavera 321	ID20240008
9	Javier	Hernández	20240009	javier.hernandez@utf.edu	2003-02-28	Vía Láctea 654	ID20240009
10	Sofía	Castro	20240010	sofia.castro@utf.edu	2002-04-12	Camino del Lago 987	ID20240010
11	Fernando	García	20240011	fernando.garcia@utf.edu	2001-10-05	Avenida Libertador 456	ID20240011
12	Gabriela	Muñoz	20240012	gabriela.munoz@utf.edu	2003-01-20	Paseo de las Palmas 789	ID20240012
13	Ricardo	Ortega	20240013	ricardo.ortega@utf.edu	2002-06-14	Carrera 23 #45-67	ID20240013
14	Valeria	Suárez	20240014	valeria.suarez@utf.edu	2001-08-30	Callejón del Bosque 101	ID20240014
15	Diego	Núñez	20240015	diego.nunez@utf.edu	2003-09-12	Urbanización La Fuente 222	ID20240015
16	Camila	Herrera	20240016	camila.herrera@utf.edu	2002-11-07	Residencial El Sol 333	ID20240016
17	Alejandro	Mendoza	20240017	alejandro.mendoza@utf.edu	2001-04-15	Barrio Central 444	ID20240017
18	Isabela	Cruz	20240018	isabela.cruz@utf.edu	2003-12-03	Colonia Jardines 555	ID20240018
19	Manuel	Reyes	20240019	manuel.reyes@utf.edu	2002-07-21	Vía Principal 666	ID20240019
20	Andrea	Vargas	20240020	andrea.vargas@utf.edu	2001-02-28	Pasaje Colonial 777	ID20240020
21	Paola	Silva	20240099	paola.silva@utf.edu	2003-10-10	Calle Estrella 898	ID20240099
22	Tomás	Delgado	20240100	tomas.delgado@utf.edu	2002-01-29	Residencial Primavera 999	ID20240100
23	Miguel	Santos	20240101	miguel.santos@utf.edu	2002-08-14	Calle del Río 123	ID20240101
24	Diana	Ortega	20240102	diana.ortega@utf.edu	2001-11-22	Avenida Central 456	ID20240102
25	Roberto	Vega	20240103	roberto.vega@utf.edu	2003-05-30	Pasaje Primavera 789	ID20240103
26	Laura	Campos	20240104	laura.campos@utf.edu	2002-02-10	Residencial Los Pinos 234	ID20240104
27	Andrés	León	20240105	andres.leon@utf.edu	2001-09-18	Callejón del Sol 567	ID20240105
28	Patricia	Morales	20240106	patricia.morales@utf.edu	2003-06-25	Urbanización Las Palmas 890	ID20240106
29	Esteban	Salas	20240107	esteban.salas@utf.edu	2002-07-05	Avenida Siempre Viva 678	ID20240107
30	Monica	Rojas	20240108	monica.rojas@utf.edu	2001-12-15	Calle del Bosque 321	ID20240108
31	Daniel	Cabrera	20240109	daniel.cabrera@utf.edu	2003-03-28	Vía Láctea 654	ID20240109
32	Verónica	Hidalgo	20240110	veronica.hidalgo@utf.edu	2002-04-12	Camino del Lago 987	ID20240110
33	Emiliano	Fuentes	20240111	emiliano.fuentes@utf.edu	2001-10-05	Avenida Libertador 456	ID20240111
34	Natalia	Sierra	20240112	natalia.sierra@utf.edu	2003-01-20	Paseo de las Rosas 789	ID20240112
35	Hugo	Navarro	20240113	hugo.navarro@utf.edu	2002-06-14	Carrera 23 #45-67	ID20240113
36	Liliana	Peña	20240114	liliana.pena@utf.edu	2001-08-30	Callejón de los Cedros 101	ID20240114
37	Ramón	Esquivel	20240115	ramon.esquivel@utf.edu	2003-09-12	Barrio San Juan 222	ID20240115
38	Beatriz	Fajardo	20240116	beatriz.fajardo@utf.edu	2002-11-07	Residencial El Sol 333	ID20240116
39	Cristian	Benítez	20240117	cristian.benitez@utf.edu	2001-04-15	Avenida Universitaria 444	ID20240117
40	Fabiola	Lara	20240118	fabiola.lara@utf.edu	2003-12-03	Colonia Jardines 555	ID20240118
41	Raúl	Ponce	20240119	raul.ponce@utf.edu	2002-07-21	Calle Principal 666	ID20240119
42	Elisa	Bermúdez	20240120	elisa.bermudez@utf.edu	2001-02-28	Pasaje Colonial 777	ID20240120
43	Mauricio	López	20240121	mauricio.lopez@utf.edu	2002-07-18	Calle Principal 101	ID20240121
44	Rosa	Maldonado	20240122	rosa.maldonado@utf.edu	2001-05-22	Avenida Central 202	ID20240122
45	Jorge	Valencia	20240123	jorge.valencia@utf.edu	2003-08-30	Residencial Primavera 303	ID20240123
46	Natalia	Guzmán	20240124	natalia.guzman@utf.edu	2002-03-10	Barrio Norte 404	ID20240124
47	Andrés	Castañeda	20240125	andres.castaneda@utf.edu	2001-12-18	Colonia del Sol 505	ID20240125
48	Paola	Miranda	20240126	paola.miranda@utf.edu	2003-06-25	Callejón de los Pinos 606	ID20240126
49	Roberto	Escobar	20240127	roberto.escobar@utf.edu	2002-07-05	Avenida Los Cedros 707	ID20240127
50	Mariana	Villalobos	20240128	mariana.villalobos@utf.edu	2001-11-15	Pasaje Colonial 808	ID20240128
51	Oscar	Mejía	20240129	oscar.mejia@utf.edu	2003-02-28	Calle del Bosque 909	ID20240129
52	Daniela	Solís	20240130	daniela.solis@utf.edu	2002-04-12	Vía Láctea 1001	ID20240130
53	Leonardo	Juárez	20240131	leonardo.juarez@utf.edu	2001-10-05	Paseo del Lago 1101	ID20240131
54	Mónica	Arévalo	20240132	monica.arevalo@utf.edu	2003-01-20	Urbanización Las Palmas 1201	ID20240132
55	Gonzalo	Rincón	20240133	gonzalo.rincon@utf.edu	2002-06-14	Carrera 12 #34-56	ID20240133
56	Valentina	Palacios	20240134	valentina.palacios@utf.edu	2001-08-30	Calle Jardines 1401	ID20240134
57	Cristian	Montes	20240135	cristian.montes@utf.edu	2003-09-12	Residencial Los Álamos 1501	ID20240135
58	Camila	Zambrano	20240136	camila.zambrano@utf.edu	2002-11-07	Avenida San Pedro 1601	ID20240136
59	Francisco	Delgado	20240137	francisco.delgado@utf.edu	2001-04-15	Colonia del Prado 1701	ID20240137
60	Isabel	Navarrete	20240138	isabel.navarrete@utf.edu	2003-12-03	Calle San Juan 1801	ID20240138
61	Héctor	Estrella	20240139	hector.estrella@utf.edu	2002-07-21	Boulevard Central 1901	ID20240139
62	Susana	Méndez	20240140	susana.mendez@utf.edu	2001-02-28	Pasaje Colón 2001	ID20240140
64	Fernando	García	20240141	fernando.garcia41@utf.edu	2002-03-14	Calle Bolívar 123	ID20240141
65	Sofía	Hernández	20240142	sofia.hernandez42@utf.edu	2001-09-22	Avenida del Sol 456	ID20240142
66	Lucas	Martínez	20240143	lucas.martinez43@utf.edu	2003-11-30	Barrio Norte 789	ID20240143
67	María	Fernández	20240144	maria.fernandez44@utf.edu	2002-05-10	Pasaje Los Pinos 234	ID20240144
68	Carlos	Torres	20240145	carlos.torres45@utf.edu	2001-12-18	Residencial Santa Fe 567	ID20240145
69	Elena	Ruiz	20240146	elena.ruiz46@utf.edu	2003-07-25	Calle Principal 890	ID20240146
70	Javier	Ortega	20240147	javier.ortega47@utf.edu	2002-08-05	Avenida Universitaria 678	ID20240147
71	Andrea	Mendoza	20240148	andrea.mendoza48@utf.edu	2001-10-15	Calle del Parque 321	ID20240148
72	Manuel	Ríos	20240149	manuel.rios49@utf.edu	2003-04-28	Vía Central 654	ID20240149
73	Claudia	Castillo	20240150	claudia.castillo50@utf.edu	2002-06-12	Camino Verde 987	ID20240150
74	Alejandro	Vargas	20240151	alejandro.vargas51@utf.edu	2001-11-05	Calle Jardines 456	ID20240151
75	Gabriela	Peña	20240152	gabriela.pena52@utf.edu	2003-02-20	Paseo de los Cedros 789	ID20240152
76	Hugo	Silva	20240153	hugo.silva53@utf.edu	2002-07-14	Carrera 23 #45-67	ID20240153
77	Liliana	López	20240154	liliana.lopez54@utf.edu	2001-09-30	Callejón de las Rosas 101	ID20240154
78	Ramiro	Figueroa	20240155	ramiro.figueroa55@utf.edu	2003-10-12	Barrio Nuevo 222	ID20240155
79	Beatriz	Romero	20240156	beatriz.romero56@utf.edu	2002-12-07	Residencial El Prado 333	ID20240156
80	Cristian	Gómez	20240157	cristian.gomez57@utf.edu	2001-05-15	Avenida Universitaria 444	ID20240157
81	Fabiola	Lara	20240158	fabiola.lara58@utf.edu	2003-09-03	Colonia Jardines 555	ID20240158
82	Raúl	Ponce	20240159	raul.ponce59@utf.edu	2002-08-21	Calle Principal 666	ID20240159
83	Elisa	Bermúdez	20240160	elisa.bermudez60@utf.edu	2001-03-28	Pasaje Colonial 777	ID20240160
84	Sebastián	Santos	20240161	sebastian.santos61@utf.edu	2002-05-19	Residencial Los Olivos 888	ID20240161
85	Camila	Zapata	20240162	camila.zapata62@utf.edu	2003-01-08	Calle Estrella 999	ID20240162
86	Rodrigo	Villalba	20240163	rodrigo.villalba63@utf.edu	2001-07-17	Avenida Bolívar 1234	ID20240163
87	Isabela	Cáceres	20240164	isabela.caceres64@utf.edu	2002-10-29	Boulevard Central 5678	ID20240164
88	Mauricio	Espinoza	20240165	mauricio.espinoza65@utf.edu	2003-11-14	Residencial Las Palmeras 7890	ID20240165
89	Paula	Suárez	20240166	paula.suarez66@utf.edu	2001-09-25	Paseo del Río 4567	ID20240166
90	Tomás	Muñoz	20240167	tomas.munoz67@utf.edu	2002-04-16	Calle del Lago 7896	ID20240167
91	Luciana	Herrera	20240168	luciana.herrera68@utf.edu	2003-02-01	Residencial del Este 1010	ID20240168
92	Diego	Paredes	20240169	diego.paredes69@utf.edu	2001-06-22	Camino Real 2222	ID20240169
93	Jazmín	Villarreal	20240170	jazmin.villarreal70@utf.edu	2002-08-05	Colonia Bella Vista 3333	ID20240170
94	Martín	Benítez	20240171	martin.benitez71@utf.edu	2003-12-09	Carrera del Sol 4444	ID20240171
95	Valeria	Salazar	20240172	valeria.salazar72@utf.edu	2001-10-18	Calle Aurora 5555	ID20240172
96	Emanuel	Montoya	20240173	emanuel.montoya73@utf.edu	2002-09-13	Paseo de las Flores 6666	ID20240173
97	Catalina	Aguilera	20240174	catalina.aguilera74@utf.edu	2003-07-24	Residencial El Dorado 7777	ID20240174
98	Álvaro	Sáenz	20240175	alvaro.saenz75@utf.edu	2001-03-05	Calle Amanecer 8888	ID20240175
99	Natalia	Chávez	20240176	natalia.chavez76@utf.edu	2002-11-11	Barrio Los Laureles 9999	ID20240176
100	Pablo	Roldán	20240177	pablo.roldan77@utf.edu	2003-05-26	Avenida San Antonio 10101	ID20240177
63	Ximena	Molina	20240178	ximena.molina78@utf.edu	2001-12-30	Residencial Villa Hermosa 11111	ID20240178
\.


--
-- Data for Name: facultades; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.facultades (id_facultad, nombre, descripcion, logo_url, id_universidad) FROM stdin;
1	Facultad de Ingeniería	Formación en diversas ramas de la ingeniería.	https://www.ejemplo.com/logos/ingenieria.png	1
2	Facultad de Ciencias Exactas	Investigación en matemáticas, física y química.	https://www.ejemplo.com/logos/ciencias_exactas.png	1
3	Facultad de Medicina	Educación en salud y formación de médicos.	https://www.ejemplo.com/logos/medicina.png	1
4	Facultad de Derecho	Estudios jurídicos y formación en leyes.	https://www.ejemplo.com/logos/derecho.png	1
5	Facultad de Economía	Carreras de administración, contabilidad y finanzas.	https://www.ejemplo.com/logos/economia.png	1
6	Facultad de Humanidades	Educación en historia, filosofía y letras.	https://www.ejemplo.com/logos/humanidades.png	1
7	Facultad de Ciencias de la Computación	Desarrollo de software, inteligencia artificial y más.	https://www.ejemplo.com/logos/computacion.png	1
8	Facultad de Arquitectura	Diseño y construcción de espacios habitables.	https://www.ejemplo.com/logos/arquitectura.png	1
9	Facultad de Ciencias Sociales	Investigación en sociología, antropología y relaciones internacionales.	https://www.ejemplo.com/logos/sociales.png	1
10	Facultad de Artes	Carreras en música, pintura, cine y teatro.	https://www.ejemplo.com/logos/artes.png	1
\.


--
-- Data for Name: inscripciones; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.inscripciones (id_inscripcion, id_estudiante, id_materia, id_semestre) FROM stdin;
1	1	721	1
2	1	722	1
3	1	723	1
4	1	724	1
5	1	725	2
6	1	726	2
7	1	727	2
8	1	728	2
9	1	729	3
10	1	730	3
11	1	731	3
12	1	732	3
13	1	733	4
14	1	734	4
15	1	735	4
16	1	736	4
17	1	737	5
18	1	738	5
19	1	739	5
20	1	740	5
21	1	741	6
22	1	742	6
23	1	743	6
24	1	744	6
25	1	745	7
26	1	746	7
27	1	747	7
28	1	748	7
29	1	749	8
30	1	750	8
31	1	751	8
32	1	752	8
33	1	753	9
34	1	754	9
35	1	755	9
36	1	756	9
37	1	757	10
38	1	758	10
39	1	759	10
40	1	760	10
41	2	401	1
42	2	402	1
43	2	403	1
44	2	404	1
45	2	405	2
46	2	406	2
47	2	407	2
48	2	408	2
49	2	409	3
50	2	410	3
51	2	411	3
52	2	412	3
53	2	413	4
54	2	414	4
55	2	415	4
56	2	416	4
57	2	417	5
58	2	418	5
59	2	419	5
60	2	420	5
61	2	421	6
62	2	422	6
63	2	423	6
64	2	424	6
65	2	425	7
66	2	426	7
67	2	427	7
68	2	428	7
69	2	429	8
70	2	430	8
71	2	431	8
72	2	432	8
73	2	433	9
74	2	434	9
75	2	435	9
76	2	436	9
77	2	437	10
78	2	438	10
79	2	439	10
80	2	440	10
81	3	241	1
82	3	242	1
83	3	243	1
84	3	244	1
85	3	245	2
86	3	246	2
87	3	247	2
88	3	248	2
89	3	249	3
90	3	250	3
91	3	251	3
92	3	252	3
93	3	253	4
94	3	254	4
95	3	255	4
96	3	256	4
97	3	257	5
98	3	258	5
99	3	259	5
100	3	260	5
101	3	261	6
102	3	262	6
103	3	263	6
104	3	264	6
105	3	265	7
106	3	266	7
107	3	267	7
108	3	268	7
109	3	269	8
110	3	270	8
111	3	271	8
112	3	272	8
113	3	273	9
114	3	274	9
115	3	275	9
116	3	276	9
117	3	277	10
118	3	278	10
119	3	279	10
120	3	280	10
121	4	801	1
122	4	802	1
123	4	803	1
124	4	804	1
125	4	805	2
126	4	806	2
127	4	807	2
128	4	808	2
129	4	809	3
130	4	810	3
131	4	811	3
132	4	812	3
133	4	813	4
134	4	814	4
135	4	815	4
136	4	816	4
137	4	817	5
138	4	818	5
139	4	819	5
140	4	820	5
141	4	821	6
142	4	822	6
143	4	823	6
144	4	824	6
145	4	825	7
146	4	826	7
147	4	827	7
148	4	828	7
149	4	829	8
150	4	830	8
151	4	831	8
152	4	832	8
153	4	833	9
154	4	834	9
155	4	835	9
156	4	836	9
157	4	837	10
158	4	838	10
159	4	839	10
160	4	840	10
161	5	81	1
162	5	82	1
163	5	83	1
164	5	84	1
165	5	85	2
166	5	86	2
167	5	87	2
168	5	88	2
169	5	89	3
170	5	90	3
171	5	91	3
172	5	92	3
173	5	93	4
174	5	94	4
175	5	95	4
176	5	96	4
177	5	97	5
178	5	98	5
179	5	99	5
180	5	100	5
181	5	101	6
182	5	102	6
183	5	103	6
184	5	104	6
185	5	105	7
186	5	106	7
187	5	107	7
188	5	108	7
189	5	109	8
190	5	110	8
191	5	111	8
192	5	112	8
193	5	113	9
194	5	114	9
195	5	115	9
196	5	116	9
197	5	117	10
198	5	118	10
199	5	119	10
200	5	120	10
201	6	1041	1
202	6	1042	1
203	6	1043	1
204	6	1044	1
205	6	1045	2
206	6	1046	2
207	6	1047	2
208	6	1048	2
209	6	1049	3
210	6	1050	3
211	6	1051	3
212	6	1052	3
213	6	1053	4
214	6	1054	4
215	6	1055	4
216	6	1056	4
217	6	1057	5
218	6	1058	5
219	6	1059	5
220	6	1060	5
221	6	1061	6
222	6	1062	6
223	6	1063	6
224	6	1064	6
225	6	1065	7
226	6	1066	7
227	6	1067	7
228	6	1068	7
229	6	1069	8
230	6	1070	8
231	6	1071	8
232	6	1072	8
233	6	1073	9
234	6	1074	9
235	6	1075	9
236	6	1076	9
237	6	1077	10
238	6	1078	10
239	6	1079	10
240	6	1080	10
241	7	481	1
242	7	482	1
243	7	483	1
244	7	484	1
245	7	485	2
246	7	486	2
247	7	487	2
248	7	488	2
249	7	489	3
250	7	490	3
251	7	491	3
252	7	492	3
253	7	493	4
254	7	494	4
255	7	495	4
256	7	496	4
257	7	497	5
258	7	498	5
259	7	499	5
260	7	500	5
261	7	501	6
262	7	502	6
263	7	503	6
264	7	504	6
265	7	505	7
266	7	506	7
267	7	507	7
268	7	508	7
269	7	509	8
270	7	510	8
271	7	511	8
272	7	512	8
273	7	513	9
274	7	514	9
275	7	515	9
276	7	516	9
277	7	517	10
278	7	518	10
279	7	519	10
280	7	520	10
281	8	641	1
282	8	642	1
283	8	643	1
284	8	644	1
285	8	645	2
286	8	646	2
287	8	647	2
288	8	648	2
289	8	649	3
290	8	650	3
291	8	651	3
292	8	652	3
293	8	653	4
294	8	654	4
295	8	655	4
296	8	656	4
297	8	657	5
298	8	658	5
299	8	659	5
300	8	660	5
301	8	661	6
302	8	662	6
303	8	663	6
304	8	664	6
305	8	665	7
306	8	666	7
307	8	667	7
308	8	668	7
309	8	669	8
310	8	670	8
311	8	671	8
312	8	672	8
313	8	673	9
314	8	674	9
315	8	675	9
316	8	676	9
317	8	677	10
318	8	678	10
319	8	679	10
320	8	680	10
321	9	1	1
322	9	2	1
323	9	3	1
324	9	4	1
325	9	5	2
326	9	6	2
327	9	7	2
328	9	8	2
329	9	9	3
330	9	10	3
331	9	11	3
332	9	12	3
333	9	13	4
334	9	14	4
335	9	15	4
336	9	16	4
337	9	17	5
338	9	18	5
339	9	19	5
340	9	20	5
341	9	21	6
342	9	22	6
343	9	23	6
344	9	24	6
345	9	25	7
346	9	26	7
347	9	27	7
348	9	28	7
349	9	29	8
350	9	30	8
351	9	31	8
352	9	32	8
353	9	33	9
354	9	34	9
355	9	35	9
356	9	36	9
357	9	37	10
358	9	38	10
359	9	39	10
360	9	40	10
361	10	1161	1
362	10	1162	1
363	10	1163	1
364	10	1164	1
365	10	1165	2
366	10	1166	2
367	10	1167	2
368	10	1168	2
369	10	1169	3
370	10	1170	3
371	10	1171	3
372	10	1172	3
373	10	1173	4
374	10	1174	4
375	10	1175	4
376	10	1176	4
377	10	1177	5
378	10	1178	5
379	10	1179	5
380	10	1180	5
381	10	1181	6
382	10	1182	6
383	10	1183	6
384	10	1184	6
385	10	1185	7
386	10	1186	7
387	10	1187	7
388	10	1188	7
389	10	1189	8
390	10	1190	8
391	10	1191	8
392	10	1192	8
393	10	1193	9
394	10	1194	9
395	10	1195	9
396	10	1196	9
397	10	1197	10
398	10	1198	10
399	10	1199	10
400	10	1200	10
401	11	81	1
402	11	82	1
403	11	83	1
404	11	84	1
405	11	85	2
406	11	86	2
407	11	87	2
408	11	88	2
409	11	89	3
410	11	90	3
411	11	91	3
412	11	92	3
413	11	93	4
414	11	94	4
415	11	95	4
416	11	96	4
417	11	97	5
418	11	98	5
419	11	99	5
420	11	100	5
421	11	101	6
422	11	102	6
423	11	103	6
424	11	104	6
425	11	105	7
426	11	106	7
427	11	107	7
428	11	108	7
429	11	109	8
430	11	110	8
431	11	111	8
432	11	112	8
433	11	113	9
434	11	114	9
435	11	115	9
436	11	116	9
437	11	117	10
438	11	118	10
439	11	119	10
440	11	120	10
441	12	721	1
442	12	722	1
443	12	723	1
444	12	724	1
445	12	725	2
446	12	726	2
447	12	727	2
448	12	728	2
449	12	729	3
450	12	730	3
451	12	731	3
452	12	732	3
453	12	733	4
454	12	734	4
455	12	735	4
456	12	736	4
457	12	737	5
458	12	738	5
459	12	739	5
460	12	740	5
461	12	741	6
462	12	742	6
463	12	743	6
464	12	744	6
465	12	745	7
466	12	746	7
467	12	747	7
468	12	748	7
469	12	749	8
470	12	750	8
471	12	751	8
472	12	752	8
473	12	753	9
474	12	754	9
475	12	755	9
476	12	756	9
477	12	757	10
478	12	758	10
479	12	759	10
480	12	760	10
481	13	1081	1
482	13	1082	1
483	13	1083	1
484	13	1084	1
485	13	1085	2
486	13	1086	2
487	13	1087	2
488	13	1088	2
489	13	1089	3
490	13	1090	3
491	13	1091	3
492	13	1092	3
493	13	1093	4
494	13	1094	4
495	13	1095	4
496	13	1096	4
497	13	1097	5
498	13	1098	5
499	13	1099	5
500	13	1100	5
501	13	1101	6
502	13	1102	6
503	13	1103	6
504	13	1104	6
505	13	1105	7
506	13	1106	7
507	13	1107	7
508	13	1108	7
509	13	1109	8
510	13	1110	8
511	13	1111	8
512	13	1112	8
513	13	1113	9
514	13	1114	9
515	13	1115	9
516	13	1116	9
517	13	1117	10
518	13	1118	10
519	13	1119	10
520	13	1120	10
521	14	481	1
522	14	482	1
523	14	483	1
524	14	484	1
525	14	485	2
526	14	486	2
527	14	487	2
528	14	488	2
529	14	489	3
530	14	490	3
531	14	491	3
532	14	492	3
533	14	493	4
534	14	494	4
535	14	495	4
536	14	496	4
537	14	497	5
538	14	498	5
539	14	499	5
540	14	500	5
541	14	501	6
542	14	502	6
543	14	503	6
544	14	504	6
545	14	505	7
546	14	506	7
547	14	507	7
548	14	508	7
549	14	509	8
550	14	510	8
551	14	511	8
552	14	512	8
553	14	513	9
554	14	514	9
555	14	515	9
556	14	516	9
557	14	517	10
558	14	518	10
559	14	519	10
560	14	520	10
561	15	801	1
562	15	802	1
563	15	803	1
564	15	804	1
565	15	805	2
566	15	806	2
567	15	807	2
568	15	808	2
569	15	809	3
570	15	810	3
571	15	811	3
572	15	812	3
573	15	813	4
574	15	814	4
575	15	815	4
576	15	816	4
577	15	817	5
578	15	818	5
579	15	819	5
580	15	820	5
581	15	821	6
582	15	822	6
583	15	823	6
584	15	824	6
585	15	825	7
586	15	826	7
587	15	827	7
588	15	828	7
589	15	829	8
590	15	830	8
591	15	831	8
592	15	832	8
593	15	833	9
594	15	834	9
595	15	835	9
596	15	836	9
597	15	837	10
598	15	838	10
599	15	839	10
600	15	840	10
601	16	81	1
602	16	82	1
603	16	83	1
604	16	84	1
605	16	85	2
606	16	86	2
607	16	87	2
608	16	88	2
609	16	89	3
610	16	90	3
611	16	91	3
612	16	92	3
613	16	93	4
614	16	94	4
615	16	95	4
616	16	96	4
617	16	97	5
618	16	98	5
619	16	99	5
620	16	100	5
621	16	101	6
622	16	102	6
623	16	103	6
624	16	104	6
625	16	105	7
626	16	106	7
627	16	107	7
628	16	108	7
629	16	109	8
630	16	110	8
631	16	111	8
632	16	112	8
633	16	113	9
634	16	114	9
635	16	115	9
636	16	116	9
637	16	117	10
638	16	118	10
639	16	119	10
640	16	120	10
641	17	1001	1
642	17	1002	1
643	17	1003	1
644	17	1004	1
645	17	1005	2
646	17	1006	2
647	17	1007	2
648	17	1008	2
649	17	1009	3
650	17	1010	3
651	17	1011	3
652	17	1012	3
653	17	1013	4
654	17	1014	4
655	17	1015	4
656	17	1016	4
657	17	1017	5
658	17	1018	5
659	17	1019	5
660	17	1020	5
661	17	1021	6
662	17	1022	6
663	17	1023	6
664	17	1024	6
665	17	1025	7
666	17	1026	7
667	17	1027	7
668	17	1028	7
669	17	1029	8
670	17	1030	8
671	17	1031	8
672	17	1032	8
673	17	1033	9
674	17	1034	9
675	17	1035	9
676	17	1036	9
677	17	1037	10
678	17	1038	10
679	17	1039	10
680	17	1040	10
681	18	201	1
682	18	202	1
683	18	203	1
684	18	204	1
685	18	205	2
686	18	206	2
687	18	207	2
688	18	208	2
689	18	209	3
690	18	210	3
691	18	211	3
692	18	212	3
693	18	213	4
694	18	214	4
695	18	215	4
696	18	216	4
697	18	217	5
698	18	218	5
699	18	219	5
700	18	220	5
701	18	221	6
702	18	222	6
703	18	223	6
704	18	224	6
705	18	225	7
706	18	226	7
707	18	227	7
708	18	228	7
709	18	229	8
710	18	230	8
711	18	231	8
712	18	232	8
713	18	233	9
714	18	234	9
715	18	235	9
716	18	236	9
717	18	237	10
718	18	238	10
719	18	239	10
720	18	240	10
721	19	281	1
722	19	282	1
723	19	283	1
724	19	284	1
725	19	285	2
726	19	286	2
727	19	287	2
728	19	288	2
729	19	289	3
730	19	290	3
731	19	291	3
732	19	292	3
733	19	293	4
734	19	294	4
735	19	295	4
736	19	296	4
737	19	297	5
738	19	298	5
739	19	299	5
740	19	300	5
741	19	301	6
742	19	302	6
743	19	303	6
744	19	304	6
745	19	305	7
746	19	306	7
747	19	307	7
748	19	308	7
749	19	309	8
750	19	310	8
751	19	311	8
752	19	312	8
753	19	313	9
754	19	314	9
755	19	315	9
756	19	316	9
757	19	317	10
758	19	318	10
759	19	319	10
760	19	320	10
761	20	1081	1
762	20	1082	1
763	20	1083	1
764	20	1084	1
765	20	1085	2
766	20	1086	2
767	20	1087	2
768	20	1088	2
769	20	1089	3
770	20	1090	3
771	20	1091	3
772	20	1092	3
773	20	1093	4
774	20	1094	4
775	20	1095	4
776	20	1096	4
777	20	1097	5
778	20	1098	5
779	20	1099	5
780	20	1100	5
781	20	1101	6
782	20	1102	6
783	20	1103	6
784	20	1104	6
785	20	1105	7
786	20	1106	7
787	20	1107	7
788	20	1108	7
789	20	1109	8
790	20	1110	8
791	20	1111	8
792	20	1112	8
793	20	1113	9
794	20	1114	9
795	20	1115	9
796	20	1116	9
797	20	1117	10
798	20	1118	10
799	20	1119	10
800	20	1120	10
801	21	601	1
802	21	602	1
803	21	603	1
804	21	604	1
805	21	605	2
806	21	606	2
807	21	607	2
808	21	608	2
809	21	609	3
810	21	610	3
811	21	611	3
812	21	612	3
813	21	613	4
814	21	614	4
815	21	615	4
816	21	616	4
817	21	617	5
818	21	618	5
819	21	619	5
820	21	620	5
821	21	621	6
822	21	622	6
823	21	623	6
824	21	624	6
825	21	625	7
826	21	626	7
827	21	627	7
828	21	628	7
829	21	629	8
830	21	630	8
831	21	631	8
832	21	632	8
833	21	633	9
834	21	634	9
835	21	635	9
836	21	636	9
837	21	637	10
838	21	638	10
839	21	639	10
840	21	640	10
841	22	521	1
842	22	522	1
843	22	523	1
844	22	524	1
845	22	525	2
846	22	526	2
847	22	527	2
848	22	528	2
849	22	529	3
850	22	530	3
851	22	531	3
852	22	532	3
853	22	533	4
854	22	534	4
855	22	535	4
856	22	536	4
857	22	537	5
858	22	538	5
859	22	539	5
860	22	540	5
861	22	541	6
862	22	542	6
863	22	543	6
864	22	544	6
865	22	545	7
866	22	546	7
867	22	547	7
868	22	548	7
869	22	549	8
870	22	550	8
871	22	551	8
872	22	552	8
873	22	553	9
874	22	554	9
875	22	555	9
876	22	556	9
877	22	557	10
878	22	558	10
879	22	559	10
880	22	560	10
881	23	41	1
882	23	42	1
883	23	43	1
884	23	44	1
885	23	45	2
886	23	46	2
887	23	47	2
888	23	48	2
889	23	49	3
890	23	50	3
891	23	51	3
892	23	52	3
893	23	53	4
894	23	54	4
895	23	55	4
896	23	56	4
897	23	57	5
898	23	58	5
899	23	59	5
900	23	60	5
901	23	61	6
902	23	62	6
903	23	63	6
904	23	64	6
905	23	65	7
906	23	66	7
907	23	67	7
908	23	68	7
909	23	69	8
910	23	70	8
911	23	71	8
912	23	72	8
913	23	73	9
914	23	74	9
915	23	75	9
916	23	76	9
917	23	77	10
918	23	78	10
919	23	79	10
920	23	80	10
921	24	921	1
922	24	922	1
923	24	923	1
924	24	924	1
925	24	925	2
926	24	926	2
927	24	927	2
928	24	928	2
929	24	929	3
930	24	930	3
931	24	931	3
932	24	932	3
933	24	933	4
934	24	934	4
935	24	935	4
936	24	936	4
937	24	937	5
938	24	938	5
939	24	939	5
940	24	940	5
941	24	941	6
942	24	942	6
943	24	943	6
944	24	944	6
945	24	945	7
946	24	946	7
947	24	947	7
948	24	948	7
949	24	949	8
950	24	950	8
951	24	951	8
952	24	952	8
953	24	953	9
954	24	954	9
955	24	955	9
956	24	956	9
957	24	957	10
958	24	958	10
959	24	959	10
960	24	960	10
961	25	761	1
962	25	762	1
963	25	763	1
964	25	764	1
965	25	765	2
966	25	766	2
967	25	767	2
968	25	768	2
969	25	769	3
970	25	770	3
971	25	771	3
972	25	772	3
973	25	773	4
974	25	774	4
975	25	775	4
976	25	776	4
977	25	777	5
978	25	778	5
979	25	779	5
980	25	780	5
981	25	781	6
982	25	782	6
983	25	783	6
984	25	784	6
985	25	785	7
986	25	786	7
987	25	787	7
988	25	788	7
989	25	789	8
990	25	790	8
991	25	791	8
992	25	792	8
993	25	793	9
994	25	794	9
995	25	795	9
996	25	796	9
997	25	797	10
998	25	798	10
999	25	799	10
1000	25	800	10
1001	26	601	1
1002	26	602	1
1003	26	603	1
1004	26	604	1
1005	26	605	2
1006	26	606	2
1007	26	607	2
1008	26	608	2
1009	26	609	3
1010	26	610	3
1011	26	611	3
1012	26	612	3
1013	26	613	4
1014	26	614	4
1015	26	615	4
1016	26	616	4
1017	26	617	5
1018	26	618	5
1019	26	619	5
1020	26	620	5
1021	26	621	6
1022	26	622	6
1023	26	623	6
1024	26	624	6
1025	26	625	7
1026	26	626	7
1027	26	627	7
1028	26	628	7
1029	26	629	8
1030	26	630	8
1031	26	631	8
1032	26	632	8
1033	26	633	9
1034	26	634	9
1035	26	635	9
1036	26	636	9
1037	26	637	10
1038	26	638	10
1039	26	639	10
1040	26	640	10
1041	27	1	1
1042	27	2	1
1043	27	3	1
1044	27	4	1
1045	27	5	2
1046	27	6	2
1047	27	7	2
1048	27	8	2
1049	27	9	3
1050	27	10	3
1051	27	11	3
1052	27	12	3
1053	27	13	4
1054	27	14	4
1055	27	15	4
1056	27	16	4
1057	27	17	5
1058	27	18	5
1059	27	19	5
1060	27	20	5
1061	27	21	6
1062	27	22	6
1063	27	23	6
1064	27	24	6
1065	27	25	7
1066	27	26	7
1067	27	27	7
1068	27	28	7
1069	27	29	8
1070	27	30	8
1071	27	31	8
1072	27	32	8
1073	27	33	9
1074	27	34	9
1075	27	35	9
1076	27	36	9
1077	27	37	10
1078	27	38	10
1079	27	39	10
1080	27	40	10
1081	28	801	1
1082	28	802	1
1083	28	803	1
1084	28	804	1
1085	28	805	2
1086	28	806	2
1087	28	807	2
1088	28	808	2
1089	28	809	3
1090	28	810	3
1091	28	811	3
1092	28	812	3
1093	28	813	4
1094	28	814	4
1095	28	815	4
1096	28	816	4
1097	28	817	5
1098	28	818	5
1099	28	819	5
1100	28	820	5
1101	28	821	6
1102	28	822	6
1103	28	823	6
1104	28	824	6
1105	28	825	7
1106	28	826	7
1107	28	827	7
1108	28	828	7
1109	28	829	8
1110	28	830	8
1111	28	831	8
1112	28	832	8
1113	28	833	9
1114	28	834	9
1115	28	835	9
1116	28	836	9
1117	28	837	10
1118	28	838	10
1119	28	839	10
1120	28	840	10
1121	29	361	1
1122	29	362	1
1123	29	363	1
1124	29	364	1
1125	29	365	2
1126	29	366	2
1127	29	367	2
1128	29	368	2
1129	29	369	3
1130	29	370	3
1131	29	371	3
1132	29	372	3
1133	29	373	4
1134	29	374	4
1135	29	375	4
1136	29	376	4
1137	29	377	5
1138	29	378	5
1139	29	379	5
1140	29	380	5
1141	29	381	6
1142	29	382	6
1143	29	383	6
1144	29	384	6
1145	29	385	7
1146	29	386	7
1147	29	387	7
1148	29	388	7
1149	29	389	8
1150	29	390	8
1151	29	391	8
1152	29	392	8
1153	29	393	9
1154	29	394	9
1155	29	395	9
1156	29	396	9
1157	29	397	10
1158	29	398	10
1159	29	399	10
1160	29	400	10
1161	30	281	1
1162	30	282	1
1163	30	283	1
1164	30	284	1
1165	30	285	2
1166	30	286	2
1167	30	287	2
1168	30	288	2
1169	30	289	3
1170	30	290	3
1171	30	291	3
1172	30	292	3
1173	30	293	4
1174	30	294	4
1175	30	295	4
1176	30	296	4
1177	30	297	5
1178	30	298	5
1179	30	299	5
1180	30	300	5
1181	30	301	6
1182	30	302	6
1183	30	303	6
1184	30	304	6
1185	30	305	7
1186	30	306	7
1187	30	307	7
1188	30	308	7
1189	30	309	8
1190	30	310	8
1191	30	311	8
1192	30	312	8
1193	30	313	9
1194	30	314	9
1195	30	315	9
1196	30	316	9
1197	30	317	10
1198	30	318	10
1199	30	319	10
1200	30	320	10
1201	31	961	1
1202	31	962	1
1203	31	963	1
1204	31	964	1
1205	31	965	2
1206	31	966	2
1207	31	967	2
1208	31	968	2
1209	31	969	3
1210	31	970	3
1211	31	971	3
1212	31	972	3
1213	31	973	4
1214	31	974	4
1215	31	975	4
1216	31	976	4
1217	31	977	5
1218	31	978	5
1219	31	979	5
1220	31	980	5
1221	31	981	6
1222	31	982	6
1223	31	983	6
1224	31	984	6
1225	31	985	7
1226	31	986	7
1227	31	987	7
1228	31	988	7
1229	31	989	8
1230	31	990	8
1231	31	991	8
1232	31	992	8
1233	31	993	9
1234	31	994	9
1235	31	995	9
1236	31	996	9
1237	31	997	10
1238	31	998	10
1239	31	999	10
1240	31	1000	10
1241	32	761	1
1242	32	762	1
1243	32	763	1
1244	32	764	1
1245	32	765	2
1246	32	766	2
1247	32	767	2
1248	32	768	2
1249	32	769	3
1250	32	770	3
1251	32	771	3
1252	32	772	3
1253	32	773	4
1254	32	774	4
1255	32	775	4
1256	32	776	4
1257	32	777	5
1258	32	778	5
1259	32	779	5
1260	32	780	5
1261	32	781	6
1262	32	782	6
1263	32	783	6
1264	32	784	6
1265	32	785	7
1266	32	786	7
1267	32	787	7
1268	32	788	7
1269	32	789	8
1270	32	790	8
1271	32	791	8
1272	32	792	8
1273	32	793	9
1274	32	794	9
1275	32	795	9
1276	32	796	9
1277	32	797	10
1278	32	798	10
1279	32	799	10
1280	32	800	10
1281	33	441	1
1282	33	442	1
1283	33	443	1
1284	33	444	1
1285	33	445	2
1286	33	446	2
1287	33	447	2
1288	33	448	2
1289	33	449	3
1290	33	450	3
1291	33	451	3
1292	33	452	3
1293	33	453	4
1294	33	454	4
1295	33	455	4
1296	33	456	4
1297	33	457	5
1298	33	458	5
1299	33	459	5
1300	33	460	5
1301	33	461	6
1302	33	462	6
1303	33	463	6
1304	33	464	6
1305	33	465	7
1306	33	466	7
1307	33	467	7
1308	33	468	7
1309	33	469	8
1310	33	470	8
1311	33	471	8
1312	33	472	8
1313	33	473	9
1314	33	474	9
1315	33	475	9
1316	33	476	9
1317	33	477	10
1318	33	478	10
1319	33	479	10
1320	33	480	10
1321	34	761	1
1322	34	762	1
1323	34	763	1
1324	34	764	1
1325	34	765	2
1326	34	766	2
1327	34	767	2
1328	34	768	2
1329	34	769	3
1330	34	770	3
1331	34	771	3
1332	34	772	3
1333	34	773	4
1334	34	774	4
1335	34	775	4
1336	34	776	4
1337	34	777	5
1338	34	778	5
1339	34	779	5
1340	34	780	5
1341	34	781	6
1342	34	782	6
1343	34	783	6
1344	34	784	6
1345	34	785	7
1346	34	786	7
1347	34	787	7
1348	34	788	7
1349	34	789	8
1350	34	790	8
1351	34	791	8
1352	34	792	8
1353	34	793	9
1354	34	794	9
1355	34	795	9
1356	34	796	9
1357	34	797	10
1358	34	798	10
1359	34	799	10
1360	34	800	10
1361	35	601	1
1362	35	602	1
1363	35	603	1
1364	35	604	1
1365	35	605	2
1366	35	606	2
1367	35	607	2
1368	35	608	2
1369	35	609	3
1370	35	610	3
1371	35	611	3
1372	35	612	3
1373	35	613	4
1374	35	614	4
1375	35	615	4
1376	35	616	4
1377	35	617	5
1378	35	618	5
1379	35	619	5
1380	35	620	5
1381	35	621	6
1382	35	622	6
1383	35	623	6
1384	35	624	6
1385	35	625	7
1386	35	626	7
1387	35	627	7
1388	35	628	7
1389	35	629	8
1390	35	630	8
1391	35	631	8
1392	35	632	8
1393	35	633	9
1394	35	634	9
1395	35	635	9
1396	35	636	9
1397	35	637	10
1398	35	638	10
1399	35	639	10
1400	35	640	10
1401	36	1161	1
1402	36	1162	1
1403	36	1163	1
1404	36	1164	1
1405	36	1165	2
1406	36	1166	2
1407	36	1167	2
1408	36	1168	2
1409	36	1169	3
1410	36	1170	3
1411	36	1171	3
1412	36	1172	3
1413	36	1173	4
1414	36	1174	4
1415	36	1175	4
1416	36	1176	4
1417	36	1177	5
1418	36	1178	5
1419	36	1179	5
1420	36	1180	5
1421	36	1181	6
1422	36	1182	6
1423	36	1183	6
1424	36	1184	6
1425	36	1185	7
1426	36	1186	7
1427	36	1187	7
1428	36	1188	7
1429	36	1189	8
1430	36	1190	8
1431	36	1191	8
1432	36	1192	8
1433	36	1193	9
1434	36	1194	9
1435	36	1195	9
1436	36	1196	9
1437	36	1197	10
1438	36	1198	10
1439	36	1199	10
1440	36	1200	10
1441	37	1081	1
1442	37	1082	1
1443	37	1083	1
1444	37	1084	1
1445	37	1085	2
1446	37	1086	2
1447	37	1087	2
1448	37	1088	2
1449	37	1089	3
1450	37	1090	3
1451	37	1091	3
1452	37	1092	3
1453	37	1093	4
1454	37	1094	4
1455	37	1095	4
1456	37	1096	4
1457	37	1097	5
1458	37	1098	5
1459	37	1099	5
1460	37	1100	5
1461	37	1101	6
1462	37	1102	6
1463	37	1103	6
1464	37	1104	6
1465	37	1105	7
1466	37	1106	7
1467	37	1107	7
1468	37	1108	7
1469	37	1109	8
1470	37	1110	8
1471	37	1111	8
1472	37	1112	8
1473	37	1113	9
1474	37	1114	9
1475	37	1115	9
1476	37	1116	9
1477	37	1117	10
1478	37	1118	10
1479	37	1119	10
1480	37	1120	10
1481	38	41	1
1482	38	42	1
1483	38	43	1
1484	38	44	1
1485	38	45	2
1486	38	46	2
1487	38	47	2
1488	38	48	2
1489	38	49	3
1490	38	50	3
1491	38	51	3
1492	38	52	3
1493	38	53	4
1494	38	54	4
1495	38	55	4
1496	38	56	4
1497	38	57	5
1498	38	58	5
1499	38	59	5
1500	38	60	5
1501	38	61	6
1502	38	62	6
1503	38	63	6
1504	38	64	6
1505	38	65	7
1506	38	66	7
1507	38	67	7
1508	38	68	7
1509	38	69	8
1510	38	70	8
1511	38	71	8
1512	38	72	8
1513	38	73	9
1514	38	74	9
1515	38	75	9
1516	38	76	9
1517	38	77	10
1518	38	78	10
1519	38	79	10
1520	38	80	10
1521	39	1041	1
1522	39	1042	1
1523	39	1043	1
1524	39	1044	1
1525	39	1045	2
1526	39	1046	2
1527	39	1047	2
1528	39	1048	2
1529	39	1049	3
1530	39	1050	3
1531	39	1051	3
1532	39	1052	3
1533	39	1053	4
1534	39	1054	4
1535	39	1055	4
1536	39	1056	4
1537	39	1057	5
1538	39	1058	5
1539	39	1059	5
1540	39	1060	5
1541	39	1061	6
1542	39	1062	6
1543	39	1063	6
1544	39	1064	6
1545	39	1065	7
1546	39	1066	7
1547	39	1067	7
1548	39	1068	7
1549	39	1069	8
1550	39	1070	8
1551	39	1071	8
1552	39	1072	8
1553	39	1073	9
1554	39	1074	9
1555	39	1075	9
1556	39	1076	9
1557	39	1077	10
1558	39	1078	10
1559	39	1079	10
1560	39	1080	10
1561	40	441	1
1562	40	442	1
1563	40	443	1
1564	40	444	1
1565	40	445	2
1566	40	446	2
1567	40	447	2
1568	40	448	2
1569	40	449	3
1570	40	450	3
1571	40	451	3
1572	40	452	3
1573	40	453	4
1574	40	454	4
1575	40	455	4
1576	40	456	4
1577	40	457	5
1578	40	458	5
1579	40	459	5
1580	40	460	5
1581	40	461	6
1582	40	462	6
1583	40	463	6
1584	40	464	6
1585	40	465	7
1586	40	466	7
1587	40	467	7
1588	40	468	7
1589	40	469	8
1590	40	470	8
1591	40	471	8
1592	40	472	8
1593	40	473	9
1594	40	474	9
1595	40	475	9
1596	40	476	9
1597	40	477	10
1598	40	478	10
1599	40	479	10
1600	40	480	10
1601	41	601	1
1602	41	602	1
1603	41	603	1
1604	41	604	1
1605	41	605	2
1606	41	606	2
1607	41	607	2
1608	41	608	2
1609	41	609	3
1610	41	610	3
1611	41	611	3
1612	41	612	3
1613	41	613	4
1614	41	614	4
1615	41	615	4
1616	41	616	4
1617	41	617	5
1618	41	618	5
1619	41	619	5
1620	41	620	5
1621	41	621	6
1622	41	622	6
1623	41	623	6
1624	41	624	6
1625	41	625	7
1626	41	626	7
1627	41	627	7
1628	41	628	7
1629	41	629	8
1630	41	630	8
1631	41	631	8
1632	41	632	8
1633	41	633	9
1634	41	634	9
1635	41	635	9
1636	41	636	9
1637	41	637	10
1638	41	638	10
1639	41	639	10
1640	41	640	10
1641	42	161	1
1642	42	162	1
1643	42	163	1
1644	42	164	1
1645	42	165	2
1646	42	166	2
1647	42	167	2
1648	42	168	2
1649	42	169	3
1650	42	170	3
1651	42	171	3
1652	42	172	3
1653	42	173	4
1654	42	174	4
1655	42	175	4
1656	42	176	4
1657	42	177	5
1658	42	178	5
1659	42	179	5
1660	42	180	5
1661	42	181	6
1662	42	182	6
1663	42	183	6
1664	42	184	6
1665	42	185	7
1666	42	186	7
1667	42	187	7
1668	42	188	7
1669	42	189	8
1670	42	190	8
1671	42	191	8
1672	42	192	8
1673	42	193	9
1674	42	194	9
1675	42	195	9
1676	42	196	9
1677	42	197	10
1678	42	198	10
1679	42	199	10
1680	42	200	10
1681	43	281	1
1682	43	282	1
1683	43	283	1
1684	43	284	1
1685	43	285	2
1686	43	286	2
1687	43	287	2
1688	43	288	2
1689	43	289	3
1690	43	290	3
1691	43	291	3
1692	43	292	3
1693	43	293	4
1694	43	294	4
1695	43	295	4
1696	43	296	4
1697	43	297	5
1698	43	298	5
1699	43	299	5
1700	43	300	5
1701	43	301	6
1702	43	302	6
1703	43	303	6
1704	43	304	6
1705	43	305	7
1706	43	306	7
1707	43	307	7
1708	43	308	7
1709	43	309	8
1710	43	310	8
1711	43	311	8
1712	43	312	8
1713	43	313	9
1714	43	314	9
1715	43	315	9
1716	43	316	9
1717	43	317	10
1718	43	318	10
1719	43	319	10
1720	43	320	10
1721	44	441	1
1722	44	442	1
1723	44	443	1
1724	44	444	1
1725	44	445	2
1726	44	446	2
1727	44	447	2
1728	44	448	2
1729	44	449	3
1730	44	450	3
1731	44	451	3
1732	44	452	3
1733	44	453	4
1734	44	454	4
1735	44	455	4
1736	44	456	4
1737	44	457	5
1738	44	458	5
1739	44	459	5
1740	44	460	5
1741	44	461	6
1742	44	462	6
1743	44	463	6
1744	44	464	6
1745	44	465	7
1746	44	466	7
1747	44	467	7
1748	44	468	7
1749	44	469	8
1750	44	470	8
1751	44	471	8
1752	44	472	8
1753	44	473	9
1754	44	474	9
1755	44	475	9
1756	44	476	9
1757	44	477	10
1758	44	478	10
1759	44	479	10
1760	44	480	10
1761	45	241	1
1762	45	242	1
1763	45	243	1
1764	45	244	1
1765	45	245	2
1766	45	246	2
1767	45	247	2
1768	45	248	2
1769	45	249	3
1770	45	250	3
1771	45	251	3
1772	45	252	3
1773	45	253	4
1774	45	254	4
1775	45	255	4
1776	45	256	4
1777	45	257	5
1778	45	258	5
1779	45	259	5
1780	45	260	5
1781	45	261	6
1782	45	262	6
1783	45	263	6
1784	45	264	6
1785	45	265	7
1786	45	266	7
1787	45	267	7
1788	45	268	7
1789	45	269	8
1790	45	270	8
1791	45	271	8
1792	45	272	8
1793	45	273	9
1794	45	274	9
1795	45	275	9
1796	45	276	9
1797	45	277	10
1798	45	278	10
1799	45	279	10
1800	45	280	10
1801	46	481	1
1802	46	482	1
1803	46	483	1
1804	46	484	1
1805	46	485	2
1806	46	486	2
1807	46	487	2
1808	46	488	2
1809	46	489	3
1810	46	490	3
1811	46	491	3
1812	46	492	3
1813	46	493	4
1814	46	494	4
1815	46	495	4
1816	46	496	4
1817	46	497	5
1818	46	498	5
1819	46	499	5
1820	46	500	5
1821	46	501	6
1822	46	502	6
1823	46	503	6
1824	46	504	6
1825	46	505	7
1826	46	506	7
1827	46	507	7
1828	46	508	7
1829	46	509	8
1830	46	510	8
1831	46	511	8
1832	46	512	8
1833	46	513	9
1834	46	514	9
1835	46	515	9
1836	46	516	9
1837	46	517	10
1838	46	518	10
1839	46	519	10
1840	46	520	10
1841	47	441	1
1842	47	442	1
1843	47	443	1
1844	47	444	1
1845	47	445	2
1846	47	446	2
1847	47	447	2
1848	47	448	2
1849	47	449	3
1850	47	450	3
1851	47	451	3
1852	47	452	3
1853	47	453	4
1854	47	454	4
1855	47	455	4
1856	47	456	4
1857	47	457	5
1858	47	458	5
1859	47	459	5
1860	47	460	5
1861	47	461	6
1862	47	462	6
1863	47	463	6
1864	47	464	6
1865	47	465	7
1866	47	466	7
1867	47	467	7
1868	47	468	7
1869	47	469	8
1870	47	470	8
1871	47	471	8
1872	47	472	8
1873	47	473	9
1874	47	474	9
1875	47	475	9
1876	47	476	9
1877	47	477	10
1878	47	478	10
1879	47	479	10
1880	47	480	10
1881	48	441	1
1882	48	442	1
1883	48	443	1
1884	48	444	1
1885	48	445	2
1886	48	446	2
1887	48	447	2
1888	48	448	2
1889	48	449	3
1890	48	450	3
1891	48	451	3
1892	48	452	3
1893	48	453	4
1894	48	454	4
1895	48	455	4
1896	48	456	4
1897	48	457	5
1898	48	458	5
1899	48	459	5
1900	48	460	5
1901	48	461	6
1902	48	462	6
1903	48	463	6
1904	48	464	6
1905	48	465	7
1906	48	466	7
1907	48	467	7
1908	48	468	7
1909	48	469	8
1910	48	470	8
1911	48	471	8
1912	48	472	8
1913	48	473	9
1914	48	474	9
1915	48	475	9
1916	48	476	9
1917	48	477	10
1918	48	478	10
1919	48	479	10
1920	48	480	10
1921	49	121	1
1922	49	122	1
1923	49	123	1
1924	49	124	1
1925	49	125	2
1926	49	126	2
1927	49	127	2
1928	49	128	2
1929	49	129	3
1930	49	130	3
1931	49	131	3
1932	49	132	3
1933	49	133	4
1934	49	134	4
1935	49	135	4
1936	49	136	4
1937	49	137	5
1938	49	138	5
1939	49	139	5
1940	49	140	5
1941	49	141	6
1942	49	142	6
1943	49	143	6
1944	49	144	6
1945	49	145	7
1946	49	146	7
1947	49	147	7
1948	49	148	7
1949	49	149	8
1950	49	150	8
1951	49	151	8
1952	49	152	8
1953	49	153	9
1954	49	154	9
1955	49	155	9
1956	49	156	9
1957	49	157	10
1958	49	158	10
1959	49	159	10
1960	49	160	10
1961	50	321	1
1962	50	322	1
1963	50	323	1
1964	50	324	1
1965	50	325	2
1966	50	326	2
1967	50	327	2
1968	50	328	2
1969	50	329	3
1970	50	330	3
1971	50	331	3
1972	50	332	3
1973	50	333	4
1974	50	334	4
1975	50	335	4
1976	50	336	4
1977	50	337	5
1978	50	338	5
1979	50	339	5
1980	50	340	5
1981	50	341	6
1982	50	342	6
1983	50	343	6
1984	50	344	6
1985	50	345	7
1986	50	346	7
1987	50	347	7
1988	50	348	7
1989	50	349	8
1990	50	350	8
1991	50	351	8
1992	50	352	8
1993	50	353	9
1994	50	354	9
1995	50	355	9
1996	50	356	9
1997	50	357	10
1998	50	358	10
1999	50	359	10
2000	50	360	10
2001	51	721	1
2002	51	722	1
2003	51	723	1
2004	51	724	1
2005	51	725	2
2006	51	726	2
2007	51	727	2
2008	51	728	2
2009	51	729	3
2010	51	730	3
2011	51	731	3
2012	51	732	3
2013	51	733	4
2014	51	734	4
2015	51	735	4
2016	51	736	4
2017	51	737	5
2018	51	738	5
2019	51	739	5
2020	51	740	5
2021	51	741	6
2022	51	742	6
2023	51	743	6
2024	51	744	6
2025	51	745	7
2026	51	746	7
2027	51	747	7
2028	51	748	7
2029	51	749	8
2030	51	750	8
2031	51	751	8
2032	51	752	8
2033	51	753	9
2034	51	754	9
2035	51	755	9
2036	51	756	9
2037	51	757	10
2038	51	758	10
2039	51	759	10
2040	51	760	10
2041	52	1001	1
2042	52	1002	1
2043	52	1003	1
2044	52	1004	1
2045	52	1005	2
2046	52	1006	2
2047	52	1007	2
2048	52	1008	2
2049	52	1009	3
2050	52	1010	3
2051	52	1011	3
2052	52	1012	3
2053	52	1013	4
2054	52	1014	4
2055	52	1015	4
2056	52	1016	4
2057	52	1017	5
2058	52	1018	5
2059	52	1019	5
2060	52	1020	5
2061	52	1021	6
2062	52	1022	6
2063	52	1023	6
2064	52	1024	6
2065	52	1025	7
2066	52	1026	7
2067	52	1027	7
2068	52	1028	7
2069	52	1029	8
2070	52	1030	8
2071	52	1031	8
2072	52	1032	8
2073	52	1033	9
2074	52	1034	9
2075	52	1035	9
2076	52	1036	9
2077	52	1037	10
2078	52	1038	10
2079	52	1039	10
2080	52	1040	10
2081	53	161	1
2082	53	162	1
2083	53	163	1
2084	53	164	1
2085	53	165	2
2086	53	166	2
2087	53	167	2
2088	53	168	2
2089	53	169	3
2090	53	170	3
2091	53	171	3
2092	53	172	3
2093	53	173	4
2094	53	174	4
2095	53	175	4
2096	53	176	4
2097	53	177	5
2098	53	178	5
2099	53	179	5
2100	53	180	5
2101	53	181	6
2102	53	182	6
2103	53	183	6
2104	53	184	6
2105	53	185	7
2106	53	186	7
2107	53	187	7
2108	53	188	7
2109	53	189	8
2110	53	190	8
2111	53	191	8
2112	53	192	8
2113	53	193	9
2114	53	194	9
2115	53	195	9
2116	53	196	9
2117	53	197	10
2118	53	198	10
2119	53	199	10
2120	53	200	10
2121	54	241	1
2122	54	242	1
2123	54	243	1
2124	54	244	1
2125	54	245	2
2126	54	246	2
2127	54	247	2
2128	54	248	2
2129	54	249	3
2130	54	250	3
2131	54	251	3
2132	54	252	3
2133	54	253	4
2134	54	254	4
2135	54	255	4
2136	54	256	4
2137	54	257	5
2138	54	258	5
2139	54	259	5
2140	54	260	5
2141	54	261	6
2142	54	262	6
2143	54	263	6
2144	54	264	6
2145	54	265	7
2146	54	266	7
2147	54	267	7
2148	54	268	7
2149	54	269	8
2150	54	270	8
2151	54	271	8
2152	54	272	8
2153	54	273	9
2154	54	274	9
2155	54	275	9
2156	54	276	9
2157	54	277	10
2158	54	278	10
2159	54	279	10
2160	54	280	10
2161	55	721	1
2162	55	722	1
2163	55	723	1
2164	55	724	1
2165	55	725	2
2166	55	726	2
2167	55	727	2
2168	55	728	2
2169	55	729	3
2170	55	730	3
2171	55	731	3
2172	55	732	3
2173	55	733	4
2174	55	734	4
2175	55	735	4
2176	55	736	4
2177	55	737	5
2178	55	738	5
2179	55	739	5
2180	55	740	5
2181	55	741	6
2182	55	742	6
2183	55	743	6
2184	55	744	6
2185	55	745	7
2186	55	746	7
2187	55	747	7
2188	55	748	7
2189	55	749	8
2190	55	750	8
2191	55	751	8
2192	55	752	8
2193	55	753	9
2194	55	754	9
2195	55	755	9
2196	55	756	9
2197	55	757	10
2198	55	758	10
2199	55	759	10
2200	55	760	10
2201	56	561	1
2202	56	562	1
2203	56	563	1
2204	56	564	1
2205	56	565	2
2206	56	566	2
2207	56	567	2
2208	56	568	2
2209	56	569	3
2210	56	570	3
2211	56	571	3
2212	56	572	3
2213	56	573	4
2214	56	574	4
2215	56	575	4
2216	56	576	4
2217	56	577	5
2218	56	578	5
2219	56	579	5
2220	56	580	5
2221	56	581	6
2222	56	582	6
2223	56	583	6
2224	56	584	6
2225	56	585	7
2226	56	586	7
2227	56	587	7
2228	56	588	7
2229	56	589	8
2230	56	590	8
2231	56	591	8
2232	56	592	8
2233	56	593	9
2234	56	594	9
2235	56	595	9
2236	56	596	9
2237	56	597	10
2238	56	598	10
2239	56	599	10
2240	56	600	10
2241	57	401	1
2242	57	402	1
2243	57	403	1
2244	57	404	1
2245	57	405	2
2246	57	406	2
2247	57	407	2
2248	57	408	2
2249	57	409	3
2250	57	410	3
2251	57	411	3
2252	57	412	3
2253	57	413	4
2254	57	414	4
2255	57	415	4
2256	57	416	4
2257	57	417	5
2258	57	418	5
2259	57	419	5
2260	57	420	5
2261	57	421	6
2262	57	422	6
2263	57	423	6
2264	57	424	6
2265	57	425	7
2266	57	426	7
2267	57	427	7
2268	57	428	7
2269	57	429	8
2270	57	430	8
2271	57	431	8
2272	57	432	8
2273	57	433	9
2274	57	434	9
2275	57	435	9
2276	57	436	9
2277	57	437	10
2278	57	438	10
2279	57	439	10
2280	57	440	10
2281	58	841	1
2282	58	842	1
2283	58	843	1
2284	58	844	1
2285	58	845	2
2286	58	846	2
2287	58	847	2
2288	58	848	2
2289	58	849	3
2290	58	850	3
2291	58	851	3
2292	58	852	3
2293	58	853	4
2294	58	854	4
2295	58	855	4
2296	58	856	4
2297	58	857	5
2298	58	858	5
2299	58	859	5
2300	58	860	5
2301	58	861	6
2302	58	862	6
2303	58	863	6
2304	58	864	6
2305	58	865	7
2306	58	866	7
2307	58	867	7
2308	58	868	7
2309	58	869	8
2310	58	870	8
2311	58	871	8
2312	58	872	8
2313	58	873	9
2314	58	874	9
2315	58	875	9
2316	58	876	9
2317	58	877	10
2318	58	878	10
2319	58	879	10
2320	58	880	10
2321	59	121	1
2322	59	122	1
2323	59	123	1
2324	59	124	1
2325	59	125	2
2326	59	126	2
2327	59	127	2
2328	59	128	2
2329	59	129	3
2330	59	130	3
2331	59	131	3
2332	59	132	3
2333	59	133	4
2334	59	134	4
2335	59	135	4
2336	59	136	4
2337	59	137	5
2338	59	138	5
2339	59	139	5
2340	59	140	5
2341	59	141	6
2342	59	142	6
2343	59	143	6
2344	59	144	6
2345	59	145	7
2346	59	146	7
2347	59	147	7
2348	59	148	7
2349	59	149	8
2350	59	150	8
2351	59	151	8
2352	59	152	8
2353	59	153	9
2354	59	154	9
2355	59	155	9
2356	59	156	9
2357	59	157	10
2358	59	158	10
2359	59	159	10
2360	59	160	10
2361	60	641	1
2362	60	642	1
2363	60	643	1
2364	60	644	1
2365	60	645	2
2366	60	646	2
2367	60	647	2
2368	60	648	2
2369	60	649	3
2370	60	650	3
2371	60	651	3
2372	60	652	3
2373	60	653	4
2374	60	654	4
2375	60	655	4
2376	60	656	4
2377	60	657	5
2378	60	658	5
2379	60	659	5
2380	60	660	5
2381	60	661	6
2382	60	662	6
2383	60	663	6
2384	60	664	6
2385	60	665	7
2386	60	666	7
2387	60	667	7
2388	60	668	7
2389	60	669	8
2390	60	670	8
2391	60	671	8
2392	60	672	8
2393	60	673	9
2394	60	674	9
2395	60	675	9
2396	60	676	9
2397	60	677	10
2398	60	678	10
2399	60	679	10
2400	60	680	10
2401	61	921	1
2402	61	922	1
2403	61	923	1
2404	61	924	1
2405	61	925	2
2406	61	926	2
2407	61	927	2
2408	61	928	2
2409	61	929	3
2410	61	930	3
2411	61	931	3
2412	61	932	3
2413	61	933	4
2414	61	934	4
2415	61	935	4
2416	61	936	4
2417	61	937	5
2418	61	938	5
2419	61	939	5
2420	61	940	5
2421	61	941	6
2422	61	942	6
2423	61	943	6
2424	61	944	6
2425	61	945	7
2426	61	946	7
2427	61	947	7
2428	61	948	7
2429	61	949	8
2430	61	950	8
2431	61	951	8
2432	61	952	8
2433	61	953	9
2434	61	954	9
2435	61	955	9
2436	61	956	9
2437	61	957	10
2438	61	958	10
2439	61	959	10
2440	61	960	10
2441	62	1161	1
2442	62	1162	1
2443	62	1163	1
2444	62	1164	1
2445	62	1165	2
2446	62	1166	2
2447	62	1167	2
2448	62	1168	2
2449	62	1169	3
2450	62	1170	3
2451	62	1171	3
2452	62	1172	3
2453	62	1173	4
2454	62	1174	4
2455	62	1175	4
2456	62	1176	4
2457	62	1177	5
2458	62	1178	5
2459	62	1179	5
2460	62	1180	5
2461	62	1181	6
2462	62	1182	6
2463	62	1183	6
2464	62	1184	6
2465	62	1185	7
2466	62	1186	7
2467	62	1187	7
2468	62	1188	7
2469	62	1189	8
2470	62	1190	8
2471	62	1191	8
2472	62	1192	8
2473	62	1193	9
2474	62	1194	9
2475	62	1195	9
2476	62	1196	9
2477	62	1197	10
2478	62	1198	10
2479	62	1199	10
2480	62	1200	10
2481	63	841	1
2482	63	842	1
2483	63	843	1
2484	63	844	1
2485	63	845	2
2486	63	846	2
2487	63	847	2
2488	63	848	2
2489	63	849	3
2490	63	850	3
2491	63	851	3
2492	63	852	3
2493	63	853	4
2494	63	854	4
2495	63	855	4
2496	63	856	4
2497	63	857	5
2498	63	858	5
2499	63	859	5
2500	63	860	5
2501	63	861	6
2502	63	862	6
2503	63	863	6
2504	63	864	6
2505	63	865	7
2506	63	866	7
2507	63	867	7
2508	63	868	7
2509	63	869	8
2510	63	870	8
2511	63	871	8
2512	63	872	8
2513	63	873	9
2514	63	874	9
2515	63	875	9
2516	63	876	9
2517	63	877	10
2518	63	878	10
2519	63	879	10
2520	63	880	10
2521	64	401	1
2522	64	402	1
2523	64	403	1
2524	64	404	1
2525	64	405	2
2526	64	406	2
2527	64	407	2
2528	64	408	2
2529	64	409	3
2530	64	410	3
2531	64	411	3
2532	64	412	3
2533	64	413	4
2534	64	414	4
2535	64	415	4
2536	64	416	4
2537	64	417	5
2538	64	418	5
2539	64	419	5
2540	64	420	5
2541	64	421	6
2542	64	422	6
2543	64	423	6
2544	64	424	6
2545	64	425	7
2546	64	426	7
2547	64	427	7
2548	64	428	7
2549	64	429	8
2550	64	430	8
2551	64	431	8
2552	64	432	8
2553	64	433	9
2554	64	434	9
2555	64	435	9
2556	64	436	9
2557	64	437	10
2558	64	438	10
2559	64	439	10
2560	64	440	10
2561	65	121	1
2562	65	122	1
2563	65	123	1
2564	65	124	1
2565	65	125	2
2566	65	126	2
2567	65	127	2
2568	65	128	2
2569	65	129	3
2570	65	130	3
2571	65	131	3
2572	65	132	3
2573	65	133	4
2574	65	134	4
2575	65	135	4
2576	65	136	4
2577	65	137	5
2578	65	138	5
2579	65	139	5
2580	65	140	5
2581	65	141	6
2582	65	142	6
2583	65	143	6
2584	65	144	6
2585	65	145	7
2586	65	146	7
2587	65	147	7
2588	65	148	7
2589	65	149	8
2590	65	150	8
2591	65	151	8
2592	65	152	8
2593	65	153	9
2594	65	154	9
2595	65	155	9
2596	65	156	9
2597	65	157	10
2598	65	158	10
2599	65	159	10
2600	65	160	10
2601	66	841	1
2602	66	842	1
2603	66	843	1
2604	66	844	1
2605	66	845	2
2606	66	846	2
2607	66	847	2
2608	66	848	2
2609	66	849	3
2610	66	850	3
2611	66	851	3
2612	66	852	3
2613	66	853	4
2614	66	854	4
2615	66	855	4
2616	66	856	4
2617	66	857	5
2618	66	858	5
2619	66	859	5
2620	66	860	5
2621	66	861	6
2622	66	862	6
2623	66	863	6
2624	66	864	6
2625	66	865	7
2626	66	866	7
2627	66	867	7
2628	66	868	7
2629	66	869	8
2630	66	870	8
2631	66	871	8
2632	66	872	8
2633	66	873	9
2634	66	874	9
2635	66	875	9
2636	66	876	9
2637	66	877	10
2638	66	878	10
2639	66	879	10
2640	66	880	10
2641	67	1001	1
2642	67	1002	1
2643	67	1003	1
2644	67	1004	1
2645	67	1005	2
2646	67	1006	2
2647	67	1007	2
2648	67	1008	2
2649	67	1009	3
2650	67	1010	3
2651	67	1011	3
2652	67	1012	3
2653	67	1013	4
2654	67	1014	4
2655	67	1015	4
2656	67	1016	4
2657	67	1017	5
2658	67	1018	5
2659	67	1019	5
2660	67	1020	5
2661	67	1021	6
2662	67	1022	6
2663	67	1023	6
2664	67	1024	6
2665	67	1025	7
2666	67	1026	7
2667	67	1027	7
2668	67	1028	7
2669	67	1029	8
2670	67	1030	8
2671	67	1031	8
2672	67	1032	8
2673	67	1033	9
2674	67	1034	9
2675	67	1035	9
2676	67	1036	9
2677	67	1037	10
2678	67	1038	10
2679	67	1039	10
2680	67	1040	10
2681	68	1001	1
2682	68	1002	1
2683	68	1003	1
2684	68	1004	1
2685	68	1005	2
2686	68	1006	2
2687	68	1007	2
2688	68	1008	2
2689	68	1009	3
2690	68	1010	3
2691	68	1011	3
2692	68	1012	3
2693	68	1013	4
2694	68	1014	4
2695	68	1015	4
2696	68	1016	4
2697	68	1017	5
2698	68	1018	5
2699	68	1019	5
2700	68	1020	5
2701	68	1021	6
2702	68	1022	6
2703	68	1023	6
2704	68	1024	6
2705	68	1025	7
2706	68	1026	7
2707	68	1027	7
2708	68	1028	7
2709	68	1029	8
2710	68	1030	8
2711	68	1031	8
2712	68	1032	8
2713	68	1033	9
2714	68	1034	9
2715	68	1035	9
2716	68	1036	9
2717	68	1037	10
2718	68	1038	10
2719	68	1039	10
2720	68	1040	10
2721	69	161	1
2722	69	162	1
2723	69	163	1
2724	69	164	1
2725	69	165	2
2726	69	166	2
2727	69	167	2
2728	69	168	2
2729	69	169	3
2730	69	170	3
2731	69	171	3
2732	69	172	3
2733	69	173	4
2734	69	174	4
2735	69	175	4
2736	69	176	4
2737	69	177	5
2738	69	178	5
2739	69	179	5
2740	69	180	5
2741	69	181	6
2742	69	182	6
2743	69	183	6
2744	69	184	6
2745	69	185	7
2746	69	186	7
2747	69	187	7
2748	69	188	7
2749	69	189	8
2750	69	190	8
2751	69	191	8
2752	69	192	8
2753	69	193	9
2754	69	194	9
2755	69	195	9
2756	69	196	9
2757	69	197	10
2758	69	198	10
2759	69	199	10
2760	69	200	10
2761	70	561	1
2762	70	562	1
2763	70	563	1
2764	70	564	1
2765	70	565	2
2766	70	566	2
2767	70	567	2
2768	70	568	2
2769	70	569	3
2770	70	570	3
2771	70	571	3
2772	70	572	3
2773	70	573	4
2774	70	574	4
2775	70	575	4
2776	70	576	4
2777	70	577	5
2778	70	578	5
2779	70	579	5
2780	70	580	5
2781	70	581	6
2782	70	582	6
2783	70	583	6
2784	70	584	6
2785	70	585	7
2786	70	586	7
2787	70	587	7
2788	70	588	7
2789	70	589	8
2790	70	590	8
2791	70	591	8
2792	70	592	8
2793	70	593	9
2794	70	594	9
2795	70	595	9
2796	70	596	9
2797	70	597	10
2798	70	598	10
2799	70	599	10
2800	70	600	10
2801	71	641	1
2802	71	642	1
2803	71	643	1
2804	71	644	1
2805	71	645	2
2806	71	646	2
2807	71	647	2
2808	71	648	2
2809	71	649	3
2810	71	650	3
2811	71	651	3
2812	71	652	3
2813	71	653	4
2814	71	654	4
2815	71	655	4
2816	71	656	4
2817	71	657	5
2818	71	658	5
2819	71	659	5
2820	71	660	5
2821	71	661	6
2822	71	662	6
2823	71	663	6
2824	71	664	6
2825	71	665	7
2826	71	666	7
2827	71	667	7
2828	71	668	7
2829	71	669	8
2830	71	670	8
2831	71	671	8
2832	71	672	8
2833	71	673	9
2834	71	674	9
2835	71	675	9
2836	71	676	9
2837	71	677	10
2838	71	678	10
2839	71	679	10
2840	71	680	10
2841	72	801	1
2842	72	802	1
2843	72	803	1
2844	72	804	1
2845	72	805	2
2846	72	806	2
2847	72	807	2
2848	72	808	2
2849	72	809	3
2850	72	810	3
2851	72	811	3
2852	72	812	3
2853	72	813	4
2854	72	814	4
2855	72	815	4
2856	72	816	4
2857	72	817	5
2858	72	818	5
2859	72	819	5
2860	72	820	5
2861	72	821	6
2862	72	822	6
2863	72	823	6
2864	72	824	6
2865	72	825	7
2866	72	826	7
2867	72	827	7
2868	72	828	7
2869	72	829	8
2870	72	830	8
2871	72	831	8
2872	72	832	8
2873	72	833	9
2874	72	834	9
2875	72	835	9
2876	72	836	9
2877	72	837	10
2878	72	838	10
2879	72	839	10
2880	72	840	10
2881	73	681	1
2882	73	682	1
2883	73	683	1
2884	73	684	1
2885	73	685	2
2886	73	686	2
2887	73	687	2
2888	73	688	2
2889	73	689	3
2890	73	690	3
2891	73	691	3
2892	73	692	3
2893	73	693	4
2894	73	694	4
2895	73	695	4
2896	73	696	4
2897	73	697	5
2898	73	698	5
2899	73	699	5
2900	73	700	5
2901	73	701	6
2902	73	702	6
2903	73	703	6
2904	73	704	6
2905	73	705	7
2906	73	706	7
2907	73	707	7
2908	73	708	7
2909	73	709	8
2910	73	710	8
2911	73	711	8
2912	73	712	8
2913	73	713	9
2914	73	714	9
2915	73	715	9
2916	73	716	9
2917	73	717	10
2918	73	718	10
2919	73	719	10
2920	73	720	10
2921	74	601	1
2922	74	602	1
2923	74	603	1
2924	74	604	1
2925	74	605	2
2926	74	606	2
2927	74	607	2
2928	74	608	2
2929	74	609	3
2930	74	610	3
2931	74	611	3
2932	74	612	3
2933	74	613	4
2934	74	614	4
2935	74	615	4
2936	74	616	4
2937	74	617	5
2938	74	618	5
2939	74	619	5
2940	74	620	5
2941	74	621	6
2942	74	622	6
2943	74	623	6
2944	74	624	6
2945	74	625	7
2946	74	626	7
2947	74	627	7
2948	74	628	7
2949	74	629	8
2950	74	630	8
2951	74	631	8
2952	74	632	8
2953	74	633	9
2954	74	634	9
2955	74	635	9
2956	74	636	9
2957	74	637	10
2958	74	638	10
2959	74	639	10
2960	74	640	10
2961	75	1	1
2962	75	2	1
2963	75	3	1
2964	75	4	1
2965	75	5	2
2966	75	6	2
2967	75	7	2
2968	75	8	2
2969	75	9	3
2970	75	10	3
2971	75	11	3
2972	75	12	3
2973	75	13	4
2974	75	14	4
2975	75	15	4
2976	75	16	4
2977	75	17	5
2978	75	18	5
2979	75	19	5
2980	75	20	5
2981	75	21	6
2982	75	22	6
2983	75	23	6
2984	75	24	6
2985	75	25	7
2986	75	26	7
2987	75	27	7
2988	75	28	7
2989	75	29	8
2990	75	30	8
2991	75	31	8
2992	75	32	8
2993	75	33	9
2994	75	34	9
2995	75	35	9
2996	75	36	9
2997	75	37	10
2998	75	38	10
2999	75	39	10
3000	75	40	10
3001	76	841	1
3002	76	842	1
3003	76	843	1
3004	76	844	1
3005	76	845	2
3006	76	846	2
3007	76	847	2
3008	76	848	2
3009	76	849	3
3010	76	850	3
3011	76	851	3
3012	76	852	3
3013	76	853	4
3014	76	854	4
3015	76	855	4
3016	76	856	4
3017	76	857	5
3018	76	858	5
3019	76	859	5
3020	76	860	5
3021	76	861	6
3022	76	862	6
3023	76	863	6
3024	76	864	6
3025	76	865	7
3026	76	866	7
3027	76	867	7
3028	76	868	7
3029	76	869	8
3030	76	870	8
3031	76	871	8
3032	76	872	8
3033	76	873	9
3034	76	874	9
3035	76	875	9
3036	76	876	9
3037	76	877	10
3038	76	878	10
3039	76	879	10
3040	76	880	10
3041	77	401	1
3042	77	402	1
3043	77	403	1
3044	77	404	1
3045	77	405	2
3046	77	406	2
3047	77	407	2
3048	77	408	2
3049	77	409	3
3050	77	410	3
3051	77	411	3
3052	77	412	3
3053	77	413	4
3054	77	414	4
3055	77	415	4
3056	77	416	4
3057	77	417	5
3058	77	418	5
3059	77	419	5
3060	77	420	5
3061	77	421	6
3062	77	422	6
3063	77	423	6
3064	77	424	6
3065	77	425	7
3066	77	426	7
3067	77	427	7
3068	77	428	7
3069	77	429	8
3070	77	430	8
3071	77	431	8
3072	77	432	8
3073	77	433	9
3074	77	434	9
3075	77	435	9
3076	77	436	9
3077	77	437	10
3078	77	438	10
3079	77	439	10
3080	77	440	10
3081	78	1001	1
3082	78	1002	1
3083	78	1003	1
3084	78	1004	1
3085	78	1005	2
3086	78	1006	2
3087	78	1007	2
3088	78	1008	2
3089	78	1009	3
3090	78	1010	3
3091	78	1011	3
3092	78	1012	3
3093	78	1013	4
3094	78	1014	4
3095	78	1015	4
3096	78	1016	4
3097	78	1017	5
3098	78	1018	5
3099	78	1019	5
3100	78	1020	5
3101	78	1021	6
3102	78	1022	6
3103	78	1023	6
3104	78	1024	6
3105	78	1025	7
3106	78	1026	7
3107	78	1027	7
3108	78	1028	7
3109	78	1029	8
3110	78	1030	8
3111	78	1031	8
3112	78	1032	8
3113	78	1033	9
3114	78	1034	9
3115	78	1035	9
3116	78	1036	9
3117	78	1037	10
3118	78	1038	10
3119	78	1039	10
3120	78	1040	10
3121	79	281	1
3122	79	282	1
3123	79	283	1
3124	79	284	1
3125	79	285	2
3126	79	286	2
3127	79	287	2
3128	79	288	2
3129	79	289	3
3130	79	290	3
3131	79	291	3
3132	79	292	3
3133	79	293	4
3134	79	294	4
3135	79	295	4
3136	79	296	4
3137	79	297	5
3138	79	298	5
3139	79	299	5
3140	79	300	5
3141	79	301	6
3142	79	302	6
3143	79	303	6
3144	79	304	6
3145	79	305	7
3146	79	306	7
3147	79	307	7
3148	79	308	7
3149	79	309	8
3150	79	310	8
3151	79	311	8
3152	79	312	8
3153	79	313	9
3154	79	314	9
3155	79	315	9
3156	79	316	9
3157	79	317	10
3158	79	318	10
3159	79	319	10
3160	79	320	10
3161	80	1041	1
3162	80	1042	1
3163	80	1043	1
3164	80	1044	1
3165	80	1045	2
3166	80	1046	2
3167	80	1047	2
3168	80	1048	2
3169	80	1049	3
3170	80	1050	3
3171	80	1051	3
3172	80	1052	3
3173	80	1053	4
3174	80	1054	4
3175	80	1055	4
3176	80	1056	4
3177	80	1057	5
3178	80	1058	5
3179	80	1059	5
3180	80	1060	5
3181	80	1061	6
3182	80	1062	6
3183	80	1063	6
3184	80	1064	6
3185	80	1065	7
3186	80	1066	7
3187	80	1067	7
3188	80	1068	7
3189	80	1069	8
3190	80	1070	8
3191	80	1071	8
3192	80	1072	8
3193	80	1073	9
3194	80	1074	9
3195	80	1075	9
3196	80	1076	9
3197	80	1077	10
3198	80	1078	10
3199	80	1079	10
3200	80	1080	10
3201	81	761	1
3202	81	762	1
3203	81	763	1
3204	81	764	1
3205	81	765	2
3206	81	766	2
3207	81	767	2
3208	81	768	2
3209	81	769	3
3210	81	770	3
3211	81	771	3
3212	81	772	3
3213	81	773	4
3214	81	774	4
3215	81	775	4
3216	81	776	4
3217	81	777	5
3218	81	778	5
3219	81	779	5
3220	81	780	5
3221	81	781	6
3222	81	782	6
3223	81	783	6
3224	81	784	6
3225	81	785	7
3226	81	786	7
3227	81	787	7
3228	81	788	7
3229	81	789	8
3230	81	790	8
3231	81	791	8
3232	81	792	8
3233	81	793	9
3234	81	794	9
3235	81	795	9
3236	81	796	9
3237	81	797	10
3238	81	798	10
3239	81	799	10
3240	81	800	10
3241	82	121	1
3242	82	122	1
3243	82	123	1
3244	82	124	1
3245	82	125	2
3246	82	126	2
3247	82	127	2
3248	82	128	2
3249	82	129	3
3250	82	130	3
3251	82	131	3
3252	82	132	3
3253	82	133	4
3254	82	134	4
3255	82	135	4
3256	82	136	4
3257	82	137	5
3258	82	138	5
3259	82	139	5
3260	82	140	5
3261	82	141	6
3262	82	142	6
3263	82	143	6
3264	82	144	6
3265	82	145	7
3266	82	146	7
3267	82	147	7
3268	82	148	7
3269	82	149	8
3270	82	150	8
3271	82	151	8
3272	82	152	8
3273	82	153	9
3274	82	154	9
3275	82	155	9
3276	82	156	9
3277	82	157	10
3278	82	158	10
3279	82	159	10
3280	82	160	10
3281	83	41	1
3282	83	42	1
3283	83	43	1
3284	83	44	1
3285	83	45	2
3286	83	46	2
3287	83	47	2
3288	83	48	2
3289	83	49	3
3290	83	50	3
3291	83	51	3
3292	83	52	3
3293	83	53	4
3294	83	54	4
3295	83	55	4
3296	83	56	4
3297	83	57	5
3298	83	58	5
3299	83	59	5
3300	83	60	5
3301	83	61	6
3302	83	62	6
3303	83	63	6
3304	83	64	6
3305	83	65	7
3306	83	66	7
3307	83	67	7
3308	83	68	7
3309	83	69	8
3310	83	70	8
3311	83	71	8
3312	83	72	8
3313	83	73	9
3314	83	74	9
3315	83	75	9
3316	83	76	9
3317	83	77	10
3318	83	78	10
3319	83	79	10
3320	83	80	10
3321	84	281	1
3322	84	282	1
3323	84	283	1
3324	84	284	1
3325	84	285	2
3326	84	286	2
3327	84	287	2
3328	84	288	2
3329	84	289	3
3330	84	290	3
3331	84	291	3
3332	84	292	3
3333	84	293	4
3334	84	294	4
3335	84	295	4
3336	84	296	4
3337	84	297	5
3338	84	298	5
3339	84	299	5
3340	84	300	5
3341	84	301	6
3342	84	302	6
3343	84	303	6
3344	84	304	6
3345	84	305	7
3346	84	306	7
3347	84	307	7
3348	84	308	7
3349	84	309	8
3350	84	310	8
3351	84	311	8
3352	84	312	8
3353	84	313	9
3354	84	314	9
3355	84	315	9
3356	84	316	9
3357	84	317	10
3358	84	318	10
3359	84	319	10
3360	84	320	10
3361	85	1	1
3362	85	2	1
3363	85	3	1
3364	85	4	1
3365	85	5	2
3366	85	6	2
3367	85	7	2
3368	85	8	2
3369	85	9	3
3370	85	10	3
3371	85	11	3
3372	85	12	3
3373	85	13	4
3374	85	14	4
3375	85	15	4
3376	85	16	4
3377	85	17	5
3378	85	18	5
3379	85	19	5
3380	85	20	5
3381	85	21	6
3382	85	22	6
3383	85	23	6
3384	85	24	6
3385	85	25	7
3386	85	26	7
3387	85	27	7
3388	85	28	7
3389	85	29	8
3390	85	30	8
3391	85	31	8
3392	85	32	8
3393	85	33	9
3394	85	34	9
3395	85	35	9
3396	85	36	9
3397	85	37	10
3398	85	38	10
3399	85	39	10
3400	85	40	10
3401	86	401	1
3402	86	402	1
3403	86	403	1
3404	86	404	1
3405	86	405	2
3406	86	406	2
3407	86	407	2
3408	86	408	2
3409	86	409	3
3410	86	410	3
3411	86	411	3
3412	86	412	3
3413	86	413	4
3414	86	414	4
3415	86	415	4
3416	86	416	4
3417	86	417	5
3418	86	418	5
3419	86	419	5
3420	86	420	5
3421	86	421	6
3422	86	422	6
3423	86	423	6
3424	86	424	6
3425	86	425	7
3426	86	426	7
3427	86	427	7
3428	86	428	7
3429	86	429	8
3430	86	430	8
3431	86	431	8
3432	86	432	8
3433	86	433	9
3434	86	434	9
3435	86	435	9
3436	86	436	9
3437	86	437	10
3438	86	438	10
3439	86	439	10
3440	86	440	10
3441	87	201	1
3442	87	202	1
3443	87	203	1
3444	87	204	1
3445	87	205	2
3446	87	206	2
3447	87	207	2
3448	87	208	2
3449	87	209	3
3450	87	210	3
3451	87	211	3
3452	87	212	3
3453	87	213	4
3454	87	214	4
3455	87	215	4
3456	87	216	4
3457	87	217	5
3458	87	218	5
3459	87	219	5
3460	87	220	5
3461	87	221	6
3462	87	222	6
3463	87	223	6
3464	87	224	6
3465	87	225	7
3466	87	226	7
3467	87	227	7
3468	87	228	7
3469	87	229	8
3470	87	230	8
3471	87	231	8
3472	87	232	8
3473	87	233	9
3474	87	234	9
3475	87	235	9
3476	87	236	9
3477	87	237	10
3478	87	238	10
3479	87	239	10
3480	87	240	10
3481	88	521	1
3482	88	522	1
3483	88	523	1
3484	88	524	1
3485	88	525	2
3486	88	526	2
3487	88	527	2
3488	88	528	2
3489	88	529	3
3490	88	530	3
3491	88	531	3
3492	88	532	3
3493	88	533	4
3494	88	534	4
3495	88	535	4
3496	88	536	4
3497	88	537	5
3498	88	538	5
3499	88	539	5
3500	88	540	5
3501	88	541	6
3502	88	542	6
3503	88	543	6
3504	88	544	6
3505	88	545	7
3506	88	546	7
3507	88	547	7
3508	88	548	7
3509	88	549	8
3510	88	550	8
3511	88	551	8
3512	88	552	8
3513	88	553	9
3514	88	554	9
3515	88	555	9
3516	88	556	9
3517	88	557	10
3518	88	558	10
3519	88	559	10
3520	88	560	10
3521	89	121	1
3522	89	122	1
3523	89	123	1
3524	89	124	1
3525	89	125	2
3526	89	126	2
3527	89	127	2
3528	89	128	2
3529	89	129	3
3530	89	130	3
3531	89	131	3
3532	89	132	3
3533	89	133	4
3534	89	134	4
3535	89	135	4
3536	89	136	4
3537	89	137	5
3538	89	138	5
3539	89	139	5
3540	89	140	5
3541	89	141	6
3542	89	142	6
3543	89	143	6
3544	89	144	6
3545	89	145	7
3546	89	146	7
3547	89	147	7
3548	89	148	7
3549	89	149	8
3550	89	150	8
3551	89	151	8
3552	89	152	8
3553	89	153	9
3554	89	154	9
3555	89	155	9
3556	89	156	9
3557	89	157	10
3558	89	158	10
3559	89	159	10
3560	89	160	10
3561	90	1121	1
3562	90	1122	1
3563	90	1123	1
3564	90	1124	1
3565	90	1125	2
3566	90	1126	2
3567	90	1127	2
3568	90	1128	2
3569	90	1129	3
3570	90	1130	3
3571	90	1131	3
3572	90	1132	3
3573	90	1133	4
3574	90	1134	4
3575	90	1135	4
3576	90	1136	4
3577	90	1137	5
3578	90	1138	5
3579	90	1139	5
3580	90	1140	5
3581	90	1141	6
3582	90	1142	6
3583	90	1143	6
3584	90	1144	6
3585	90	1145	7
3586	90	1146	7
3587	90	1147	7
3588	90	1148	7
3589	90	1149	8
3590	90	1150	8
3591	90	1151	8
3592	90	1152	8
3593	90	1153	9
3594	90	1154	9
3595	90	1155	9
3596	90	1156	9
3597	90	1157	10
3598	90	1158	10
3599	90	1159	10
3600	90	1160	10
3601	91	1161	1
3602	91	1162	1
3603	91	1163	1
3604	91	1164	1
3605	91	1165	2
3606	91	1166	2
3607	91	1167	2
3608	91	1168	2
3609	91	1169	3
3610	91	1170	3
3611	91	1171	3
3612	91	1172	3
3613	91	1173	4
3614	91	1174	4
3615	91	1175	4
3616	91	1176	4
3617	91	1177	5
3618	91	1178	5
3619	91	1179	5
3620	91	1180	5
3621	91	1181	6
3622	91	1182	6
3623	91	1183	6
3624	91	1184	6
3625	91	1185	7
3626	91	1186	7
3627	91	1187	7
3628	91	1188	7
3629	91	1189	8
3630	91	1190	8
3631	91	1191	8
3632	91	1192	8
3633	91	1193	9
3634	91	1194	9
3635	91	1195	9
3636	91	1196	9
3637	91	1197	10
3638	91	1198	10
3639	91	1199	10
3640	91	1200	10
3641	92	121	1
3642	92	122	1
3643	92	123	1
3644	92	124	1
3645	92	125	2
3646	92	126	2
3647	92	127	2
3648	92	128	2
3649	92	129	3
3650	92	130	3
3651	92	131	3
3652	92	132	3
3653	92	133	4
3654	92	134	4
3655	92	135	4
3656	92	136	4
3657	92	137	5
3658	92	138	5
3659	92	139	5
3660	92	140	5
3661	92	141	6
3662	92	142	6
3663	92	143	6
3664	92	144	6
3665	92	145	7
3666	92	146	7
3667	92	147	7
3668	92	148	7
3669	92	149	8
3670	92	150	8
3671	92	151	8
3672	92	152	8
3673	92	153	9
3674	92	154	9
3675	92	155	9
3676	92	156	9
3677	92	157	10
3678	92	158	10
3679	92	159	10
3680	92	160	10
3681	93	1041	1
3682	93	1042	1
3683	93	1043	1
3684	93	1044	1
3685	93	1045	2
3686	93	1046	2
3687	93	1047	2
3688	93	1048	2
3689	93	1049	3
3690	93	1050	3
3691	93	1051	3
3692	93	1052	3
3693	93	1053	4
3694	93	1054	4
3695	93	1055	4
3696	93	1056	4
3697	93	1057	5
3698	93	1058	5
3699	93	1059	5
3700	93	1060	5
3701	93	1061	6
3702	93	1062	6
3703	93	1063	6
3704	93	1064	6
3705	93	1065	7
3706	93	1066	7
3707	93	1067	7
3708	93	1068	7
3709	93	1069	8
3710	93	1070	8
3711	93	1071	8
3712	93	1072	8
3713	93	1073	9
3714	93	1074	9
3715	93	1075	9
3716	93	1076	9
3717	93	1077	10
3718	93	1078	10
3719	93	1079	10
3720	93	1080	10
3721	94	961	1
3722	94	962	1
3723	94	963	1
3724	94	964	1
3725	94	965	2
3726	94	966	2
3727	94	967	2
3728	94	968	2
3729	94	969	3
3730	94	970	3
3731	94	971	3
3732	94	972	3
3733	94	973	4
3734	94	974	4
3735	94	975	4
3736	94	976	4
3737	94	977	5
3738	94	978	5
3739	94	979	5
3740	94	980	5
3741	94	981	6
3742	94	982	6
3743	94	983	6
3744	94	984	6
3745	94	985	7
3746	94	986	7
3747	94	987	7
3748	94	988	7
3749	94	989	8
3750	94	990	8
3751	94	991	8
3752	94	992	8
3753	94	993	9
3754	94	994	9
3755	94	995	9
3756	94	996	9
3757	94	997	10
3758	94	998	10
3759	94	999	10
3760	94	1000	10
3761	95	321	1
3762	95	322	1
3763	95	323	1
3764	95	324	1
3765	95	325	2
3766	95	326	2
3767	95	327	2
3768	95	328	2
3769	95	329	3
3770	95	330	3
3771	95	331	3
3772	95	332	3
3773	95	333	4
3774	95	334	4
3775	95	335	4
3776	95	336	4
3777	95	337	5
3778	95	338	5
3779	95	339	5
3780	95	340	5
3781	95	341	6
3782	95	342	6
3783	95	343	6
3784	95	344	6
3785	95	345	7
3786	95	346	7
3787	95	347	7
3788	95	348	7
3789	95	349	8
3790	95	350	8
3791	95	351	8
3792	95	352	8
3793	95	353	9
3794	95	354	9
3795	95	355	9
3796	95	356	9
3797	95	357	10
3798	95	358	10
3799	95	359	10
3800	95	360	10
3801	96	1041	1
3802	96	1042	1
3803	96	1043	1
3804	96	1044	1
3805	96	1045	2
3806	96	1046	2
3807	96	1047	2
3808	96	1048	2
3809	96	1049	3
3810	96	1050	3
3811	96	1051	3
3812	96	1052	3
3813	96	1053	4
3814	96	1054	4
3815	96	1055	4
3816	96	1056	4
3817	96	1057	5
3818	96	1058	5
3819	96	1059	5
3820	96	1060	5
3821	96	1061	6
3822	96	1062	6
3823	96	1063	6
3824	96	1064	6
3825	96	1065	7
3826	96	1066	7
3827	96	1067	7
3828	96	1068	7
3829	96	1069	8
3830	96	1070	8
3831	96	1071	8
3832	96	1072	8
3833	96	1073	9
3834	96	1074	9
3835	96	1075	9
3836	96	1076	9
3837	96	1077	10
3838	96	1078	10
3839	96	1079	10
3840	96	1080	10
3841	97	201	1
3842	97	202	1
3843	97	203	1
3844	97	204	1
3845	97	205	2
3846	97	206	2
3847	97	207	2
3848	97	208	2
3849	97	209	3
3850	97	210	3
3851	97	211	3
3852	97	212	3
3853	97	213	4
3854	97	214	4
3855	97	215	4
3856	97	216	4
3857	97	217	5
3858	97	218	5
3859	97	219	5
3860	97	220	5
3861	97	221	6
3862	97	222	6
3863	97	223	6
3864	97	224	6
3865	97	225	7
3866	97	226	7
3867	97	227	7
3868	97	228	7
3869	97	229	8
3870	97	230	8
3871	97	231	8
3872	97	232	8
3873	97	233	9
3874	97	234	9
3875	97	235	9
3876	97	236	9
3877	97	237	10
3878	97	238	10
3879	97	239	10
3880	97	240	10
3881	98	161	1
3882	98	162	1
3883	98	163	1
3884	98	164	1
3885	98	165	2
3886	98	166	2
3887	98	167	2
3888	98	168	2
3889	98	169	3
3890	98	170	3
3891	98	171	3
3892	98	172	3
3893	98	173	4
3894	98	174	4
3895	98	175	4
3896	98	176	4
3897	98	177	5
3898	98	178	5
3899	98	179	5
3900	98	180	5
3901	98	181	6
3902	98	182	6
3903	98	183	6
3904	98	184	6
3905	98	185	7
3906	98	186	7
3907	98	187	7
3908	98	188	7
3909	98	189	8
3910	98	190	8
3911	98	191	8
3912	98	192	8
3913	98	193	9
3914	98	194	9
3915	98	195	9
3916	98	196	9
3917	98	197	10
3918	98	198	10
3919	98	199	10
3920	98	200	10
3921	99	401	1
3922	99	402	1
3923	99	403	1
3924	99	404	1
3925	99	405	2
3926	99	406	2
3927	99	407	2
3928	99	408	2
3929	99	409	3
3930	99	410	3
3931	99	411	3
3932	99	412	3
3933	99	413	4
3934	99	414	4
3935	99	415	4
3936	99	416	4
3937	99	417	5
3938	99	418	5
3939	99	419	5
3940	99	420	5
3941	99	421	6
3942	99	422	6
3943	99	423	6
3944	99	424	6
3945	99	425	7
3946	99	426	7
3947	99	427	7
3948	99	428	7
3949	99	429	8
3950	99	430	8
3951	99	431	8
3952	99	432	8
3953	99	433	9
3954	99	434	9
3955	99	435	9
3956	99	436	9
3957	99	437	10
3958	99	438	10
3959	99	439	10
3960	99	440	10
3961	100	81	1
3962	100	82	1
3963	100	83	1
3964	100	84	1
3965	100	85	2
3966	100	86	2
3967	100	87	2
3968	100	88	2
3969	100	89	3
3970	100	90	3
3971	100	91	3
3972	100	92	3
3973	100	93	4
3974	100	94	4
3975	100	95	4
3976	100	96	4
3977	100	97	5
3978	100	98	5
3979	100	99	5
3980	100	100	5
3981	100	101	6
3982	100	102	6
3983	100	103	6
3984	100	104	6
3985	100	105	7
3986	100	106	7
3987	100	107	7
3988	100	108	7
3989	100	109	8
3990	100	110	8
3991	100	111	8
3992	100	112	8
3993	100	113	9
3994	100	114	9
3995	100	115	9
3996	100	116	9
3997	100	117	10
3998	100	118	10
3999	100	119	10
4000	100	120	10
\.


--
-- Data for Name: materias; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.materias (id_materia, id_escuela, nombre, descripcion, creditos) FROM stdin;
1	1	Cálculo 1	Materia de Cálculo 1 en la Escuela de Ingeniería Civil.	3
2	1	Álgebra 1	Materia de Álgebra 1 en la Escuela de Ingeniería Civil.	4
3	1	Física 1	Materia de Física 1 en la Escuela de Ingeniería Civil.	5
4	1	Materiales 1	Materia de Materiales 1 en la Escuela de Ingeniería Civil.	3
5	1	Electrónica 1	Materia de Electrónica 1 en la Escuela de Ingeniería Civil.	4
6	1	Mecánica 1	Materia de Mecánica 1 en la Escuela de Ingeniería Civil.	5
7	1	Estructuras 1	Materia de Estructuras 1 en la Escuela de Ingeniería Civil.	3
8	1	Dibujo Técnico 1	Materia de Dibujo Técnico 1 en la Escuela de Ingeniería Civil.	4
9	1	Cálculo 2	Materia de Cálculo 2 en la Escuela de Ingeniería Civil.	5
10	1	Álgebra 2	Materia de Álgebra 2 en la Escuela de Ingeniería Civil.	3
11	1	Física 2	Materia de Física 2 en la Escuela de Ingeniería Civil.	4
12	1	Materiales 2	Materia de Materiales 2 en la Escuela de Ingeniería Civil.	5
13	1	Electrónica 2	Materia de Electrónica 2 en la Escuela de Ingeniería Civil.	3
14	1	Mecánica 2	Materia de Mecánica 2 en la Escuela de Ingeniería Civil.	4
15	1	Estructuras 2	Materia de Estructuras 2 en la Escuela de Ingeniería Civil.	5
16	1	Dibujo Técnico 2	Materia de Dibujo Técnico 2 en la Escuela de Ingeniería Civil.	3
17	1	Cálculo 3	Materia de Cálculo 3 en la Escuela de Ingeniería Civil.	4
18	1	Álgebra 3	Materia de Álgebra 3 en la Escuela de Ingeniería Civil.	5
19	1	Física 3	Materia de Física 3 en la Escuela de Ingeniería Civil.	3
20	1	Materiales 3	Materia de Materiales 3 en la Escuela de Ingeniería Civil.	4
21	1	Electrónica 3	Materia de Electrónica 3 en la Escuela de Ingeniería Civil.	5
22	1	Mecánica 3	Materia de Mecánica 3 en la Escuela de Ingeniería Civil.	3
23	1	Estructuras 3	Materia de Estructuras 3 en la Escuela de Ingeniería Civil.	4
24	1	Dibujo Técnico 3	Materia de Dibujo Técnico 3 en la Escuela de Ingeniería Civil.	5
25	1	Cálculo 4	Materia de Cálculo 4 en la Escuela de Ingeniería Civil.	3
26	1	Álgebra 4	Materia de Álgebra 4 en la Escuela de Ingeniería Civil.	4
27	1	Física 4	Materia de Física 4 en la Escuela de Ingeniería Civil.	5
28	1	Materiales 4	Materia de Materiales 4 en la Escuela de Ingeniería Civil.	3
29	1	Electrónica 4	Materia de Electrónica 4 en la Escuela de Ingeniería Civil.	4
30	1	Mecánica 4	Materia de Mecánica 4 en la Escuela de Ingeniería Civil.	5
31	1	Estructuras 4	Materia de Estructuras 4 en la Escuela de Ingeniería Civil.	3
32	1	Dibujo Técnico 4	Materia de Dibujo Técnico 4 en la Escuela de Ingeniería Civil.	4
33	1	Cálculo 5	Materia de Cálculo 5 en la Escuela de Ingeniería Civil.	5
34	1	Álgebra 5	Materia de Álgebra 5 en la Escuela de Ingeniería Civil.	3
35	1	Física 5	Materia de Física 5 en la Escuela de Ingeniería Civil.	4
36	1	Materiales 5	Materia de Materiales 5 en la Escuela de Ingeniería Civil.	5
37	1	Electrónica 5	Materia de Electrónica 5 en la Escuela de Ingeniería Civil.	3
38	1	Mecánica 5	Materia de Mecánica 5 en la Escuela de Ingeniería Civil.	4
39	1	Estructuras 5	Materia de Estructuras 5 en la Escuela de Ingeniería Civil.	5
40	1	Dibujo Técnico 5	Materia de Dibujo Técnico 5 en la Escuela de Ingeniería Civil.	3
41	2	Cálculo 1	Materia de Cálculo 1 en la Escuela de Ingeniería Mecánica.	3
42	2	Álgebra 1	Materia de Álgebra 1 en la Escuela de Ingeniería Mecánica.	4
43	2	Física 1	Materia de Física 1 en la Escuela de Ingeniería Mecánica.	5
44	2	Materiales 1	Materia de Materiales 1 en la Escuela de Ingeniería Mecánica.	3
45	2	Electrónica 1	Materia de Electrónica 1 en la Escuela de Ingeniería Mecánica.	4
46	2	Mecánica 1	Materia de Mecánica 1 en la Escuela de Ingeniería Mecánica.	5
47	2	Estructuras 1	Materia de Estructuras 1 en la Escuela de Ingeniería Mecánica.	3
48	2	Dibujo Técnico 1	Materia de Dibujo Técnico 1 en la Escuela de Ingeniería Mecánica.	4
49	2	Cálculo 2	Materia de Cálculo 2 en la Escuela de Ingeniería Mecánica.	5
50	2	Álgebra 2	Materia de Álgebra 2 en la Escuela de Ingeniería Mecánica.	3
51	2	Física 2	Materia de Física 2 en la Escuela de Ingeniería Mecánica.	4
52	2	Materiales 2	Materia de Materiales 2 en la Escuela de Ingeniería Mecánica.	5
53	2	Electrónica 2	Materia de Electrónica 2 en la Escuela de Ingeniería Mecánica.	3
54	2	Mecánica 2	Materia de Mecánica 2 en la Escuela de Ingeniería Mecánica.	4
55	2	Estructuras 2	Materia de Estructuras 2 en la Escuela de Ingeniería Mecánica.	5
56	2	Dibujo Técnico 2	Materia de Dibujo Técnico 2 en la Escuela de Ingeniería Mecánica.	3
57	2	Cálculo 3	Materia de Cálculo 3 en la Escuela de Ingeniería Mecánica.	4
58	2	Álgebra 3	Materia de Álgebra 3 en la Escuela de Ingeniería Mecánica.	5
59	2	Física 3	Materia de Física 3 en la Escuela de Ingeniería Mecánica.	3
60	2	Materiales 3	Materia de Materiales 3 en la Escuela de Ingeniería Mecánica.	4
61	2	Electrónica 3	Materia de Electrónica 3 en la Escuela de Ingeniería Mecánica.	5
62	2	Mecánica 3	Materia de Mecánica 3 en la Escuela de Ingeniería Mecánica.	3
63	2	Estructuras 3	Materia de Estructuras 3 en la Escuela de Ingeniería Mecánica.	4
64	2	Dibujo Técnico 3	Materia de Dibujo Técnico 3 en la Escuela de Ingeniería Mecánica.	5
65	2	Cálculo 4	Materia de Cálculo 4 en la Escuela de Ingeniería Mecánica.	3
66	2	Álgebra 4	Materia de Álgebra 4 en la Escuela de Ingeniería Mecánica.	4
67	2	Física 4	Materia de Física 4 en la Escuela de Ingeniería Mecánica.	5
68	2	Materiales 4	Materia de Materiales 4 en la Escuela de Ingeniería Mecánica.	3
69	2	Electrónica 4	Materia de Electrónica 4 en la Escuela de Ingeniería Mecánica.	4
70	2	Mecánica 4	Materia de Mecánica 4 en la Escuela de Ingeniería Mecánica.	5
71	2	Estructuras 4	Materia de Estructuras 4 en la Escuela de Ingeniería Mecánica.	3
72	2	Dibujo Técnico 4	Materia de Dibujo Técnico 4 en la Escuela de Ingeniería Mecánica.	4
73	2	Cálculo 5	Materia de Cálculo 5 en la Escuela de Ingeniería Mecánica.	5
74	2	Álgebra 5	Materia de Álgebra 5 en la Escuela de Ingeniería Mecánica.	3
75	2	Física 5	Materia de Física 5 en la Escuela de Ingeniería Mecánica.	4
76	2	Materiales 5	Materia de Materiales 5 en la Escuela de Ingeniería Mecánica.	5
77	2	Electrónica 5	Materia de Electrónica 5 en la Escuela de Ingeniería Mecánica.	3
78	2	Mecánica 5	Materia de Mecánica 5 en la Escuela de Ingeniería Mecánica.	4
79	2	Estructuras 5	Materia de Estructuras 5 en la Escuela de Ingeniería Mecánica.	5
80	2	Dibujo Técnico 5	Materia de Dibujo Técnico 5 en la Escuela de Ingeniería Mecánica.	3
81	3	Cálculo 1	Materia de Cálculo 1 en la Escuela de Ingeniería Electrónica.	3
82	3	Álgebra 1	Materia de Álgebra 1 en la Escuela de Ingeniería Electrónica.	4
83	3	Física 1	Materia de Física 1 en la Escuela de Ingeniería Electrónica.	5
84	3	Materiales 1	Materia de Materiales 1 en la Escuela de Ingeniería Electrónica.	3
85	3	Electrónica 1	Materia de Electrónica 1 en la Escuela de Ingeniería Electrónica.	4
86	3	Mecánica 1	Materia de Mecánica 1 en la Escuela de Ingeniería Electrónica.	5
87	3	Estructuras 1	Materia de Estructuras 1 en la Escuela de Ingeniería Electrónica.	3
88	3	Dibujo Técnico 1	Materia de Dibujo Técnico 1 en la Escuela de Ingeniería Electrónica.	4
89	3	Cálculo 2	Materia de Cálculo 2 en la Escuela de Ingeniería Electrónica.	5
90	3	Álgebra 2	Materia de Álgebra 2 en la Escuela de Ingeniería Electrónica.	3
91	3	Física 2	Materia de Física 2 en la Escuela de Ingeniería Electrónica.	4
92	3	Materiales 2	Materia de Materiales 2 en la Escuela de Ingeniería Electrónica.	5
93	3	Electrónica 2	Materia de Electrónica 2 en la Escuela de Ingeniería Electrónica.	3
94	3	Mecánica 2	Materia de Mecánica 2 en la Escuela de Ingeniería Electrónica.	4
95	3	Estructuras 2	Materia de Estructuras 2 en la Escuela de Ingeniería Electrónica.	5
96	3	Dibujo Técnico 2	Materia de Dibujo Técnico 2 en la Escuela de Ingeniería Electrónica.	3
97	3	Cálculo 3	Materia de Cálculo 3 en la Escuela de Ingeniería Electrónica.	4
98	3	Álgebra 3	Materia de Álgebra 3 en la Escuela de Ingeniería Electrónica.	5
99	3	Física 3	Materia de Física 3 en la Escuela de Ingeniería Electrónica.	3
100	3	Materiales 3	Materia de Materiales 3 en la Escuela de Ingeniería Electrónica.	4
101	3	Electrónica 3	Materia de Electrónica 3 en la Escuela de Ingeniería Electrónica.	5
102	3	Mecánica 3	Materia de Mecánica 3 en la Escuela de Ingeniería Electrónica.	3
103	3	Estructuras 3	Materia de Estructuras 3 en la Escuela de Ingeniería Electrónica.	4
104	3	Dibujo Técnico 3	Materia de Dibujo Técnico 3 en la Escuela de Ingeniería Electrónica.	5
105	3	Cálculo 4	Materia de Cálculo 4 en la Escuela de Ingeniería Electrónica.	3
106	3	Álgebra 4	Materia de Álgebra 4 en la Escuela de Ingeniería Electrónica.	4
107	3	Física 4	Materia de Física 4 en la Escuela de Ingeniería Electrónica.	5
108	3	Materiales 4	Materia de Materiales 4 en la Escuela de Ingeniería Electrónica.	3
109	3	Electrónica 4	Materia de Electrónica 4 en la Escuela de Ingeniería Electrónica.	4
110	3	Mecánica 4	Materia de Mecánica 4 en la Escuela de Ingeniería Electrónica.	5
111	3	Estructuras 4	Materia de Estructuras 4 en la Escuela de Ingeniería Electrónica.	3
112	3	Dibujo Técnico 4	Materia de Dibujo Técnico 4 en la Escuela de Ingeniería Electrónica.	4
113	3	Cálculo 5	Materia de Cálculo 5 en la Escuela de Ingeniería Electrónica.	5
114	3	Álgebra 5	Materia de Álgebra 5 en la Escuela de Ingeniería Electrónica.	3
115	3	Física 5	Materia de Física 5 en la Escuela de Ingeniería Electrónica.	4
116	3	Materiales 5	Materia de Materiales 5 en la Escuela de Ingeniería Electrónica.	5
117	3	Electrónica 5	Materia de Electrónica 5 en la Escuela de Ingeniería Electrónica.	3
118	3	Mecánica 5	Materia de Mecánica 5 en la Escuela de Ingeniería Electrónica.	4
119	3	Estructuras 5	Materia de Estructuras 5 en la Escuela de Ingeniería Electrónica.	5
120	3	Dibujo Técnico 5	Materia de Dibujo Técnico 5 en la Escuela de Ingeniería Electrónica.	3
121	4	Análisis Matemático 1	Materia de Análisis Matemático 1 en la Escuela de Matemáticas.	3
122	4	Álgebra Lineal 1	Materia de Álgebra Lineal 1 en la Escuela de Matemáticas.	4
123	4	Geometría 1	Materia de Geometría 1 en la Escuela de Matemáticas.	5
124	4	Física Moderna 1	Materia de Física Moderna 1 en la Escuela de Matemáticas.	3
125	4	Química General 1	Materia de Química General 1 en la Escuela de Matemáticas.	4
126	4	Estadística 1	Materia de Estadística 1 en la Escuela de Matemáticas.	5
127	4	Análisis Matemático 2	Materia de Análisis Matemático 2 en la Escuela de Matemáticas.	3
128	4	Álgebra Lineal 2	Materia de Álgebra Lineal 2 en la Escuela de Matemáticas.	4
129	4	Geometría 2	Materia de Geometría 2 en la Escuela de Matemáticas.	5
130	4	Física Moderna 2	Materia de Física Moderna 2 en la Escuela de Matemáticas.	3
131	4	Química General 2	Materia de Química General 2 en la Escuela de Matemáticas.	4
132	4	Estadística 2	Materia de Estadística 2 en la Escuela de Matemáticas.	5
133	4	Análisis Matemático 3	Materia de Análisis Matemático 3 en la Escuela de Matemáticas.	3
134	4	Álgebra Lineal 3	Materia de Álgebra Lineal 3 en la Escuela de Matemáticas.	4
135	4	Geometría 3	Materia de Geometría 3 en la Escuela de Matemáticas.	5
136	4	Física Moderna 3	Materia de Física Moderna 3 en la Escuela de Matemáticas.	3
137	4	Química General 3	Materia de Química General 3 en la Escuela de Matemáticas.	4
138	4	Estadística 3	Materia de Estadística 3 en la Escuela de Matemáticas.	5
139	4	Análisis Matemático 4	Materia de Análisis Matemático 4 en la Escuela de Matemáticas.	3
140	4	Álgebra Lineal 4	Materia de Álgebra Lineal 4 en la Escuela de Matemáticas.	4
141	4	Geometría 4	Materia de Geometría 4 en la Escuela de Matemáticas.	5
142	4	Física Moderna 4	Materia de Física Moderna 4 en la Escuela de Matemáticas.	3
143	4	Química General 4	Materia de Química General 4 en la Escuela de Matemáticas.	4
144	4	Estadística 4	Materia de Estadística 4 en la Escuela de Matemáticas.	5
145	4	Análisis Matemático 5	Materia de Análisis Matemático 5 en la Escuela de Matemáticas.	3
146	4	Álgebra Lineal 5	Materia de Álgebra Lineal 5 en la Escuela de Matemáticas.	4
147	4	Geometría 5	Materia de Geometría 5 en la Escuela de Matemáticas.	5
148	4	Física Moderna 5	Materia de Física Moderna 5 en la Escuela de Matemáticas.	3
149	4	Química General 5	Materia de Química General 5 en la Escuela de Matemáticas.	4
150	4	Estadística 5	Materia de Estadística 5 en la Escuela de Matemáticas.	5
151	4	Análisis Matemático 6	Materia de Análisis Matemático 6 en la Escuela de Matemáticas.	3
152	4	Álgebra Lineal 6	Materia de Álgebra Lineal 6 en la Escuela de Matemáticas.	4
153	4	Geometría 6	Materia de Geometría 6 en la Escuela de Matemáticas.	5
154	4	Física Moderna 6	Materia de Física Moderna 6 en la Escuela de Matemáticas.	3
155	4	Química General 6	Materia de Química General 6 en la Escuela de Matemáticas.	4
156	4	Estadística 6	Materia de Estadística 6 en la Escuela de Matemáticas.	5
157	4	Análisis Matemático 7	Materia de Análisis Matemático 7 en la Escuela de Matemáticas.	3
158	4	Álgebra Lineal 7	Materia de Álgebra Lineal 7 en la Escuela de Matemáticas.	4
159	4	Geometría 7	Materia de Geometría 7 en la Escuela de Matemáticas.	5
160	4	Física Moderna 7	Materia de Física Moderna 7 en la Escuela de Matemáticas.	3
161	5	Análisis Matemático 1	Materia de Análisis Matemático 1 en la Escuela de Física.	3
162	5	Álgebra Lineal 1	Materia de Álgebra Lineal 1 en la Escuela de Física.	4
163	5	Geometría 1	Materia de Geometría 1 en la Escuela de Física.	5
164	5	Física Moderna 1	Materia de Física Moderna 1 en la Escuela de Física.	3
165	5	Química General 1	Materia de Química General 1 en la Escuela de Física.	4
166	5	Estadística 1	Materia de Estadística 1 en la Escuela de Física.	5
167	5	Análisis Matemático 2	Materia de Análisis Matemático 2 en la Escuela de Física.	3
168	5	Álgebra Lineal 2	Materia de Álgebra Lineal 2 en la Escuela de Física.	4
169	5	Geometría 2	Materia de Geometría 2 en la Escuela de Física.	5
170	5	Física Moderna 2	Materia de Física Moderna 2 en la Escuela de Física.	3
171	5	Química General 2	Materia de Química General 2 en la Escuela de Física.	4
172	5	Estadística 2	Materia de Estadística 2 en la Escuela de Física.	5
173	5	Análisis Matemático 3	Materia de Análisis Matemático 3 en la Escuela de Física.	3
174	5	Álgebra Lineal 3	Materia de Álgebra Lineal 3 en la Escuela de Física.	4
175	5	Geometría 3	Materia de Geometría 3 en la Escuela de Física.	5
176	5	Física Moderna 3	Materia de Física Moderna 3 en la Escuela de Física.	3
177	5	Química General 3	Materia de Química General 3 en la Escuela de Física.	4
178	5	Estadística 3	Materia de Estadística 3 en la Escuela de Física.	5
179	5	Análisis Matemático 4	Materia de Análisis Matemático 4 en la Escuela de Física.	3
180	5	Álgebra Lineal 4	Materia de Álgebra Lineal 4 en la Escuela de Física.	4
181	5	Geometría 4	Materia de Geometría 4 en la Escuela de Física.	5
182	5	Física Moderna 4	Materia de Física Moderna 4 en la Escuela de Física.	3
183	5	Química General 4	Materia de Química General 4 en la Escuela de Física.	4
184	5	Estadística 4	Materia de Estadística 4 en la Escuela de Física.	5
185	5	Análisis Matemático 5	Materia de Análisis Matemático 5 en la Escuela de Física.	3
186	5	Álgebra Lineal 5	Materia de Álgebra Lineal 5 en la Escuela de Física.	4
187	5	Geometría 5	Materia de Geometría 5 en la Escuela de Física.	5
188	5	Física Moderna 5	Materia de Física Moderna 5 en la Escuela de Física.	3
189	5	Química General 5	Materia de Química General 5 en la Escuela de Física.	4
190	5	Estadística 5	Materia de Estadística 5 en la Escuela de Física.	5
191	5	Análisis Matemático 6	Materia de Análisis Matemático 6 en la Escuela de Física.	3
192	5	Álgebra Lineal 6	Materia de Álgebra Lineal 6 en la Escuela de Física.	4
193	5	Geometría 6	Materia de Geometría 6 en la Escuela de Física.	5
194	5	Física Moderna 6	Materia de Física Moderna 6 en la Escuela de Física.	3
195	5	Química General 6	Materia de Química General 6 en la Escuela de Física.	4
196	5	Estadística 6	Materia de Estadística 6 en la Escuela de Física.	5
197	5	Análisis Matemático 7	Materia de Análisis Matemático 7 en la Escuela de Física.	3
198	5	Álgebra Lineal 7	Materia de Álgebra Lineal 7 en la Escuela de Física.	4
199	5	Geometría 7	Materia de Geometría 7 en la Escuela de Física.	5
200	5	Física Moderna 7	Materia de Física Moderna 7 en la Escuela de Física.	3
201	6	Análisis Matemático 1	Materia de Análisis Matemático 1 en la Escuela de Química.	3
202	6	Álgebra Lineal 1	Materia de Álgebra Lineal 1 en la Escuela de Química.	4
203	6	Geometría 1	Materia de Geometría 1 en la Escuela de Química.	5
204	6	Física Moderna 1	Materia de Física Moderna 1 en la Escuela de Química.	3
205	6	Química General 1	Materia de Química General 1 en la Escuela de Química.	4
206	6	Estadística 1	Materia de Estadística 1 en la Escuela de Química.	5
207	6	Análisis Matemático 2	Materia de Análisis Matemático 2 en la Escuela de Química.	3
208	6	Álgebra Lineal 2	Materia de Álgebra Lineal 2 en la Escuela de Química.	4
209	6	Geometría 2	Materia de Geometría 2 en la Escuela de Química.	5
210	6	Física Moderna 2	Materia de Física Moderna 2 en la Escuela de Química.	3
211	6	Química General 2	Materia de Química General 2 en la Escuela de Química.	4
212	6	Estadística 2	Materia de Estadística 2 en la Escuela de Química.	5
213	6	Análisis Matemático 3	Materia de Análisis Matemático 3 en la Escuela de Química.	3
214	6	Álgebra Lineal 3	Materia de Álgebra Lineal 3 en la Escuela de Química.	4
215	6	Geometría 3	Materia de Geometría 3 en la Escuela de Química.	5
216	6	Física Moderna 3	Materia de Física Moderna 3 en la Escuela de Química.	3
217	6	Química General 3	Materia de Química General 3 en la Escuela de Química.	4
218	6	Estadística 3	Materia de Estadística 3 en la Escuela de Química.	5
219	6	Análisis Matemático 4	Materia de Análisis Matemático 4 en la Escuela de Química.	3
220	6	Álgebra Lineal 4	Materia de Álgebra Lineal 4 en la Escuela de Química.	4
221	6	Geometría 4	Materia de Geometría 4 en la Escuela de Química.	5
222	6	Física Moderna 4	Materia de Física Moderna 4 en la Escuela de Química.	3
223	6	Química General 4	Materia de Química General 4 en la Escuela de Química.	4
224	6	Estadística 4	Materia de Estadística 4 en la Escuela de Química.	5
225	6	Análisis Matemático 5	Materia de Análisis Matemático 5 en la Escuela de Química.	3
226	6	Álgebra Lineal 5	Materia de Álgebra Lineal 5 en la Escuela de Química.	4
227	6	Geometría 5	Materia de Geometría 5 en la Escuela de Química.	5
228	6	Física Moderna 5	Materia de Física Moderna 5 en la Escuela de Química.	3
229	6	Química General 5	Materia de Química General 5 en la Escuela de Química.	4
230	6	Estadística 5	Materia de Estadística 5 en la Escuela de Química.	5
231	6	Análisis Matemático 6	Materia de Análisis Matemático 6 en la Escuela de Química.	3
232	6	Álgebra Lineal 6	Materia de Álgebra Lineal 6 en la Escuela de Química.	4
233	6	Geometría 6	Materia de Geometría 6 en la Escuela de Química.	5
234	6	Física Moderna 6	Materia de Física Moderna 6 en la Escuela de Química.	3
235	6	Química General 6	Materia de Química General 6 en la Escuela de Química.	4
236	6	Estadística 6	Materia de Estadística 6 en la Escuela de Química.	5
237	6	Análisis Matemático 7	Materia de Análisis Matemático 7 en la Escuela de Química.	3
238	6	Álgebra Lineal 7	Materia de Álgebra Lineal 7 en la Escuela de Química.	4
239	6	Geometría 7	Materia de Geometría 7 en la Escuela de Química.	5
240	6	Física Moderna 7	Materia de Física Moderna 7 en la Escuela de Química.	3
241	7	Anatomía 1	Materia de Anatomía 1 en la Escuela de Medicina General.	3
242	7	Fisiología 1	Materia de Fisiología 1 en la Escuela de Medicina General.	4
243	7	Bioquímica 1	Materia de Bioquímica 1 en la Escuela de Medicina General.	5
244	7	Microbiología 1	Materia de Microbiología 1 en la Escuela de Medicina General.	3
245	7	Farmacología 1	Materia de Farmacología 1 en la Escuela de Medicina General.	4
246	7	Nutrición 1	Materia de Nutrición 1 en la Escuela de Medicina General.	5
247	7	Pediatría 1	Materia de Pediatría 1 en la Escuela de Medicina General.	3
248	7	Cirugía 1	Materia de Cirugía 1 en la Escuela de Medicina General.	4
249	7	Anatomía 2	Materia de Anatomía 2 en la Escuela de Medicina General.	5
250	7	Fisiología 2	Materia de Fisiología 2 en la Escuela de Medicina General.	3
251	7	Bioquímica 2	Materia de Bioquímica 2 en la Escuela de Medicina General.	4
252	7	Microbiología 2	Materia de Microbiología 2 en la Escuela de Medicina General.	5
253	7	Farmacología 2	Materia de Farmacología 2 en la Escuela de Medicina General.	3
254	7	Nutrición 2	Materia de Nutrición 2 en la Escuela de Medicina General.	4
255	7	Pediatría 2	Materia de Pediatría 2 en la Escuela de Medicina General.	5
256	7	Cirugía 2	Materia de Cirugía 2 en la Escuela de Medicina General.	3
257	7	Anatomía 3	Materia de Anatomía 3 en la Escuela de Medicina General.	4
258	7	Fisiología 3	Materia de Fisiología 3 en la Escuela de Medicina General.	5
259	7	Bioquímica 3	Materia de Bioquímica 3 en la Escuela de Medicina General.	3
260	7	Microbiología 3	Materia de Microbiología 3 en la Escuela de Medicina General.	4
261	7	Farmacología 3	Materia de Farmacología 3 en la Escuela de Medicina General.	5
262	7	Nutrición 3	Materia de Nutrición 3 en la Escuela de Medicina General.	3
263	7	Pediatría 3	Materia de Pediatría 3 en la Escuela de Medicina General.	4
264	7	Cirugía 3	Materia de Cirugía 3 en la Escuela de Medicina General.	5
265	7	Anatomía 4	Materia de Anatomía 4 en la Escuela de Medicina General.	3
266	7	Fisiología 4	Materia de Fisiología 4 en la Escuela de Medicina General.	4
267	7	Bioquímica 4	Materia de Bioquímica 4 en la Escuela de Medicina General.	5
268	7	Microbiología 4	Materia de Microbiología 4 en la Escuela de Medicina General.	3
269	7	Farmacología 4	Materia de Farmacología 4 en la Escuela de Medicina General.	4
270	7	Nutrición 4	Materia de Nutrición 4 en la Escuela de Medicina General.	5
271	7	Pediatría 4	Materia de Pediatría 4 en la Escuela de Medicina General.	3
272	7	Cirugía 4	Materia de Cirugía 4 en la Escuela de Medicina General.	4
273	7	Anatomía 5	Materia de Anatomía 5 en la Escuela de Medicina General.	5
274	7	Fisiología 5	Materia de Fisiología 5 en la Escuela de Medicina General.	3
275	7	Bioquímica 5	Materia de Bioquímica 5 en la Escuela de Medicina General.	4
276	7	Microbiología 5	Materia de Microbiología 5 en la Escuela de Medicina General.	5
277	7	Farmacología 5	Materia de Farmacología 5 en la Escuela de Medicina General.	3
278	7	Nutrición 5	Materia de Nutrición 5 en la Escuela de Medicina General.	4
279	7	Pediatría 5	Materia de Pediatría 5 en la Escuela de Medicina General.	5
280	7	Cirugía 5	Materia de Cirugía 5 en la Escuela de Medicina General.	3
281	8	Anatomía 1	Materia de Anatomía 1 en la Escuela de Enfermería.	3
282	8	Fisiología 1	Materia de Fisiología 1 en la Escuela de Enfermería.	4
283	8	Bioquímica 1	Materia de Bioquímica 1 en la Escuela de Enfermería.	5
284	8	Microbiología 1	Materia de Microbiología 1 en la Escuela de Enfermería.	3
285	8	Farmacología 1	Materia de Farmacología 1 en la Escuela de Enfermería.	4
286	8	Nutrición 1	Materia de Nutrición 1 en la Escuela de Enfermería.	5
287	8	Pediatría 1	Materia de Pediatría 1 en la Escuela de Enfermería.	3
288	8	Cirugía 1	Materia de Cirugía 1 en la Escuela de Enfermería.	4
289	8	Anatomía 2	Materia de Anatomía 2 en la Escuela de Enfermería.	5
290	8	Fisiología 2	Materia de Fisiología 2 en la Escuela de Enfermería.	3
291	8	Bioquímica 2	Materia de Bioquímica 2 en la Escuela de Enfermería.	4
292	8	Microbiología 2	Materia de Microbiología 2 en la Escuela de Enfermería.	5
293	8	Farmacología 2	Materia de Farmacología 2 en la Escuela de Enfermería.	3
294	8	Nutrición 2	Materia de Nutrición 2 en la Escuela de Enfermería.	4
295	8	Pediatría 2	Materia de Pediatría 2 en la Escuela de Enfermería.	5
296	8	Cirugía 2	Materia de Cirugía 2 en la Escuela de Enfermería.	3
297	8	Anatomía 3	Materia de Anatomía 3 en la Escuela de Enfermería.	4
298	8	Fisiología 3	Materia de Fisiología 3 en la Escuela de Enfermería.	5
299	8	Bioquímica 3	Materia de Bioquímica 3 en la Escuela de Enfermería.	3
300	8	Microbiología 3	Materia de Microbiología 3 en la Escuela de Enfermería.	4
301	8	Farmacología 3	Materia de Farmacología 3 en la Escuela de Enfermería.	5
302	8	Nutrición 3	Materia de Nutrición 3 en la Escuela de Enfermería.	3
303	8	Pediatría 3	Materia de Pediatría 3 en la Escuela de Enfermería.	4
304	8	Cirugía 3	Materia de Cirugía 3 en la Escuela de Enfermería.	5
305	8	Anatomía 4	Materia de Anatomía 4 en la Escuela de Enfermería.	3
306	8	Fisiología 4	Materia de Fisiología 4 en la Escuela de Enfermería.	4
307	8	Bioquímica 4	Materia de Bioquímica 4 en la Escuela de Enfermería.	5
308	8	Microbiología 4	Materia de Microbiología 4 en la Escuela de Enfermería.	3
309	8	Farmacología 4	Materia de Farmacología 4 en la Escuela de Enfermería.	4
310	8	Nutrición 4	Materia de Nutrición 4 en la Escuela de Enfermería.	5
311	8	Pediatría 4	Materia de Pediatría 4 en la Escuela de Enfermería.	3
312	8	Cirugía 4	Materia de Cirugía 4 en la Escuela de Enfermería.	4
313	8	Anatomía 5	Materia de Anatomía 5 en la Escuela de Enfermería.	5
314	8	Fisiología 5	Materia de Fisiología 5 en la Escuela de Enfermería.	3
315	8	Bioquímica 5	Materia de Bioquímica 5 en la Escuela de Enfermería.	4
316	8	Microbiología 5	Materia de Microbiología 5 en la Escuela de Enfermería.	5
317	8	Farmacología 5	Materia de Farmacología 5 en la Escuela de Enfermería.	3
318	8	Nutrición 5	Materia de Nutrición 5 en la Escuela de Enfermería.	4
319	8	Pediatría 5	Materia de Pediatría 5 en la Escuela de Enfermería.	5
320	8	Cirugía 5	Materia de Cirugía 5 en la Escuela de Enfermería.	3
321	9	Anatomía 1	Materia de Anatomía 1 en la Escuela de Nutrición.	3
322	9	Fisiología 1	Materia de Fisiología 1 en la Escuela de Nutrición.	4
323	9	Bioquímica 1	Materia de Bioquímica 1 en la Escuela de Nutrición.	5
324	9	Microbiología 1	Materia de Microbiología 1 en la Escuela de Nutrición.	3
325	9	Farmacología 1	Materia de Farmacología 1 en la Escuela de Nutrición.	4
326	9	Nutrición 1	Materia de Nutrición 1 en la Escuela de Nutrición.	5
327	9	Pediatría 1	Materia de Pediatría 1 en la Escuela de Nutrición.	3
328	9	Cirugía 1	Materia de Cirugía 1 en la Escuela de Nutrición.	4
329	9	Anatomía 2	Materia de Anatomía 2 en la Escuela de Nutrición.	5
330	9	Fisiología 2	Materia de Fisiología 2 en la Escuela de Nutrición.	3
331	9	Bioquímica 2	Materia de Bioquímica 2 en la Escuela de Nutrición.	4
332	9	Microbiología 2	Materia de Microbiología 2 en la Escuela de Nutrición.	5
333	9	Farmacología 2	Materia de Farmacología 2 en la Escuela de Nutrición.	3
334	9	Nutrición 2	Materia de Nutrición 2 en la Escuela de Nutrición.	4
335	9	Pediatría 2	Materia de Pediatría 2 en la Escuela de Nutrición.	5
336	9	Cirugía 2	Materia de Cirugía 2 en la Escuela de Nutrición.	3
337	9	Anatomía 3	Materia de Anatomía 3 en la Escuela de Nutrición.	4
338	9	Fisiología 3	Materia de Fisiología 3 en la Escuela de Nutrición.	5
339	9	Bioquímica 3	Materia de Bioquímica 3 en la Escuela de Nutrición.	3
340	9	Microbiología 3	Materia de Microbiología 3 en la Escuela de Nutrición.	4
341	9	Farmacología 3	Materia de Farmacología 3 en la Escuela de Nutrición.	5
342	9	Nutrición 3	Materia de Nutrición 3 en la Escuela de Nutrición.	3
343	9	Pediatría 3	Materia de Pediatría 3 en la Escuela de Nutrición.	4
344	9	Cirugía 3	Materia de Cirugía 3 en la Escuela de Nutrición.	5
345	9	Anatomía 4	Materia de Anatomía 4 en la Escuela de Nutrición.	3
346	9	Fisiología 4	Materia de Fisiología 4 en la Escuela de Nutrición.	4
347	9	Bioquímica 4	Materia de Bioquímica 4 en la Escuela de Nutrición.	5
348	9	Microbiología 4	Materia de Microbiología 4 en la Escuela de Nutrición.	3
349	9	Farmacología 4	Materia de Farmacología 4 en la Escuela de Nutrición.	4
350	9	Nutrición 4	Materia de Nutrición 4 en la Escuela de Nutrición.	5
351	9	Pediatría 4	Materia de Pediatría 4 en la Escuela de Nutrición.	3
352	9	Cirugía 4	Materia de Cirugía 4 en la Escuela de Nutrición.	4
353	9	Anatomía 5	Materia de Anatomía 5 en la Escuela de Nutrición.	5
354	9	Fisiología 5	Materia de Fisiología 5 en la Escuela de Nutrición.	3
355	9	Bioquímica 5	Materia de Bioquímica 5 en la Escuela de Nutrición.	4
356	9	Microbiología 5	Materia de Microbiología 5 en la Escuela de Nutrición.	5
357	9	Farmacología 5	Materia de Farmacología 5 en la Escuela de Nutrición.	3
358	9	Nutrición 5	Materia de Nutrición 5 en la Escuela de Nutrición.	4
359	9	Pediatría 5	Materia de Pediatría 5 en la Escuela de Nutrición.	5
360	9	Cirugía 5	Materia de Cirugía 5 en la Escuela de Nutrición.	3
361	10	Derecho Penal 1	Materia de Derecho Penal 1 en la Escuela de Derecho Penal.	3
362	10	Derecho Civil 1	Materia de Derecho Civil 1 en la Escuela de Derecho Penal.	4
363	10	Derecho Constitucional 1	Materia de Derecho Constitucional 1 en la Escuela de Derecho Penal.	5
364	10	Derecho Internacional 1	Materia de Derecho Internacional 1 en la Escuela de Derecho Penal.	3
365	10	Derecho Mercantil 1	Materia de Derecho Mercantil 1 en la Escuela de Derecho Penal.	4
366	10	Derecho Procesal 1	Materia de Derecho Procesal 1 en la Escuela de Derecho Penal.	5
367	10	Derecho Penal 2	Materia de Derecho Penal 2 en la Escuela de Derecho Penal.	3
368	10	Derecho Civil 2	Materia de Derecho Civil 2 en la Escuela de Derecho Penal.	4
369	10	Derecho Constitucional 2	Materia de Derecho Constitucional 2 en la Escuela de Derecho Penal.	5
370	10	Derecho Internacional 2	Materia de Derecho Internacional 2 en la Escuela de Derecho Penal.	3
371	10	Derecho Mercantil 2	Materia de Derecho Mercantil 2 en la Escuela de Derecho Penal.	4
372	10	Derecho Procesal 2	Materia de Derecho Procesal 2 en la Escuela de Derecho Penal.	5
373	10	Derecho Penal 3	Materia de Derecho Penal 3 en la Escuela de Derecho Penal.	3
374	10	Derecho Civil 3	Materia de Derecho Civil 3 en la Escuela de Derecho Penal.	4
375	10	Derecho Constitucional 3	Materia de Derecho Constitucional 3 en la Escuela de Derecho Penal.	5
376	10	Derecho Internacional 3	Materia de Derecho Internacional 3 en la Escuela de Derecho Penal.	3
377	10	Derecho Mercantil 3	Materia de Derecho Mercantil 3 en la Escuela de Derecho Penal.	4
378	10	Derecho Procesal 3	Materia de Derecho Procesal 3 en la Escuela de Derecho Penal.	5
379	10	Derecho Penal 4	Materia de Derecho Penal 4 en la Escuela de Derecho Penal.	3
380	10	Derecho Civil 4	Materia de Derecho Civil 4 en la Escuela de Derecho Penal.	4
381	10	Derecho Constitucional 4	Materia de Derecho Constitucional 4 en la Escuela de Derecho Penal.	5
382	10	Derecho Internacional 4	Materia de Derecho Internacional 4 en la Escuela de Derecho Penal.	3
383	10	Derecho Mercantil 4	Materia de Derecho Mercantil 4 en la Escuela de Derecho Penal.	4
384	10	Derecho Procesal 4	Materia de Derecho Procesal 4 en la Escuela de Derecho Penal.	5
385	10	Derecho Penal 5	Materia de Derecho Penal 5 en la Escuela de Derecho Penal.	3
386	10	Derecho Civil 5	Materia de Derecho Civil 5 en la Escuela de Derecho Penal.	4
387	10	Derecho Constitucional 5	Materia de Derecho Constitucional 5 en la Escuela de Derecho Penal.	5
388	10	Derecho Internacional 5	Materia de Derecho Internacional 5 en la Escuela de Derecho Penal.	3
389	10	Derecho Mercantil 5	Materia de Derecho Mercantil 5 en la Escuela de Derecho Penal.	4
390	10	Derecho Procesal 5	Materia de Derecho Procesal 5 en la Escuela de Derecho Penal.	5
391	10	Derecho Penal 6	Materia de Derecho Penal 6 en la Escuela de Derecho Penal.	3
392	10	Derecho Civil 6	Materia de Derecho Civil 6 en la Escuela de Derecho Penal.	4
393	10	Derecho Constitucional 6	Materia de Derecho Constitucional 6 en la Escuela de Derecho Penal.	5
394	10	Derecho Internacional 6	Materia de Derecho Internacional 6 en la Escuela de Derecho Penal.	3
395	10	Derecho Mercantil 6	Materia de Derecho Mercantil 6 en la Escuela de Derecho Penal.	4
396	10	Derecho Procesal 6	Materia de Derecho Procesal 6 en la Escuela de Derecho Penal.	5
397	10	Derecho Penal 7	Materia de Derecho Penal 7 en la Escuela de Derecho Penal.	3
398	10	Derecho Civil 7	Materia de Derecho Civil 7 en la Escuela de Derecho Penal.	4
399	10	Derecho Constitucional 7	Materia de Derecho Constitucional 7 en la Escuela de Derecho Penal.	5
400	10	Derecho Internacional 7	Materia de Derecho Internacional 7 en la Escuela de Derecho Penal.	3
401	11	Derecho Penal 1	Materia de Derecho Penal 1 en la Escuela de Derecho Civil.	3
402	11	Derecho Civil 1	Materia de Derecho Civil 1 en la Escuela de Derecho Civil.	4
403	11	Derecho Constitucional 1	Materia de Derecho Constitucional 1 en la Escuela de Derecho Civil.	5
404	11	Derecho Internacional 1	Materia de Derecho Internacional 1 en la Escuela de Derecho Civil.	3
405	11	Derecho Mercantil 1	Materia de Derecho Mercantil 1 en la Escuela de Derecho Civil.	4
406	11	Derecho Procesal 1	Materia de Derecho Procesal 1 en la Escuela de Derecho Civil.	5
407	11	Derecho Penal 2	Materia de Derecho Penal 2 en la Escuela de Derecho Civil.	3
408	11	Derecho Civil 2	Materia de Derecho Civil 2 en la Escuela de Derecho Civil.	4
409	11	Derecho Constitucional 2	Materia de Derecho Constitucional 2 en la Escuela de Derecho Civil.	5
410	11	Derecho Internacional 2	Materia de Derecho Internacional 2 en la Escuela de Derecho Civil.	3
411	11	Derecho Mercantil 2	Materia de Derecho Mercantil 2 en la Escuela de Derecho Civil.	4
412	11	Derecho Procesal 2	Materia de Derecho Procesal 2 en la Escuela de Derecho Civil.	5
413	11	Derecho Penal 3	Materia de Derecho Penal 3 en la Escuela de Derecho Civil.	3
414	11	Derecho Civil 3	Materia de Derecho Civil 3 en la Escuela de Derecho Civil.	4
415	11	Derecho Constitucional 3	Materia de Derecho Constitucional 3 en la Escuela de Derecho Civil.	5
416	11	Derecho Internacional 3	Materia de Derecho Internacional 3 en la Escuela de Derecho Civil.	3
417	11	Derecho Mercantil 3	Materia de Derecho Mercantil 3 en la Escuela de Derecho Civil.	4
418	11	Derecho Procesal 3	Materia de Derecho Procesal 3 en la Escuela de Derecho Civil.	5
419	11	Derecho Penal 4	Materia de Derecho Penal 4 en la Escuela de Derecho Civil.	3
420	11	Derecho Civil 4	Materia de Derecho Civil 4 en la Escuela de Derecho Civil.	4
421	11	Derecho Constitucional 4	Materia de Derecho Constitucional 4 en la Escuela de Derecho Civil.	5
422	11	Derecho Internacional 4	Materia de Derecho Internacional 4 en la Escuela de Derecho Civil.	3
423	11	Derecho Mercantil 4	Materia de Derecho Mercantil 4 en la Escuela de Derecho Civil.	4
424	11	Derecho Procesal 4	Materia de Derecho Procesal 4 en la Escuela de Derecho Civil.	5
425	11	Derecho Penal 5	Materia de Derecho Penal 5 en la Escuela de Derecho Civil.	3
426	11	Derecho Civil 5	Materia de Derecho Civil 5 en la Escuela de Derecho Civil.	4
427	11	Derecho Constitucional 5	Materia de Derecho Constitucional 5 en la Escuela de Derecho Civil.	5
428	11	Derecho Internacional 5	Materia de Derecho Internacional 5 en la Escuela de Derecho Civil.	3
429	11	Derecho Mercantil 5	Materia de Derecho Mercantil 5 en la Escuela de Derecho Civil.	4
430	11	Derecho Procesal 5	Materia de Derecho Procesal 5 en la Escuela de Derecho Civil.	5
431	11	Derecho Penal 6	Materia de Derecho Penal 6 en la Escuela de Derecho Civil.	3
432	11	Derecho Civil 6	Materia de Derecho Civil 6 en la Escuela de Derecho Civil.	4
433	11	Derecho Constitucional 6	Materia de Derecho Constitucional 6 en la Escuela de Derecho Civil.	5
434	11	Derecho Internacional 6	Materia de Derecho Internacional 6 en la Escuela de Derecho Civil.	3
435	11	Derecho Mercantil 6	Materia de Derecho Mercantil 6 en la Escuela de Derecho Civil.	4
436	11	Derecho Procesal 6	Materia de Derecho Procesal 6 en la Escuela de Derecho Civil.	5
437	11	Derecho Penal 7	Materia de Derecho Penal 7 en la Escuela de Derecho Civil.	3
438	11	Derecho Civil 7	Materia de Derecho Civil 7 en la Escuela de Derecho Civil.	4
439	11	Derecho Constitucional 7	Materia de Derecho Constitucional 7 en la Escuela de Derecho Civil.	5
440	11	Derecho Internacional 7	Materia de Derecho Internacional 7 en la Escuela de Derecho Civil.	3
441	12	Derecho Penal 1	Materia de Derecho Penal 1 en la Escuela de Derecho Internacional.	3
442	12	Derecho Civil 1	Materia de Derecho Civil 1 en la Escuela de Derecho Internacional.	4
443	12	Derecho Constitucional 1	Materia de Derecho Constitucional 1 en la Escuela de Derecho Internacional.	5
444	12	Derecho Internacional 1	Materia de Derecho Internacional 1 en la Escuela de Derecho Internacional.	3
445	12	Derecho Mercantil 1	Materia de Derecho Mercantil 1 en la Escuela de Derecho Internacional.	4
446	12	Derecho Procesal 1	Materia de Derecho Procesal 1 en la Escuela de Derecho Internacional.	5
447	12	Derecho Penal 2	Materia de Derecho Penal 2 en la Escuela de Derecho Internacional.	3
448	12	Derecho Civil 2	Materia de Derecho Civil 2 en la Escuela de Derecho Internacional.	4
449	12	Derecho Constitucional 2	Materia de Derecho Constitucional 2 en la Escuela de Derecho Internacional.	5
450	12	Derecho Internacional 2	Materia de Derecho Internacional 2 en la Escuela de Derecho Internacional.	3
451	12	Derecho Mercantil 2	Materia de Derecho Mercantil 2 en la Escuela de Derecho Internacional.	4
452	12	Derecho Procesal 2	Materia de Derecho Procesal 2 en la Escuela de Derecho Internacional.	5
453	12	Derecho Penal 3	Materia de Derecho Penal 3 en la Escuela de Derecho Internacional.	3
454	12	Derecho Civil 3	Materia de Derecho Civil 3 en la Escuela de Derecho Internacional.	4
455	12	Derecho Constitucional 3	Materia de Derecho Constitucional 3 en la Escuela de Derecho Internacional.	5
456	12	Derecho Internacional 3	Materia de Derecho Internacional 3 en la Escuela de Derecho Internacional.	3
457	12	Derecho Mercantil 3	Materia de Derecho Mercantil 3 en la Escuela de Derecho Internacional.	4
458	12	Derecho Procesal 3	Materia de Derecho Procesal 3 en la Escuela de Derecho Internacional.	5
459	12	Derecho Penal 4	Materia de Derecho Penal 4 en la Escuela de Derecho Internacional.	3
460	12	Derecho Civil 4	Materia de Derecho Civil 4 en la Escuela de Derecho Internacional.	4
461	12	Derecho Constitucional 4	Materia de Derecho Constitucional 4 en la Escuela de Derecho Internacional.	5
462	12	Derecho Internacional 4	Materia de Derecho Internacional 4 en la Escuela de Derecho Internacional.	3
463	12	Derecho Mercantil 4	Materia de Derecho Mercantil 4 en la Escuela de Derecho Internacional.	4
464	12	Derecho Procesal 4	Materia de Derecho Procesal 4 en la Escuela de Derecho Internacional.	5
465	12	Derecho Penal 5	Materia de Derecho Penal 5 en la Escuela de Derecho Internacional.	3
466	12	Derecho Civil 5	Materia de Derecho Civil 5 en la Escuela de Derecho Internacional.	4
467	12	Derecho Constitucional 5	Materia de Derecho Constitucional 5 en la Escuela de Derecho Internacional.	5
468	12	Derecho Internacional 5	Materia de Derecho Internacional 5 en la Escuela de Derecho Internacional.	3
469	12	Derecho Mercantil 5	Materia de Derecho Mercantil 5 en la Escuela de Derecho Internacional.	4
470	12	Derecho Procesal 5	Materia de Derecho Procesal 5 en la Escuela de Derecho Internacional.	5
471	12	Derecho Penal 6	Materia de Derecho Penal 6 en la Escuela de Derecho Internacional.	3
472	12	Derecho Civil 6	Materia de Derecho Civil 6 en la Escuela de Derecho Internacional.	4
473	12	Derecho Constitucional 6	Materia de Derecho Constitucional 6 en la Escuela de Derecho Internacional.	5
474	12	Derecho Internacional 6	Materia de Derecho Internacional 6 en la Escuela de Derecho Internacional.	3
475	12	Derecho Mercantil 6	Materia de Derecho Mercantil 6 en la Escuela de Derecho Internacional.	4
476	12	Derecho Procesal 6	Materia de Derecho Procesal 6 en la Escuela de Derecho Internacional.	5
477	12	Derecho Penal 7	Materia de Derecho Penal 7 en la Escuela de Derecho Internacional.	3
478	12	Derecho Civil 7	Materia de Derecho Civil 7 en la Escuela de Derecho Internacional.	4
479	12	Derecho Constitucional 7	Materia de Derecho Constitucional 7 en la Escuela de Derecho Internacional.	5
480	12	Derecho Internacional 7	Materia de Derecho Internacional 7 en la Escuela de Derecho Internacional.	3
481	13	Contabilidad 1	Materia de Contabilidad 1 en la Escuela de Administración.	3
482	13	Gestión Empresarial 1	Materia de Gestión Empresarial 1 en la Escuela de Administración.	4
483	13	Marketing 1	Materia de Marketing 1 en la Escuela de Administración.	5
484	13	Economía 1	Materia de Economía 1 en la Escuela de Administración.	3
485	13	Finanzas 1	Materia de Finanzas 1 en la Escuela de Administración.	4
486	13	Estadística 1	Materia de Estadística 1 en la Escuela de Administración.	5
487	13	Contabilidad 2	Materia de Contabilidad 2 en la Escuela de Administración.	3
488	13	Gestión Empresarial 2	Materia de Gestión Empresarial 2 en la Escuela de Administración.	4
489	13	Marketing 2	Materia de Marketing 2 en la Escuela de Administración.	5
490	13	Economía 2	Materia de Economía 2 en la Escuela de Administración.	3
491	13	Finanzas 2	Materia de Finanzas 2 en la Escuela de Administración.	4
492	13	Estadística 2	Materia de Estadística 2 en la Escuela de Administración.	5
493	13	Contabilidad 3	Materia de Contabilidad 3 en la Escuela de Administración.	3
494	13	Gestión Empresarial 3	Materia de Gestión Empresarial 3 en la Escuela de Administración.	4
495	13	Marketing 3	Materia de Marketing 3 en la Escuela de Administración.	5
496	13	Economía 3	Materia de Economía 3 en la Escuela de Administración.	3
497	13	Finanzas 3	Materia de Finanzas 3 en la Escuela de Administración.	4
498	13	Estadística 3	Materia de Estadística 3 en la Escuela de Administración.	5
499	13	Contabilidad 4	Materia de Contabilidad 4 en la Escuela de Administración.	3
500	13	Gestión Empresarial 4	Materia de Gestión Empresarial 4 en la Escuela de Administración.	4
501	13	Marketing 4	Materia de Marketing 4 en la Escuela de Administración.	5
502	13	Economía 4	Materia de Economía 4 en la Escuela de Administración.	3
503	13	Finanzas 4	Materia de Finanzas 4 en la Escuela de Administración.	4
504	13	Estadística 4	Materia de Estadística 4 en la Escuela de Administración.	5
505	13	Contabilidad 5	Materia de Contabilidad 5 en la Escuela de Administración.	3
506	13	Gestión Empresarial 5	Materia de Gestión Empresarial 5 en la Escuela de Administración.	4
507	13	Marketing 5	Materia de Marketing 5 en la Escuela de Administración.	5
508	13	Economía 5	Materia de Economía 5 en la Escuela de Administración.	3
509	13	Finanzas 5	Materia de Finanzas 5 en la Escuela de Administración.	4
510	13	Estadística 5	Materia de Estadística 5 en la Escuela de Administración.	5
511	13	Contabilidad 6	Materia de Contabilidad 6 en la Escuela de Administración.	3
583	15	Finanzas 4	Materia de Finanzas 4 en la Escuela de Finanzas.	4
512	13	Gestión Empresarial 6	Materia de Gestión Empresarial 6 en la Escuela de Administración.	4
513	13	Marketing 6	Materia de Marketing 6 en la Escuela de Administración.	5
514	13	Economía 6	Materia de Economía 6 en la Escuela de Administración.	3
515	13	Finanzas 6	Materia de Finanzas 6 en la Escuela de Administración.	4
516	13	Estadística 6	Materia de Estadística 6 en la Escuela de Administración.	5
517	13	Contabilidad 7	Materia de Contabilidad 7 en la Escuela de Administración.	3
518	13	Gestión Empresarial 7	Materia de Gestión Empresarial 7 en la Escuela de Administración.	4
519	13	Marketing 7	Materia de Marketing 7 en la Escuela de Administración.	5
520	13	Economía 7	Materia de Economía 7 en la Escuela de Administración.	3
521	14	Contabilidad 1	Materia de Contabilidad 1 en la Escuela de Contabilidad.	3
522	14	Gestión Empresarial 1	Materia de Gestión Empresarial 1 en la Escuela de Contabilidad.	4
523	14	Marketing 1	Materia de Marketing 1 en la Escuela de Contabilidad.	5
524	14	Economía 1	Materia de Economía 1 en la Escuela de Contabilidad.	3
525	14	Finanzas 1	Materia de Finanzas 1 en la Escuela de Contabilidad.	4
526	14	Estadística 1	Materia de Estadística 1 en la Escuela de Contabilidad.	5
527	14	Contabilidad 2	Materia de Contabilidad 2 en la Escuela de Contabilidad.	3
528	14	Gestión Empresarial 2	Materia de Gestión Empresarial 2 en la Escuela de Contabilidad.	4
529	14	Marketing 2	Materia de Marketing 2 en la Escuela de Contabilidad.	5
530	14	Economía 2	Materia de Economía 2 en la Escuela de Contabilidad.	3
531	14	Finanzas 2	Materia de Finanzas 2 en la Escuela de Contabilidad.	4
532	14	Estadística 2	Materia de Estadística 2 en la Escuela de Contabilidad.	5
533	14	Contabilidad 3	Materia de Contabilidad 3 en la Escuela de Contabilidad.	3
534	14	Gestión Empresarial 3	Materia de Gestión Empresarial 3 en la Escuela de Contabilidad.	4
535	14	Marketing 3	Materia de Marketing 3 en la Escuela de Contabilidad.	5
536	14	Economía 3	Materia de Economía 3 en la Escuela de Contabilidad.	3
537	14	Finanzas 3	Materia de Finanzas 3 en la Escuela de Contabilidad.	4
538	14	Estadística 3	Materia de Estadística 3 en la Escuela de Contabilidad.	5
539	14	Contabilidad 4	Materia de Contabilidad 4 en la Escuela de Contabilidad.	3
540	14	Gestión Empresarial 4	Materia de Gestión Empresarial 4 en la Escuela de Contabilidad.	4
541	14	Marketing 4	Materia de Marketing 4 en la Escuela de Contabilidad.	5
542	14	Economía 4	Materia de Economía 4 en la Escuela de Contabilidad.	3
543	14	Finanzas 4	Materia de Finanzas 4 en la Escuela de Contabilidad.	4
544	14	Estadística 4	Materia de Estadística 4 en la Escuela de Contabilidad.	5
545	14	Contabilidad 5	Materia de Contabilidad 5 en la Escuela de Contabilidad.	3
546	14	Gestión Empresarial 5	Materia de Gestión Empresarial 5 en la Escuela de Contabilidad.	4
547	14	Marketing 5	Materia de Marketing 5 en la Escuela de Contabilidad.	5
548	14	Economía 5	Materia de Economía 5 en la Escuela de Contabilidad.	3
549	14	Finanzas 5	Materia de Finanzas 5 en la Escuela de Contabilidad.	4
550	14	Estadística 5	Materia de Estadística 5 en la Escuela de Contabilidad.	5
551	14	Contabilidad 6	Materia de Contabilidad 6 en la Escuela de Contabilidad.	3
552	14	Gestión Empresarial 6	Materia de Gestión Empresarial 6 en la Escuela de Contabilidad.	4
553	14	Marketing 6	Materia de Marketing 6 en la Escuela de Contabilidad.	5
554	14	Economía 6	Materia de Economía 6 en la Escuela de Contabilidad.	3
555	14	Finanzas 6	Materia de Finanzas 6 en la Escuela de Contabilidad.	4
556	14	Estadística 6	Materia de Estadística 6 en la Escuela de Contabilidad.	5
557	14	Contabilidad 7	Materia de Contabilidad 7 en la Escuela de Contabilidad.	3
558	14	Gestión Empresarial 7	Materia de Gestión Empresarial 7 en la Escuela de Contabilidad.	4
559	14	Marketing 7	Materia de Marketing 7 en la Escuela de Contabilidad.	5
560	14	Economía 7	Materia de Economía 7 en la Escuela de Contabilidad.	3
561	15	Contabilidad 1	Materia de Contabilidad 1 en la Escuela de Finanzas.	3
562	15	Gestión Empresarial 1	Materia de Gestión Empresarial 1 en la Escuela de Finanzas.	4
563	15	Marketing 1	Materia de Marketing 1 en la Escuela de Finanzas.	5
564	15	Economía 1	Materia de Economía 1 en la Escuela de Finanzas.	3
565	15	Finanzas 1	Materia de Finanzas 1 en la Escuela de Finanzas.	4
566	15	Estadística 1	Materia de Estadística 1 en la Escuela de Finanzas.	5
567	15	Contabilidad 2	Materia de Contabilidad 2 en la Escuela de Finanzas.	3
568	15	Gestión Empresarial 2	Materia de Gestión Empresarial 2 en la Escuela de Finanzas.	4
569	15	Marketing 2	Materia de Marketing 2 en la Escuela de Finanzas.	5
570	15	Economía 2	Materia de Economía 2 en la Escuela de Finanzas.	3
571	15	Finanzas 2	Materia de Finanzas 2 en la Escuela de Finanzas.	4
572	15	Estadística 2	Materia de Estadística 2 en la Escuela de Finanzas.	5
573	15	Contabilidad 3	Materia de Contabilidad 3 en la Escuela de Finanzas.	3
574	15	Gestión Empresarial 3	Materia de Gestión Empresarial 3 en la Escuela de Finanzas.	4
575	15	Marketing 3	Materia de Marketing 3 en la Escuela de Finanzas.	5
576	15	Economía 3	Materia de Economía 3 en la Escuela de Finanzas.	3
577	15	Finanzas 3	Materia de Finanzas 3 en la Escuela de Finanzas.	4
578	15	Estadística 3	Materia de Estadística 3 en la Escuela de Finanzas.	5
579	15	Contabilidad 4	Materia de Contabilidad 4 en la Escuela de Finanzas.	3
580	15	Gestión Empresarial 4	Materia de Gestión Empresarial 4 en la Escuela de Finanzas.	4
581	15	Marketing 4	Materia de Marketing 4 en la Escuela de Finanzas.	5
582	15	Economía 4	Materia de Economía 4 en la Escuela de Finanzas.	3
584	15	Estadística 4	Materia de Estadística 4 en la Escuela de Finanzas.	5
585	15	Contabilidad 5	Materia de Contabilidad 5 en la Escuela de Finanzas.	3
586	15	Gestión Empresarial 5	Materia de Gestión Empresarial 5 en la Escuela de Finanzas.	4
587	15	Marketing 5	Materia de Marketing 5 en la Escuela de Finanzas.	5
588	15	Economía 5	Materia de Economía 5 en la Escuela de Finanzas.	3
589	15	Finanzas 5	Materia de Finanzas 5 en la Escuela de Finanzas.	4
590	15	Estadística 5	Materia de Estadística 5 en la Escuela de Finanzas.	5
591	15	Contabilidad 6	Materia de Contabilidad 6 en la Escuela de Finanzas.	3
592	15	Gestión Empresarial 6	Materia de Gestión Empresarial 6 en la Escuela de Finanzas.	4
593	15	Marketing 6	Materia de Marketing 6 en la Escuela de Finanzas.	5
594	15	Economía 6	Materia de Economía 6 en la Escuela de Finanzas.	3
595	15	Finanzas 6	Materia de Finanzas 6 en la Escuela de Finanzas.	4
596	15	Estadística 6	Materia de Estadística 6 en la Escuela de Finanzas.	5
597	15	Contabilidad 7	Materia de Contabilidad 7 en la Escuela de Finanzas.	3
598	15	Gestión Empresarial 7	Materia de Gestión Empresarial 7 en la Escuela de Finanzas.	4
599	15	Marketing 7	Materia de Marketing 7 en la Escuela de Finanzas.	5
600	15	Economía 7	Materia de Economía 7 en la Escuela de Finanzas.	3
601	16	Historia Universal 1	Materia de Historia Universal 1 en la Escuela de Historia.	3
602	16	Filosofía Moderna 1	Materia de Filosofía Moderna 1 en la Escuela de Historia.	4
603	16	Literatura Clásica 1	Materia de Literatura Clásica 1 en la Escuela de Historia.	5
604	16	Sociología 1	Materia de Sociología 1 en la Escuela de Historia.	3
605	16	Antropología 1	Materia de Antropología 1 en la Escuela de Historia.	4
606	16	Psicología 1	Materia de Psicología 1 en la Escuela de Historia.	5
607	16	Historia Universal 2	Materia de Historia Universal 2 en la Escuela de Historia.	3
608	16	Filosofía Moderna 2	Materia de Filosofía Moderna 2 en la Escuela de Historia.	4
609	16	Literatura Clásica 2	Materia de Literatura Clásica 2 en la Escuela de Historia.	5
610	16	Sociología 2	Materia de Sociología 2 en la Escuela de Historia.	3
611	16	Antropología 2	Materia de Antropología 2 en la Escuela de Historia.	4
612	16	Psicología 2	Materia de Psicología 2 en la Escuela de Historia.	5
613	16	Historia Universal 3	Materia de Historia Universal 3 en la Escuela de Historia.	3
614	16	Filosofía Moderna 3	Materia de Filosofía Moderna 3 en la Escuela de Historia.	4
615	16	Literatura Clásica 3	Materia de Literatura Clásica 3 en la Escuela de Historia.	5
616	16	Sociología 3	Materia de Sociología 3 en la Escuela de Historia.	3
617	16	Antropología 3	Materia de Antropología 3 en la Escuela de Historia.	4
618	16	Psicología 3	Materia de Psicología 3 en la Escuela de Historia.	5
619	16	Historia Universal 4	Materia de Historia Universal 4 en la Escuela de Historia.	3
620	16	Filosofía Moderna 4	Materia de Filosofía Moderna 4 en la Escuela de Historia.	4
621	16	Literatura Clásica 4	Materia de Literatura Clásica 4 en la Escuela de Historia.	5
622	16	Sociología 4	Materia de Sociología 4 en la Escuela de Historia.	3
623	16	Antropología 4	Materia de Antropología 4 en la Escuela de Historia.	4
624	16	Psicología 4	Materia de Psicología 4 en la Escuela de Historia.	5
625	16	Historia Universal 5	Materia de Historia Universal 5 en la Escuela de Historia.	3
626	16	Filosofía Moderna 5	Materia de Filosofía Moderna 5 en la Escuela de Historia.	4
627	16	Literatura Clásica 5	Materia de Literatura Clásica 5 en la Escuela de Historia.	5
628	16	Sociología 5	Materia de Sociología 5 en la Escuela de Historia.	3
629	16	Antropología 5	Materia de Antropología 5 en la Escuela de Historia.	4
630	16	Psicología 5	Materia de Psicología 5 en la Escuela de Historia.	5
631	16	Historia Universal 6	Materia de Historia Universal 6 en la Escuela de Historia.	3
632	16	Filosofía Moderna 6	Materia de Filosofía Moderna 6 en la Escuela de Historia.	4
633	16	Literatura Clásica 6	Materia de Literatura Clásica 6 en la Escuela de Historia.	5
634	16	Sociología 6	Materia de Sociología 6 en la Escuela de Historia.	3
635	16	Antropología 6	Materia de Antropología 6 en la Escuela de Historia.	4
636	16	Psicología 6	Materia de Psicología 6 en la Escuela de Historia.	5
637	16	Historia Universal 7	Materia de Historia Universal 7 en la Escuela de Historia.	3
638	16	Filosofía Moderna 7	Materia de Filosofía Moderna 7 en la Escuela de Historia.	4
639	16	Literatura Clásica 7	Materia de Literatura Clásica 7 en la Escuela de Historia.	5
640	16	Sociología 7	Materia de Sociología 7 en la Escuela de Historia.	3
641	17	Historia Universal 1	Materia de Historia Universal 1 en la Escuela de Filosofía.	3
642	17	Filosofía Moderna 1	Materia de Filosofía Moderna 1 en la Escuela de Filosofía.	4
643	17	Literatura Clásica 1	Materia de Literatura Clásica 1 en la Escuela de Filosofía.	5
644	17	Sociología 1	Materia de Sociología 1 en la Escuela de Filosofía.	3
645	17	Antropología 1	Materia de Antropología 1 en la Escuela de Filosofía.	4
646	17	Psicología 1	Materia de Psicología 1 en la Escuela de Filosofía.	5
647	17	Historia Universal 2	Materia de Historia Universal 2 en la Escuela de Filosofía.	3
648	17	Filosofía Moderna 2	Materia de Filosofía Moderna 2 en la Escuela de Filosofía.	4
649	17	Literatura Clásica 2	Materia de Literatura Clásica 2 en la Escuela de Filosofía.	5
650	17	Sociología 2	Materia de Sociología 2 en la Escuela de Filosofía.	3
651	17	Antropología 2	Materia de Antropología 2 en la Escuela de Filosofía.	4
652	17	Psicología 2	Materia de Psicología 2 en la Escuela de Filosofía.	5
653	17	Historia Universal 3	Materia de Historia Universal 3 en la Escuela de Filosofía.	3
654	17	Filosofía Moderna 3	Materia de Filosofía Moderna 3 en la Escuela de Filosofía.	4
655	17	Literatura Clásica 3	Materia de Literatura Clásica 3 en la Escuela de Filosofía.	5
656	17	Sociología 3	Materia de Sociología 3 en la Escuela de Filosofía.	3
657	17	Antropología 3	Materia de Antropología 3 en la Escuela de Filosofía.	4
658	17	Psicología 3	Materia de Psicología 3 en la Escuela de Filosofía.	5
659	17	Historia Universal 4	Materia de Historia Universal 4 en la Escuela de Filosofía.	3
660	17	Filosofía Moderna 4	Materia de Filosofía Moderna 4 en la Escuela de Filosofía.	4
661	17	Literatura Clásica 4	Materia de Literatura Clásica 4 en la Escuela de Filosofía.	5
662	17	Sociología 4	Materia de Sociología 4 en la Escuela de Filosofía.	3
663	17	Antropología 4	Materia de Antropología 4 en la Escuela de Filosofía.	4
664	17	Psicología 4	Materia de Psicología 4 en la Escuela de Filosofía.	5
665	17	Historia Universal 5	Materia de Historia Universal 5 en la Escuela de Filosofía.	3
666	17	Filosofía Moderna 5	Materia de Filosofía Moderna 5 en la Escuela de Filosofía.	4
667	17	Literatura Clásica 5	Materia de Literatura Clásica 5 en la Escuela de Filosofía.	5
668	17	Sociología 5	Materia de Sociología 5 en la Escuela de Filosofía.	3
669	17	Antropología 5	Materia de Antropología 5 en la Escuela de Filosofía.	4
670	17	Psicología 5	Materia de Psicología 5 en la Escuela de Filosofía.	5
671	17	Historia Universal 6	Materia de Historia Universal 6 en la Escuela de Filosofía.	3
672	17	Filosofía Moderna 6	Materia de Filosofía Moderna 6 en la Escuela de Filosofía.	4
673	17	Literatura Clásica 6	Materia de Literatura Clásica 6 en la Escuela de Filosofía.	5
674	17	Sociología 6	Materia de Sociología 6 en la Escuela de Filosofía.	3
675	17	Antropología 6	Materia de Antropología 6 en la Escuela de Filosofía.	4
676	17	Psicología 6	Materia de Psicología 6 en la Escuela de Filosofía.	5
677	17	Historia Universal 7	Materia de Historia Universal 7 en la Escuela de Filosofía.	3
678	17	Filosofía Moderna 7	Materia de Filosofía Moderna 7 en la Escuela de Filosofía.	4
679	17	Literatura Clásica 7	Materia de Literatura Clásica 7 en la Escuela de Filosofía.	5
680	17	Sociología 7	Materia de Sociología 7 en la Escuela de Filosofía.	3
681	18	Historia Universal 1	Materia de Historia Universal 1 en la Escuela de Letras.	3
682	18	Filosofía Moderna 1	Materia de Filosofía Moderna 1 en la Escuela de Letras.	4
683	18	Literatura Clásica 1	Materia de Literatura Clásica 1 en la Escuela de Letras.	5
684	18	Sociología 1	Materia de Sociología 1 en la Escuela de Letras.	3
685	18	Antropología 1	Materia de Antropología 1 en la Escuela de Letras.	4
686	18	Psicología 1	Materia de Psicología 1 en la Escuela de Letras.	5
687	18	Historia Universal 2	Materia de Historia Universal 2 en la Escuela de Letras.	3
688	18	Filosofía Moderna 2	Materia de Filosofía Moderna 2 en la Escuela de Letras.	4
689	18	Literatura Clásica 2	Materia de Literatura Clásica 2 en la Escuela de Letras.	5
690	18	Sociología 2	Materia de Sociología 2 en la Escuela de Letras.	3
691	18	Antropología 2	Materia de Antropología 2 en la Escuela de Letras.	4
692	18	Psicología 2	Materia de Psicología 2 en la Escuela de Letras.	5
693	18	Historia Universal 3	Materia de Historia Universal 3 en la Escuela de Letras.	3
694	18	Filosofía Moderna 3	Materia de Filosofía Moderna 3 en la Escuela de Letras.	4
695	18	Literatura Clásica 3	Materia de Literatura Clásica 3 en la Escuela de Letras.	5
696	18	Sociología 3	Materia de Sociología 3 en la Escuela de Letras.	3
697	18	Antropología 3	Materia de Antropología 3 en la Escuela de Letras.	4
698	18	Psicología 3	Materia de Psicología 3 en la Escuela de Letras.	5
699	18	Historia Universal 4	Materia de Historia Universal 4 en la Escuela de Letras.	3
700	18	Filosofía Moderna 4	Materia de Filosofía Moderna 4 en la Escuela de Letras.	4
701	18	Literatura Clásica 4	Materia de Literatura Clásica 4 en la Escuela de Letras.	5
702	18	Sociología 4	Materia de Sociología 4 en la Escuela de Letras.	3
703	18	Antropología 4	Materia de Antropología 4 en la Escuela de Letras.	4
704	18	Psicología 4	Materia de Psicología 4 en la Escuela de Letras.	5
705	18	Historia Universal 5	Materia de Historia Universal 5 en la Escuela de Letras.	3
706	18	Filosofía Moderna 5	Materia de Filosofía Moderna 5 en la Escuela de Letras.	4
707	18	Literatura Clásica 5	Materia de Literatura Clásica 5 en la Escuela de Letras.	5
708	18	Sociología 5	Materia de Sociología 5 en la Escuela de Letras.	3
709	18	Antropología 5	Materia de Antropología 5 en la Escuela de Letras.	4
710	18	Psicología 5	Materia de Psicología 5 en la Escuela de Letras.	5
711	18	Historia Universal 6	Materia de Historia Universal 6 en la Escuela de Letras.	3
712	18	Filosofía Moderna 6	Materia de Filosofía Moderna 6 en la Escuela de Letras.	4
713	18	Literatura Clásica 6	Materia de Literatura Clásica 6 en la Escuela de Letras.	5
714	18	Sociología 6	Materia de Sociología 6 en la Escuela de Letras.	3
715	18	Antropología 6	Materia de Antropología 6 en la Escuela de Letras.	4
716	18	Psicología 6	Materia de Psicología 6 en la Escuela de Letras.	5
717	18	Historia Universal 7	Materia de Historia Universal 7 en la Escuela de Letras.	3
718	18	Filosofía Moderna 7	Materia de Filosofía Moderna 7 en la Escuela de Letras.	4
719	18	Literatura Clásica 7	Materia de Literatura Clásica 7 en la Escuela de Letras.	5
720	18	Sociología 7	Materia de Sociología 7 en la Escuela de Letras.	3
721	19	Programación 1	Materia de Programación 1 en la Escuela de Desarrollo de Software.	3
722	19	Bases de Datos 1	Materia de Bases de Datos 1 en la Escuela de Desarrollo de Software.	4
723	19	Redes 1	Materia de Redes 1 en la Escuela de Desarrollo de Software.	5
724	19	Ciberseguridad 1	Materia de Ciberseguridad 1 en la Escuela de Desarrollo de Software.	3
725	19	Sistemas Operativos 1	Materia de Sistemas Operativos 1 en la Escuela de Desarrollo de Software.	4
726	19	Inteligencia Artificial 1	Materia de Inteligencia Artificial 1 en la Escuela de Desarrollo de Software.	5
727	19	Programación 2	Materia de Programación 2 en la Escuela de Desarrollo de Software.	3
728	19	Bases de Datos 2	Materia de Bases de Datos 2 en la Escuela de Desarrollo de Software.	4
729	19	Redes 2	Materia de Redes 2 en la Escuela de Desarrollo de Software.	5
730	19	Ciberseguridad 2	Materia de Ciberseguridad 2 en la Escuela de Desarrollo de Software.	3
731	19	Sistemas Operativos 2	Materia de Sistemas Operativos 2 en la Escuela de Desarrollo de Software.	4
732	19	Inteligencia Artificial 2	Materia de Inteligencia Artificial 2 en la Escuela de Desarrollo de Software.	5
733	19	Programación 3	Materia de Programación 3 en la Escuela de Desarrollo de Software.	3
734	19	Bases de Datos 3	Materia de Bases de Datos 3 en la Escuela de Desarrollo de Software.	4
735	19	Redes 3	Materia de Redes 3 en la Escuela de Desarrollo de Software.	5
736	19	Ciberseguridad 3	Materia de Ciberseguridad 3 en la Escuela de Desarrollo de Software.	3
737	19	Sistemas Operativos 3	Materia de Sistemas Operativos 3 en la Escuela de Desarrollo de Software.	4
738	19	Inteligencia Artificial 3	Materia de Inteligencia Artificial 3 en la Escuela de Desarrollo de Software.	5
739	19	Programación 4	Materia de Programación 4 en la Escuela de Desarrollo de Software.	3
740	19	Bases de Datos 4	Materia de Bases de Datos 4 en la Escuela de Desarrollo de Software.	4
741	19	Redes 4	Materia de Redes 4 en la Escuela de Desarrollo de Software.	5
742	19	Ciberseguridad 4	Materia de Ciberseguridad 4 en la Escuela de Desarrollo de Software.	3
743	19	Sistemas Operativos 4	Materia de Sistemas Operativos 4 en la Escuela de Desarrollo de Software.	4
744	19	Inteligencia Artificial 4	Materia de Inteligencia Artificial 4 en la Escuela de Desarrollo de Software.	5
745	19	Programación 5	Materia de Programación 5 en la Escuela de Desarrollo de Software.	3
746	19	Bases de Datos 5	Materia de Bases de Datos 5 en la Escuela de Desarrollo de Software.	4
747	19	Redes 5	Materia de Redes 5 en la Escuela de Desarrollo de Software.	5
748	19	Ciberseguridad 5	Materia de Ciberseguridad 5 en la Escuela de Desarrollo de Software.	3
749	19	Sistemas Operativos 5	Materia de Sistemas Operativos 5 en la Escuela de Desarrollo de Software.	4
750	19	Inteligencia Artificial 5	Materia de Inteligencia Artificial 5 en la Escuela de Desarrollo de Software.	5
751	19	Programación 6	Materia de Programación 6 en la Escuela de Desarrollo de Software.	3
752	19	Bases de Datos 6	Materia de Bases de Datos 6 en la Escuela de Desarrollo de Software.	4
753	19	Redes 6	Materia de Redes 6 en la Escuela de Desarrollo de Software.	5
754	19	Ciberseguridad 6	Materia de Ciberseguridad 6 en la Escuela de Desarrollo de Software.	3
755	19	Sistemas Operativos 6	Materia de Sistemas Operativos 6 en la Escuela de Desarrollo de Software.	4
756	19	Inteligencia Artificial 6	Materia de Inteligencia Artificial 6 en la Escuela de Desarrollo de Software.	5
757	19	Programación 7	Materia de Programación 7 en la Escuela de Desarrollo de Software.	3
758	19	Bases de Datos 7	Materia de Bases de Datos 7 en la Escuela de Desarrollo de Software.	4
759	19	Redes 7	Materia de Redes 7 en la Escuela de Desarrollo de Software.	5
760	19	Ciberseguridad 7	Materia de Ciberseguridad 7 en la Escuela de Desarrollo de Software.	3
761	20	Programación 1	Materia de Programación 1 en la Escuela de Inteligencia Artificial.	3
762	20	Bases de Datos 1	Materia de Bases de Datos 1 en la Escuela de Inteligencia Artificial.	4
763	20	Redes 1	Materia de Redes 1 en la Escuela de Inteligencia Artificial.	5
764	20	Ciberseguridad 1	Materia de Ciberseguridad 1 en la Escuela de Inteligencia Artificial.	3
765	20	Sistemas Operativos 1	Materia de Sistemas Operativos 1 en la Escuela de Inteligencia Artificial.	4
766	20	Inteligencia Artificial 1	Materia de Inteligencia Artificial 1 en la Escuela de Inteligencia Artificial.	5
767	20	Programación 2	Materia de Programación 2 en la Escuela de Inteligencia Artificial.	3
768	20	Bases de Datos 2	Materia de Bases de Datos 2 en la Escuela de Inteligencia Artificial.	4
769	20	Redes 2	Materia de Redes 2 en la Escuela de Inteligencia Artificial.	5
770	20	Ciberseguridad 2	Materia de Ciberseguridad 2 en la Escuela de Inteligencia Artificial.	3
771	20	Sistemas Operativos 2	Materia de Sistemas Operativos 2 en la Escuela de Inteligencia Artificial.	4
772	20	Inteligencia Artificial 2	Materia de Inteligencia Artificial 2 en la Escuela de Inteligencia Artificial.	5
773	20	Programación 3	Materia de Programación 3 en la Escuela de Inteligencia Artificial.	3
774	20	Bases de Datos 3	Materia de Bases de Datos 3 en la Escuela de Inteligencia Artificial.	4
775	20	Redes 3	Materia de Redes 3 en la Escuela de Inteligencia Artificial.	5
776	20	Ciberseguridad 3	Materia de Ciberseguridad 3 en la Escuela de Inteligencia Artificial.	3
777	20	Sistemas Operativos 3	Materia de Sistemas Operativos 3 en la Escuela de Inteligencia Artificial.	4
778	20	Inteligencia Artificial 3	Materia de Inteligencia Artificial 3 en la Escuela de Inteligencia Artificial.	5
779	20	Programación 4	Materia de Programación 4 en la Escuela de Inteligencia Artificial.	3
780	20	Bases de Datos 4	Materia de Bases de Datos 4 en la Escuela de Inteligencia Artificial.	4
781	20	Redes 4	Materia de Redes 4 en la Escuela de Inteligencia Artificial.	5
782	20	Ciberseguridad 4	Materia de Ciberseguridad 4 en la Escuela de Inteligencia Artificial.	3
783	20	Sistemas Operativos 4	Materia de Sistemas Operativos 4 en la Escuela de Inteligencia Artificial.	4
784	20	Inteligencia Artificial 4	Materia de Inteligencia Artificial 4 en la Escuela de Inteligencia Artificial.	5
785	20	Programación 5	Materia de Programación 5 en la Escuela de Inteligencia Artificial.	3
786	20	Bases de Datos 5	Materia de Bases de Datos 5 en la Escuela de Inteligencia Artificial.	4
787	20	Redes 5	Materia de Redes 5 en la Escuela de Inteligencia Artificial.	5
788	20	Ciberseguridad 5	Materia de Ciberseguridad 5 en la Escuela de Inteligencia Artificial.	3
789	20	Sistemas Operativos 5	Materia de Sistemas Operativos 5 en la Escuela de Inteligencia Artificial.	4
790	20	Inteligencia Artificial 5	Materia de Inteligencia Artificial 5 en la Escuela de Inteligencia Artificial.	5
791	20	Programación 6	Materia de Programación 6 en la Escuela de Inteligencia Artificial.	3
792	20	Bases de Datos 6	Materia de Bases de Datos 6 en la Escuela de Inteligencia Artificial.	4
793	20	Redes 6	Materia de Redes 6 en la Escuela de Inteligencia Artificial.	5
794	20	Ciberseguridad 6	Materia de Ciberseguridad 6 en la Escuela de Inteligencia Artificial.	3
795	20	Sistemas Operativos 6	Materia de Sistemas Operativos 6 en la Escuela de Inteligencia Artificial.	4
796	20	Inteligencia Artificial 6	Materia de Inteligencia Artificial 6 en la Escuela de Inteligencia Artificial.	5
797	20	Programación 7	Materia de Programación 7 en la Escuela de Inteligencia Artificial.	3
798	20	Bases de Datos 7	Materia de Bases de Datos 7 en la Escuela de Inteligencia Artificial.	4
799	20	Redes 7	Materia de Redes 7 en la Escuela de Inteligencia Artificial.	5
800	20	Ciberseguridad 7	Materia de Ciberseguridad 7 en la Escuela de Inteligencia Artificial.	3
801	21	Programación 1	Materia de Programación 1 en la Escuela de Redes y Telecomunicaciones.	3
802	21	Bases de Datos 1	Materia de Bases de Datos 1 en la Escuela de Redes y Telecomunicaciones.	4
803	21	Redes 1	Materia de Redes 1 en la Escuela de Redes y Telecomunicaciones.	5
804	21	Ciberseguridad 1	Materia de Ciberseguridad 1 en la Escuela de Redes y Telecomunicaciones.	3
805	21	Sistemas Operativos 1	Materia de Sistemas Operativos 1 en la Escuela de Redes y Telecomunicaciones.	4
806	21	Inteligencia Artificial 1	Materia de Inteligencia Artificial 1 en la Escuela de Redes y Telecomunicaciones.	5
807	21	Programación 2	Materia de Programación 2 en la Escuela de Redes y Telecomunicaciones.	3
808	21	Bases de Datos 2	Materia de Bases de Datos 2 en la Escuela de Redes y Telecomunicaciones.	4
809	21	Redes 2	Materia de Redes 2 en la Escuela de Redes y Telecomunicaciones.	5
810	21	Ciberseguridad 2	Materia de Ciberseguridad 2 en la Escuela de Redes y Telecomunicaciones.	3
811	21	Sistemas Operativos 2	Materia de Sistemas Operativos 2 en la Escuela de Redes y Telecomunicaciones.	4
812	21	Inteligencia Artificial 2	Materia de Inteligencia Artificial 2 en la Escuela de Redes y Telecomunicaciones.	5
813	21	Programación 3	Materia de Programación 3 en la Escuela de Redes y Telecomunicaciones.	3
814	21	Bases de Datos 3	Materia de Bases de Datos 3 en la Escuela de Redes y Telecomunicaciones.	4
815	21	Redes 3	Materia de Redes 3 en la Escuela de Redes y Telecomunicaciones.	5
816	21	Ciberseguridad 3	Materia de Ciberseguridad 3 en la Escuela de Redes y Telecomunicaciones.	3
817	21	Sistemas Operativos 3	Materia de Sistemas Operativos 3 en la Escuela de Redes y Telecomunicaciones.	4
818	21	Inteligencia Artificial 3	Materia de Inteligencia Artificial 3 en la Escuela de Redes y Telecomunicaciones.	5
819	21	Programación 4	Materia de Programación 4 en la Escuela de Redes y Telecomunicaciones.	3
820	21	Bases de Datos 4	Materia de Bases de Datos 4 en la Escuela de Redes y Telecomunicaciones.	4
821	21	Redes 4	Materia de Redes 4 en la Escuela de Redes y Telecomunicaciones.	5
822	21	Ciberseguridad 4	Materia de Ciberseguridad 4 en la Escuela de Redes y Telecomunicaciones.	3
823	21	Sistemas Operativos 4	Materia de Sistemas Operativos 4 en la Escuela de Redes y Telecomunicaciones.	4
824	21	Inteligencia Artificial 4	Materia de Inteligencia Artificial 4 en la Escuela de Redes y Telecomunicaciones.	5
825	21	Programación 5	Materia de Programación 5 en la Escuela de Redes y Telecomunicaciones.	3
826	21	Bases de Datos 5	Materia de Bases de Datos 5 en la Escuela de Redes y Telecomunicaciones.	4
827	21	Redes 5	Materia de Redes 5 en la Escuela de Redes y Telecomunicaciones.	5
828	21	Ciberseguridad 5	Materia de Ciberseguridad 5 en la Escuela de Redes y Telecomunicaciones.	3
829	21	Sistemas Operativos 5	Materia de Sistemas Operativos 5 en la Escuela de Redes y Telecomunicaciones.	4
830	21	Inteligencia Artificial 5	Materia de Inteligencia Artificial 5 en la Escuela de Redes y Telecomunicaciones.	5
831	21	Programación 6	Materia de Programación 6 en la Escuela de Redes y Telecomunicaciones.	3
832	21	Bases de Datos 6	Materia de Bases de Datos 6 en la Escuela de Redes y Telecomunicaciones.	4
833	21	Redes 6	Materia de Redes 6 en la Escuela de Redes y Telecomunicaciones.	5
834	21	Ciberseguridad 6	Materia de Ciberseguridad 6 en la Escuela de Redes y Telecomunicaciones.	3
835	21	Sistemas Operativos 6	Materia de Sistemas Operativos 6 en la Escuela de Redes y Telecomunicaciones.	4
836	21	Inteligencia Artificial 6	Materia de Inteligencia Artificial 6 en la Escuela de Redes y Telecomunicaciones.	5
837	21	Programación 7	Materia de Programación 7 en la Escuela de Redes y Telecomunicaciones.	3
838	21	Bases de Datos 7	Materia de Bases de Datos 7 en la Escuela de Redes y Telecomunicaciones.	4
839	21	Redes 7	Materia de Redes 7 en la Escuela de Redes y Telecomunicaciones.	5
840	21	Ciberseguridad 7	Materia de Ciberseguridad 7 en la Escuela de Redes y Telecomunicaciones.	3
841	22	Diseño Urbano 1	Materia de Diseño Urbano 1 en la Escuela de Diseño Urbano.	3
842	22	Historia del Arte 1	Materia de Historia del Arte 1 en la Escuela de Diseño Urbano.	4
843	22	Patrimonio Arquitectónico 1	Materia de Patrimonio Arquitectónico 1 en la Escuela de Diseño Urbano.	5
844	22	Dibujo Artístico 1	Materia de Dibujo Artístico 1 en la Escuela de Diseño Urbano.	3
845	22	Composición Musical 1	Materia de Composición Musical 1 en la Escuela de Diseño Urbano.	4
846	22	Diseño Urbano 2	Materia de Diseño Urbano 2 en la Escuela de Diseño Urbano.	5
847	22	Historia del Arte 2	Materia de Historia del Arte 2 en la Escuela de Diseño Urbano.	3
848	22	Patrimonio Arquitectónico 2	Materia de Patrimonio Arquitectónico 2 en la Escuela de Diseño Urbano.	4
849	22	Dibujo Artístico 2	Materia de Dibujo Artístico 2 en la Escuela de Diseño Urbano.	5
850	22	Composición Musical 2	Materia de Composición Musical 2 en la Escuela de Diseño Urbano.	3
851	22	Diseño Urbano 3	Materia de Diseño Urbano 3 en la Escuela de Diseño Urbano.	4
852	22	Historia del Arte 3	Materia de Historia del Arte 3 en la Escuela de Diseño Urbano.	5
853	22	Patrimonio Arquitectónico 3	Materia de Patrimonio Arquitectónico 3 en la Escuela de Diseño Urbano.	3
854	22	Dibujo Artístico 3	Materia de Dibujo Artístico 3 en la Escuela de Diseño Urbano.	4
855	22	Composición Musical 3	Materia de Composición Musical 3 en la Escuela de Diseño Urbano.	5
856	22	Diseño Urbano 4	Materia de Diseño Urbano 4 en la Escuela de Diseño Urbano.	3
857	22	Historia del Arte 4	Materia de Historia del Arte 4 en la Escuela de Diseño Urbano.	4
858	22	Patrimonio Arquitectónico 4	Materia de Patrimonio Arquitectónico 4 en la Escuela de Diseño Urbano.	5
859	22	Dibujo Artístico 4	Materia de Dibujo Artístico 4 en la Escuela de Diseño Urbano.	3
860	22	Composición Musical 4	Materia de Composición Musical 4 en la Escuela de Diseño Urbano.	4
861	22	Diseño Urbano 5	Materia de Diseño Urbano 5 en la Escuela de Diseño Urbano.	5
862	22	Historia del Arte 5	Materia de Historia del Arte 5 en la Escuela de Diseño Urbano.	3
863	22	Patrimonio Arquitectónico 5	Materia de Patrimonio Arquitectónico 5 en la Escuela de Diseño Urbano.	4
864	22	Dibujo Artístico 5	Materia de Dibujo Artístico 5 en la Escuela de Diseño Urbano.	5
865	22	Composición Musical 5	Materia de Composición Musical 5 en la Escuela de Diseño Urbano.	3
866	22	Diseño Urbano 6	Materia de Diseño Urbano 6 en la Escuela de Diseño Urbano.	4
867	22	Historia del Arte 6	Materia de Historia del Arte 6 en la Escuela de Diseño Urbano.	5
868	22	Patrimonio Arquitectónico 6	Materia de Patrimonio Arquitectónico 6 en la Escuela de Diseño Urbano.	3
869	22	Dibujo Artístico 6	Materia de Dibujo Artístico 6 en la Escuela de Diseño Urbano.	4
870	22	Composición Musical 6	Materia de Composición Musical 6 en la Escuela de Diseño Urbano.	5
871	22	Diseño Urbano 7	Materia de Diseño Urbano 7 en la Escuela de Diseño Urbano.	3
872	22	Historia del Arte 7	Materia de Historia del Arte 7 en la Escuela de Diseño Urbano.	4
873	22	Patrimonio Arquitectónico 7	Materia de Patrimonio Arquitectónico 7 en la Escuela de Diseño Urbano.	5
874	22	Dibujo Artístico 7	Materia de Dibujo Artístico 7 en la Escuela de Diseño Urbano.	3
875	22	Composición Musical 7	Materia de Composición Musical 7 en la Escuela de Diseño Urbano.	4
876	22	Diseño Urbano 8	Materia de Diseño Urbano 8 en la Escuela de Diseño Urbano.	5
877	22	Historia del Arte 8	Materia de Historia del Arte 8 en la Escuela de Diseño Urbano.	3
878	22	Patrimonio Arquitectónico 8	Materia de Patrimonio Arquitectónico 8 en la Escuela de Diseño Urbano.	4
879	22	Dibujo Artístico 8	Materia de Dibujo Artístico 8 en la Escuela de Diseño Urbano.	5
880	22	Composición Musical 8	Materia de Composición Musical 8 en la Escuela de Diseño Urbano.	3
881	23	Diseño Urbano 1	Materia de Diseño Urbano 1 en la Escuela de Arquitectura Sostenible.	3
882	23	Historia del Arte 1	Materia de Historia del Arte 1 en la Escuela de Arquitectura Sostenible.	4
883	23	Patrimonio Arquitectónico 1	Materia de Patrimonio Arquitectónico 1 en la Escuela de Arquitectura Sostenible.	5
884	23	Dibujo Artístico 1	Materia de Dibujo Artístico 1 en la Escuela de Arquitectura Sostenible.	3
885	23	Composición Musical 1	Materia de Composición Musical 1 en la Escuela de Arquitectura Sostenible.	4
886	23	Diseño Urbano 2	Materia de Diseño Urbano 2 en la Escuela de Arquitectura Sostenible.	5
887	23	Historia del Arte 2	Materia de Historia del Arte 2 en la Escuela de Arquitectura Sostenible.	3
888	23	Patrimonio Arquitectónico 2	Materia de Patrimonio Arquitectónico 2 en la Escuela de Arquitectura Sostenible.	4
889	23	Dibujo Artístico 2	Materia de Dibujo Artístico 2 en la Escuela de Arquitectura Sostenible.	5
890	23	Composición Musical 2	Materia de Composición Musical 2 en la Escuela de Arquitectura Sostenible.	3
891	23	Diseño Urbano 3	Materia de Diseño Urbano 3 en la Escuela de Arquitectura Sostenible.	4
892	23	Historia del Arte 3	Materia de Historia del Arte 3 en la Escuela de Arquitectura Sostenible.	5
893	23	Patrimonio Arquitectónico 3	Materia de Patrimonio Arquitectónico 3 en la Escuela de Arquitectura Sostenible.	3
894	23	Dibujo Artístico 3	Materia de Dibujo Artístico 3 en la Escuela de Arquitectura Sostenible.	4
895	23	Composición Musical 3	Materia de Composición Musical 3 en la Escuela de Arquitectura Sostenible.	5
896	23	Diseño Urbano 4	Materia de Diseño Urbano 4 en la Escuela de Arquitectura Sostenible.	3
897	23	Historia del Arte 4	Materia de Historia del Arte 4 en la Escuela de Arquitectura Sostenible.	4
898	23	Patrimonio Arquitectónico 4	Materia de Patrimonio Arquitectónico 4 en la Escuela de Arquitectura Sostenible.	5
899	23	Dibujo Artístico 4	Materia de Dibujo Artístico 4 en la Escuela de Arquitectura Sostenible.	3
900	23	Composición Musical 4	Materia de Composición Musical 4 en la Escuela de Arquitectura Sostenible.	4
901	23	Diseño Urbano 5	Materia de Diseño Urbano 5 en la Escuela de Arquitectura Sostenible.	5
902	23	Historia del Arte 5	Materia de Historia del Arte 5 en la Escuela de Arquitectura Sostenible.	3
903	23	Patrimonio Arquitectónico 5	Materia de Patrimonio Arquitectónico 5 en la Escuela de Arquitectura Sostenible.	4
904	23	Dibujo Artístico 5	Materia de Dibujo Artístico 5 en la Escuela de Arquitectura Sostenible.	5
905	23	Composición Musical 5	Materia de Composición Musical 5 en la Escuela de Arquitectura Sostenible.	3
906	23	Diseño Urbano 6	Materia de Diseño Urbano 6 en la Escuela de Arquitectura Sostenible.	4
907	23	Historia del Arte 6	Materia de Historia del Arte 6 en la Escuela de Arquitectura Sostenible.	5
908	23	Patrimonio Arquitectónico 6	Materia de Patrimonio Arquitectónico 6 en la Escuela de Arquitectura Sostenible.	3
909	23	Dibujo Artístico 6	Materia de Dibujo Artístico 6 en la Escuela de Arquitectura Sostenible.	4
910	23	Composición Musical 6	Materia de Composición Musical 6 en la Escuela de Arquitectura Sostenible.	5
911	23	Diseño Urbano 7	Materia de Diseño Urbano 7 en la Escuela de Arquitectura Sostenible.	3
912	23	Historia del Arte 7	Materia de Historia del Arte 7 en la Escuela de Arquitectura Sostenible.	4
913	23	Patrimonio Arquitectónico 7	Materia de Patrimonio Arquitectónico 7 en la Escuela de Arquitectura Sostenible.	5
914	23	Dibujo Artístico 7	Materia de Dibujo Artístico 7 en la Escuela de Arquitectura Sostenible.	3
915	23	Composición Musical 7	Materia de Composición Musical 7 en la Escuela de Arquitectura Sostenible.	4
916	23	Diseño Urbano 8	Materia de Diseño Urbano 8 en la Escuela de Arquitectura Sostenible.	5
917	23	Historia del Arte 8	Materia de Historia del Arte 8 en la Escuela de Arquitectura Sostenible.	3
918	23	Patrimonio Arquitectónico 8	Materia de Patrimonio Arquitectónico 8 en la Escuela de Arquitectura Sostenible.	4
919	23	Dibujo Artístico 8	Materia de Dibujo Artístico 8 en la Escuela de Arquitectura Sostenible.	5
920	23	Composición Musical 8	Materia de Composición Musical 8 en la Escuela de Arquitectura Sostenible.	3
921	24	Diseño Urbano 1	Materia de Diseño Urbano 1 en la Escuela de Patrimonio Arquitectónico.	3
922	24	Historia del Arte 1	Materia de Historia del Arte 1 en la Escuela de Patrimonio Arquitectónico.	4
923	24	Patrimonio Arquitectónico 1	Materia de Patrimonio Arquitectónico 1 en la Escuela de Patrimonio Arquitectónico.	5
924	24	Dibujo Artístico 1	Materia de Dibujo Artístico 1 en la Escuela de Patrimonio Arquitectónico.	3
925	24	Composición Musical 1	Materia de Composición Musical 1 en la Escuela de Patrimonio Arquitectónico.	4
926	24	Diseño Urbano 2	Materia de Diseño Urbano 2 en la Escuela de Patrimonio Arquitectónico.	5
927	24	Historia del Arte 2	Materia de Historia del Arte 2 en la Escuela de Patrimonio Arquitectónico.	3
928	24	Patrimonio Arquitectónico 2	Materia de Patrimonio Arquitectónico 2 en la Escuela de Patrimonio Arquitectónico.	4
929	24	Dibujo Artístico 2	Materia de Dibujo Artístico 2 en la Escuela de Patrimonio Arquitectónico.	5
930	24	Composición Musical 2	Materia de Composición Musical 2 en la Escuela de Patrimonio Arquitectónico.	3
931	24	Diseño Urbano 3	Materia de Diseño Urbano 3 en la Escuela de Patrimonio Arquitectónico.	4
932	24	Historia del Arte 3	Materia de Historia del Arte 3 en la Escuela de Patrimonio Arquitectónico.	5
933	24	Patrimonio Arquitectónico 3	Materia de Patrimonio Arquitectónico 3 en la Escuela de Patrimonio Arquitectónico.	3
934	24	Dibujo Artístico 3	Materia de Dibujo Artístico 3 en la Escuela de Patrimonio Arquitectónico.	4
935	24	Composición Musical 3	Materia de Composición Musical 3 en la Escuela de Patrimonio Arquitectónico.	5
936	24	Diseño Urbano 4	Materia de Diseño Urbano 4 en la Escuela de Patrimonio Arquitectónico.	3
937	24	Historia del Arte 4	Materia de Historia del Arte 4 en la Escuela de Patrimonio Arquitectónico.	4
938	24	Patrimonio Arquitectónico 4	Materia de Patrimonio Arquitectónico 4 en la Escuela de Patrimonio Arquitectónico.	5
939	24	Dibujo Artístico 4	Materia de Dibujo Artístico 4 en la Escuela de Patrimonio Arquitectónico.	3
940	24	Composición Musical 4	Materia de Composición Musical 4 en la Escuela de Patrimonio Arquitectónico.	4
941	24	Diseño Urbano 5	Materia de Diseño Urbano 5 en la Escuela de Patrimonio Arquitectónico.	5
942	24	Historia del Arte 5	Materia de Historia del Arte 5 en la Escuela de Patrimonio Arquitectónico.	3
943	24	Patrimonio Arquitectónico 5	Materia de Patrimonio Arquitectónico 5 en la Escuela de Patrimonio Arquitectónico.	4
944	24	Dibujo Artístico 5	Materia de Dibujo Artístico 5 en la Escuela de Patrimonio Arquitectónico.	5
945	24	Composición Musical 5	Materia de Composición Musical 5 en la Escuela de Patrimonio Arquitectónico.	3
946	24	Diseño Urbano 6	Materia de Diseño Urbano 6 en la Escuela de Patrimonio Arquitectónico.	4
947	24	Historia del Arte 6	Materia de Historia del Arte 6 en la Escuela de Patrimonio Arquitectónico.	5
948	24	Patrimonio Arquitectónico 6	Materia de Patrimonio Arquitectónico 6 en la Escuela de Patrimonio Arquitectónico.	3
949	24	Dibujo Artístico 6	Materia de Dibujo Artístico 6 en la Escuela de Patrimonio Arquitectónico.	4
950	24	Composición Musical 6	Materia de Composición Musical 6 en la Escuela de Patrimonio Arquitectónico.	5
951	24	Diseño Urbano 7	Materia de Diseño Urbano 7 en la Escuela de Patrimonio Arquitectónico.	3
952	24	Historia del Arte 7	Materia de Historia del Arte 7 en la Escuela de Patrimonio Arquitectónico.	4
953	24	Patrimonio Arquitectónico 7	Materia de Patrimonio Arquitectónico 7 en la Escuela de Patrimonio Arquitectónico.	5
954	24	Dibujo Artístico 7	Materia de Dibujo Artístico 7 en la Escuela de Patrimonio Arquitectónico.	3
955	24	Composición Musical 7	Materia de Composición Musical 7 en la Escuela de Patrimonio Arquitectónico.	4
956	24	Diseño Urbano 8	Materia de Diseño Urbano 8 en la Escuela de Patrimonio Arquitectónico.	5
957	24	Historia del Arte 8	Materia de Historia del Arte 8 en la Escuela de Patrimonio Arquitectónico.	3
958	24	Patrimonio Arquitectónico 8	Materia de Patrimonio Arquitectónico 8 en la Escuela de Patrimonio Arquitectónico.	4
959	24	Dibujo Artístico 8	Materia de Dibujo Artístico 8 en la Escuela de Patrimonio Arquitectónico.	5
960	24	Composición Musical 8	Materia de Composición Musical 8 en la Escuela de Patrimonio Arquitectónico.	3
961	25	Historia Universal 1	Materia de Historia Universal 1 en la Escuela de Sociología.	3
962	25	Filosofía Moderna 1	Materia de Filosofía Moderna 1 en la Escuela de Sociología.	4
963	25	Literatura Clásica 1	Materia de Literatura Clásica 1 en la Escuela de Sociología.	5
964	25	Sociología 1	Materia de Sociología 1 en la Escuela de Sociología.	3
965	25	Antropología 1	Materia de Antropología 1 en la Escuela de Sociología.	4
966	25	Psicología 1	Materia de Psicología 1 en la Escuela de Sociología.	5
967	25	Historia Universal 2	Materia de Historia Universal 2 en la Escuela de Sociología.	3
968	25	Filosofía Moderna 2	Materia de Filosofía Moderna 2 en la Escuela de Sociología.	4
969	25	Literatura Clásica 2	Materia de Literatura Clásica 2 en la Escuela de Sociología.	5
970	25	Sociología 2	Materia de Sociología 2 en la Escuela de Sociología.	3
971	25	Antropología 2	Materia de Antropología 2 en la Escuela de Sociología.	4
972	25	Psicología 2	Materia de Psicología 2 en la Escuela de Sociología.	5
973	25	Historia Universal 3	Materia de Historia Universal 3 en la Escuela de Sociología.	3
974	25	Filosofía Moderna 3	Materia de Filosofía Moderna 3 en la Escuela de Sociología.	4
975	25	Literatura Clásica 3	Materia de Literatura Clásica 3 en la Escuela de Sociología.	5
976	25	Sociología 3	Materia de Sociología 3 en la Escuela de Sociología.	3
977	25	Antropología 3	Materia de Antropología 3 en la Escuela de Sociología.	4
978	25	Psicología 3	Materia de Psicología 3 en la Escuela de Sociología.	5
979	25	Historia Universal 4	Materia de Historia Universal 4 en la Escuela de Sociología.	3
980	25	Filosofía Moderna 4	Materia de Filosofía Moderna 4 en la Escuela de Sociología.	4
981	25	Literatura Clásica 4	Materia de Literatura Clásica 4 en la Escuela de Sociología.	5
982	25	Sociología 4	Materia de Sociología 4 en la Escuela de Sociología.	3
983	25	Antropología 4	Materia de Antropología 4 en la Escuela de Sociología.	4
984	25	Psicología 4	Materia de Psicología 4 en la Escuela de Sociología.	5
985	25	Historia Universal 5	Materia de Historia Universal 5 en la Escuela de Sociología.	3
986	25	Filosofía Moderna 5	Materia de Filosofía Moderna 5 en la Escuela de Sociología.	4
987	25	Literatura Clásica 5	Materia de Literatura Clásica 5 en la Escuela de Sociología.	5
988	25	Sociología 5	Materia de Sociología 5 en la Escuela de Sociología.	3
989	25	Antropología 5	Materia de Antropología 5 en la Escuela de Sociología.	4
990	25	Psicología 5	Materia de Psicología 5 en la Escuela de Sociología.	5
991	25	Historia Universal 6	Materia de Historia Universal 6 en la Escuela de Sociología.	3
992	25	Filosofía Moderna 6	Materia de Filosofía Moderna 6 en la Escuela de Sociología.	4
993	25	Literatura Clásica 6	Materia de Literatura Clásica 6 en la Escuela de Sociología.	5
994	25	Sociología 6	Materia de Sociología 6 en la Escuela de Sociología.	3
995	25	Antropología 6	Materia de Antropología 6 en la Escuela de Sociología.	4
996	25	Psicología 6	Materia de Psicología 6 en la Escuela de Sociología.	5
997	25	Historia Universal 7	Materia de Historia Universal 7 en la Escuela de Sociología.	3
998	25	Filosofía Moderna 7	Materia de Filosofía Moderna 7 en la Escuela de Sociología.	4
999	25	Literatura Clásica 7	Materia de Literatura Clásica 7 en la Escuela de Sociología.	5
1000	25	Sociología 7	Materia de Sociología 7 en la Escuela de Sociología.	3
1001	26	Historia Universal 1	Materia de Historia Universal 1 en la Escuela de Antropología.	3
1002	26	Filosofía Moderna 1	Materia de Filosofía Moderna 1 en la Escuela de Antropología.	4
1003	26	Literatura Clásica 1	Materia de Literatura Clásica 1 en la Escuela de Antropología.	5
1004	26	Sociología 1	Materia de Sociología 1 en la Escuela de Antropología.	3
1005	26	Antropología 1	Materia de Antropología 1 en la Escuela de Antropología.	4
1006	26	Psicología 1	Materia de Psicología 1 en la Escuela de Antropología.	5
1007	26	Historia Universal 2	Materia de Historia Universal 2 en la Escuela de Antropología.	3
1008	26	Filosofía Moderna 2	Materia de Filosofía Moderna 2 en la Escuela de Antropología.	4
1009	26	Literatura Clásica 2	Materia de Literatura Clásica 2 en la Escuela de Antropología.	5
1010	26	Sociología 2	Materia de Sociología 2 en la Escuela de Antropología.	3
1011	26	Antropología 2	Materia de Antropología 2 en la Escuela de Antropología.	4
1012	26	Psicología 2	Materia de Psicología 2 en la Escuela de Antropología.	5
1013	26	Historia Universal 3	Materia de Historia Universal 3 en la Escuela de Antropología.	3
1014	26	Filosofía Moderna 3	Materia de Filosofía Moderna 3 en la Escuela de Antropología.	4
1015	26	Literatura Clásica 3	Materia de Literatura Clásica 3 en la Escuela de Antropología.	5
1016	26	Sociología 3	Materia de Sociología 3 en la Escuela de Antropología.	3
1017	26	Antropología 3	Materia de Antropología 3 en la Escuela de Antropología.	4
1018	26	Psicología 3	Materia de Psicología 3 en la Escuela de Antropología.	5
1019	26	Historia Universal 4	Materia de Historia Universal 4 en la Escuela de Antropología.	3
1020	26	Filosofía Moderna 4	Materia de Filosofía Moderna 4 en la Escuela de Antropología.	4
1021	26	Literatura Clásica 4	Materia de Literatura Clásica 4 en la Escuela de Antropología.	5
1022	26	Sociología 4	Materia de Sociología 4 en la Escuela de Antropología.	3
1023	26	Antropología 4	Materia de Antropología 4 en la Escuela de Antropología.	4
1024	26	Psicología 4	Materia de Psicología 4 en la Escuela de Antropología.	5
1025	26	Historia Universal 5	Materia de Historia Universal 5 en la Escuela de Antropología.	3
1026	26	Filosofía Moderna 5	Materia de Filosofía Moderna 5 en la Escuela de Antropología.	4
1027	26	Literatura Clásica 5	Materia de Literatura Clásica 5 en la Escuela de Antropología.	5
1028	26	Sociología 5	Materia de Sociología 5 en la Escuela de Antropología.	3
1029	26	Antropología 5	Materia de Antropología 5 en la Escuela de Antropología.	4
1030	26	Psicología 5	Materia de Psicología 5 en la Escuela de Antropología.	5
1031	26	Historia Universal 6	Materia de Historia Universal 6 en la Escuela de Antropología.	3
1032	26	Filosofía Moderna 6	Materia de Filosofía Moderna 6 en la Escuela de Antropología.	4
1033	26	Literatura Clásica 6	Materia de Literatura Clásica 6 en la Escuela de Antropología.	5
1034	26	Sociología 6	Materia de Sociología 6 en la Escuela de Antropología.	3
1035	26	Antropología 6	Materia de Antropología 6 en la Escuela de Antropología.	4
1036	26	Psicología 6	Materia de Psicología 6 en la Escuela de Antropología.	5
1037	26	Historia Universal 7	Materia de Historia Universal 7 en la Escuela de Antropología.	3
1038	26	Filosofía Moderna 7	Materia de Filosofía Moderna 7 en la Escuela de Antropología.	4
1039	26	Literatura Clásica 7	Materia de Literatura Clásica 7 en la Escuela de Antropología.	5
1040	26	Sociología 7	Materia de Sociología 7 en la Escuela de Antropología.	3
1041	27	Análisis Matemático 1	Materia de Análisis Matemático 1 en la Escuela de Relaciones Internacionales.	3
1042	27	Álgebra Lineal 1	Materia de Álgebra Lineal 1 en la Escuela de Relaciones Internacionales.	4
1043	27	Geometría 1	Materia de Geometría 1 en la Escuela de Relaciones Internacionales.	5
1044	27	Física Moderna 1	Materia de Física Moderna 1 en la Escuela de Relaciones Internacionales.	3
1045	27	Química General 1	Materia de Química General 1 en la Escuela de Relaciones Internacionales.	4
1046	27	Estadística 1	Materia de Estadística 1 en la Escuela de Relaciones Internacionales.	5
1047	27	Análisis Matemático 2	Materia de Análisis Matemático 2 en la Escuela de Relaciones Internacionales.	3
1048	27	Álgebra Lineal 2	Materia de Álgebra Lineal 2 en la Escuela de Relaciones Internacionales.	4
1049	27	Geometría 2	Materia de Geometría 2 en la Escuela de Relaciones Internacionales.	5
1050	27	Física Moderna 2	Materia de Física Moderna 2 en la Escuela de Relaciones Internacionales.	3
1051	27	Química General 2	Materia de Química General 2 en la Escuela de Relaciones Internacionales.	4
1052	27	Estadística 2	Materia de Estadística 2 en la Escuela de Relaciones Internacionales.	5
1053	27	Análisis Matemático 3	Materia de Análisis Matemático 3 en la Escuela de Relaciones Internacionales.	3
1054	27	Álgebra Lineal 3	Materia de Álgebra Lineal 3 en la Escuela de Relaciones Internacionales.	4
1055	27	Geometría 3	Materia de Geometría 3 en la Escuela de Relaciones Internacionales.	5
1056	27	Física Moderna 3	Materia de Física Moderna 3 en la Escuela de Relaciones Internacionales.	3
1057	27	Química General 3	Materia de Química General 3 en la Escuela de Relaciones Internacionales.	4
1058	27	Estadística 3	Materia de Estadística 3 en la Escuela de Relaciones Internacionales.	5
1059	27	Análisis Matemático 4	Materia de Análisis Matemático 4 en la Escuela de Relaciones Internacionales.	3
1060	27	Álgebra Lineal 4	Materia de Álgebra Lineal 4 en la Escuela de Relaciones Internacionales.	4
1061	27	Geometría 4	Materia de Geometría 4 en la Escuela de Relaciones Internacionales.	5
1062	27	Física Moderna 4	Materia de Física Moderna 4 en la Escuela de Relaciones Internacionales.	3
1063	27	Química General 4	Materia de Química General 4 en la Escuela de Relaciones Internacionales.	4
1064	27	Estadística 4	Materia de Estadística 4 en la Escuela de Relaciones Internacionales.	5
1065	27	Análisis Matemático 5	Materia de Análisis Matemático 5 en la Escuela de Relaciones Internacionales.	3
1066	27	Álgebra Lineal 5	Materia de Álgebra Lineal 5 en la Escuela de Relaciones Internacionales.	4
1067	27	Geometría 5	Materia de Geometría 5 en la Escuela de Relaciones Internacionales.	5
1068	27	Física Moderna 5	Materia de Física Moderna 5 en la Escuela de Relaciones Internacionales.	3
1069	27	Química General 5	Materia de Química General 5 en la Escuela de Relaciones Internacionales.	4
1070	27	Estadística 5	Materia de Estadística 5 en la Escuela de Relaciones Internacionales.	5
1071	27	Análisis Matemático 6	Materia de Análisis Matemático 6 en la Escuela de Relaciones Internacionales.	3
1072	27	Álgebra Lineal 6	Materia de Álgebra Lineal 6 en la Escuela de Relaciones Internacionales.	4
1073	27	Geometría 6	Materia de Geometría 6 en la Escuela de Relaciones Internacionales.	5
1074	27	Física Moderna 6	Materia de Física Moderna 6 en la Escuela de Relaciones Internacionales.	3
1075	27	Química General 6	Materia de Química General 6 en la Escuela de Relaciones Internacionales.	4
1076	27	Estadística 6	Materia de Estadística 6 en la Escuela de Relaciones Internacionales.	5
1077	27	Análisis Matemático 7	Materia de Análisis Matemático 7 en la Escuela de Relaciones Internacionales.	3
1078	27	Álgebra Lineal 7	Materia de Álgebra Lineal 7 en la Escuela de Relaciones Internacionales.	4
1079	27	Geometría 7	Materia de Geometría 7 en la Escuela de Relaciones Internacionales.	5
1080	27	Física Moderna 7	Materia de Física Moderna 7 en la Escuela de Relaciones Internacionales.	3
1081	28	Diseño Urbano 1	Materia de Diseño Urbano 1 en la Escuela de Música.	3
1082	28	Historia del Arte 1	Materia de Historia del Arte 1 en la Escuela de Música.	4
1083	28	Patrimonio Arquitectónico 1	Materia de Patrimonio Arquitectónico 1 en la Escuela de Música.	5
1084	28	Dibujo Artístico 1	Materia de Dibujo Artístico 1 en la Escuela de Música.	3
1085	28	Composición Musical 1	Materia de Composición Musical 1 en la Escuela de Música.	4
1086	28	Diseño Urbano 2	Materia de Diseño Urbano 2 en la Escuela de Música.	5
1087	28	Historia del Arte 2	Materia de Historia del Arte 2 en la Escuela de Música.	3
1088	28	Patrimonio Arquitectónico 2	Materia de Patrimonio Arquitectónico 2 en la Escuela de Música.	4
1089	28	Dibujo Artístico 2	Materia de Dibujo Artístico 2 en la Escuela de Música.	5
1090	28	Composición Musical 2	Materia de Composición Musical 2 en la Escuela de Música.	3
1091	28	Diseño Urbano 3	Materia de Diseño Urbano 3 en la Escuela de Música.	4
1092	28	Historia del Arte 3	Materia de Historia del Arte 3 en la Escuela de Música.	5
1093	28	Patrimonio Arquitectónico 3	Materia de Patrimonio Arquitectónico 3 en la Escuela de Música.	3
1094	28	Dibujo Artístico 3	Materia de Dibujo Artístico 3 en la Escuela de Música.	4
1095	28	Composición Musical 3	Materia de Composición Musical 3 en la Escuela de Música.	5
1096	28	Diseño Urbano 4	Materia de Diseño Urbano 4 en la Escuela de Música.	3
1097	28	Historia del Arte 4	Materia de Historia del Arte 4 en la Escuela de Música.	4
1098	28	Patrimonio Arquitectónico 4	Materia de Patrimonio Arquitectónico 4 en la Escuela de Música.	5
1099	28	Dibujo Artístico 4	Materia de Dibujo Artístico 4 en la Escuela de Música.	3
1100	28	Composición Musical 4	Materia de Composición Musical 4 en la Escuela de Música.	4
1101	28	Diseño Urbano 5	Materia de Diseño Urbano 5 en la Escuela de Música.	5
1102	28	Historia del Arte 5	Materia de Historia del Arte 5 en la Escuela de Música.	3
1103	28	Patrimonio Arquitectónico 5	Materia de Patrimonio Arquitectónico 5 en la Escuela de Música.	4
1104	28	Dibujo Artístico 5	Materia de Dibujo Artístico 5 en la Escuela de Música.	5
1105	28	Composición Musical 5	Materia de Composición Musical 5 en la Escuela de Música.	3
1106	28	Diseño Urbano 6	Materia de Diseño Urbano 6 en la Escuela de Música.	4
1107	28	Historia del Arte 6	Materia de Historia del Arte 6 en la Escuela de Música.	5
1108	28	Patrimonio Arquitectónico 6	Materia de Patrimonio Arquitectónico 6 en la Escuela de Música.	3
1109	28	Dibujo Artístico 6	Materia de Dibujo Artístico 6 en la Escuela de Música.	4
1110	28	Composición Musical 6	Materia de Composición Musical 6 en la Escuela de Música.	5
1111	28	Diseño Urbano 7	Materia de Diseño Urbano 7 en la Escuela de Música.	3
1112	28	Historia del Arte 7	Materia de Historia del Arte 7 en la Escuela de Música.	4
1113	28	Patrimonio Arquitectónico 7	Materia de Patrimonio Arquitectónico 7 en la Escuela de Música.	5
1114	28	Dibujo Artístico 7	Materia de Dibujo Artístico 7 en la Escuela de Música.	3
1115	28	Composición Musical 7	Materia de Composición Musical 7 en la Escuela de Música.	4
1116	28	Diseño Urbano 8	Materia de Diseño Urbano 8 en la Escuela de Música.	5
1117	28	Historia del Arte 8	Materia de Historia del Arte 8 en la Escuela de Música.	3
1118	28	Patrimonio Arquitectónico 8	Materia de Patrimonio Arquitectónico 8 en la Escuela de Música.	4
1119	28	Dibujo Artístico 8	Materia de Dibujo Artístico 8 en la Escuela de Música.	5
1120	28	Composición Musical 8	Materia de Composición Musical 8 en la Escuela de Música.	3
1121	29	Diseño Urbano 1	Materia de Diseño Urbano 1 en la Escuela de Artes Visuales.	3
1122	29	Historia del Arte 1	Materia de Historia del Arte 1 en la Escuela de Artes Visuales.	4
1123	29	Patrimonio Arquitectónico 1	Materia de Patrimonio Arquitectónico 1 en la Escuela de Artes Visuales.	5
1124	29	Dibujo Artístico 1	Materia de Dibujo Artístico 1 en la Escuela de Artes Visuales.	3
1125	29	Composición Musical 1	Materia de Composición Musical 1 en la Escuela de Artes Visuales.	4
1126	29	Diseño Urbano 2	Materia de Diseño Urbano 2 en la Escuela de Artes Visuales.	5
1127	29	Historia del Arte 2	Materia de Historia del Arte 2 en la Escuela de Artes Visuales.	3
1128	29	Patrimonio Arquitectónico 2	Materia de Patrimonio Arquitectónico 2 en la Escuela de Artes Visuales.	4
1129	29	Dibujo Artístico 2	Materia de Dibujo Artístico 2 en la Escuela de Artes Visuales.	5
1130	29	Composición Musical 2	Materia de Composición Musical 2 en la Escuela de Artes Visuales.	3
1131	29	Diseño Urbano 3	Materia de Diseño Urbano 3 en la Escuela de Artes Visuales.	4
1132	29	Historia del Arte 3	Materia de Historia del Arte 3 en la Escuela de Artes Visuales.	5
1133	29	Patrimonio Arquitectónico 3	Materia de Patrimonio Arquitectónico 3 en la Escuela de Artes Visuales.	3
1134	29	Dibujo Artístico 3	Materia de Dibujo Artístico 3 en la Escuela de Artes Visuales.	4
1135	29	Composición Musical 3	Materia de Composición Musical 3 en la Escuela de Artes Visuales.	5
1136	29	Diseño Urbano 4	Materia de Diseño Urbano 4 en la Escuela de Artes Visuales.	3
1137	29	Historia del Arte 4	Materia de Historia del Arte 4 en la Escuela de Artes Visuales.	4
1138	29	Patrimonio Arquitectónico 4	Materia de Patrimonio Arquitectónico 4 en la Escuela de Artes Visuales.	5
1139	29	Dibujo Artístico 4	Materia de Dibujo Artístico 4 en la Escuela de Artes Visuales.	3
1140	29	Composición Musical 4	Materia de Composición Musical 4 en la Escuela de Artes Visuales.	4
1141	29	Diseño Urbano 5	Materia de Diseño Urbano 5 en la Escuela de Artes Visuales.	5
1142	29	Historia del Arte 5	Materia de Historia del Arte 5 en la Escuela de Artes Visuales.	3
1143	29	Patrimonio Arquitectónico 5	Materia de Patrimonio Arquitectónico 5 en la Escuela de Artes Visuales.	4
1144	29	Dibujo Artístico 5	Materia de Dibujo Artístico 5 en la Escuela de Artes Visuales.	5
1145	29	Composición Musical 5	Materia de Composición Musical 5 en la Escuela de Artes Visuales.	3
1146	29	Diseño Urbano 6	Materia de Diseño Urbano 6 en la Escuela de Artes Visuales.	4
1147	29	Historia del Arte 6	Materia de Historia del Arte 6 en la Escuela de Artes Visuales.	5
1148	29	Patrimonio Arquitectónico 6	Materia de Patrimonio Arquitectónico 6 en la Escuela de Artes Visuales.	3
1149	29	Dibujo Artístico 6	Materia de Dibujo Artístico 6 en la Escuela de Artes Visuales.	4
1150	29	Composición Musical 6	Materia de Composición Musical 6 en la Escuela de Artes Visuales.	5
1151	29	Diseño Urbano 7	Materia de Diseño Urbano 7 en la Escuela de Artes Visuales.	3
1152	29	Historia del Arte 7	Materia de Historia del Arte 7 en la Escuela de Artes Visuales.	4
1153	29	Patrimonio Arquitectónico 7	Materia de Patrimonio Arquitectónico 7 en la Escuela de Artes Visuales.	5
1154	29	Dibujo Artístico 7	Materia de Dibujo Artístico 7 en la Escuela de Artes Visuales.	3
1155	29	Composición Musical 7	Materia de Composición Musical 7 en la Escuela de Artes Visuales.	4
1156	29	Diseño Urbano 8	Materia de Diseño Urbano 8 en la Escuela de Artes Visuales.	5
1157	29	Historia del Arte 8	Materia de Historia del Arte 8 en la Escuela de Artes Visuales.	3
1158	29	Patrimonio Arquitectónico 8	Materia de Patrimonio Arquitectónico 8 en la Escuela de Artes Visuales.	4
1159	29	Dibujo Artístico 8	Materia de Dibujo Artístico 8 en la Escuela de Artes Visuales.	5
1160	29	Composición Musical 8	Materia de Composición Musical 8 en la Escuela de Artes Visuales.	3
1161	30	Diseño Urbano 1	Materia de Diseño Urbano 1 en la Escuela de Cine y Teatro.	3
1162	30	Historia del Arte 1	Materia de Historia del Arte 1 en la Escuela de Cine y Teatro.	4
1163	30	Patrimonio Arquitectónico 1	Materia de Patrimonio Arquitectónico 1 en la Escuela de Cine y Teatro.	5
1164	30	Dibujo Artístico 1	Materia de Dibujo Artístico 1 en la Escuela de Cine y Teatro.	3
1165	30	Composición Musical 1	Materia de Composición Musical 1 en la Escuela de Cine y Teatro.	4
1166	30	Diseño Urbano 2	Materia de Diseño Urbano 2 en la Escuela de Cine y Teatro.	5
1167	30	Historia del Arte 2	Materia de Historia del Arte 2 en la Escuela de Cine y Teatro.	3
1168	30	Patrimonio Arquitectónico 2	Materia de Patrimonio Arquitectónico 2 en la Escuela de Cine y Teatro.	4
1169	30	Dibujo Artístico 2	Materia de Dibujo Artístico 2 en la Escuela de Cine y Teatro.	5
1170	30	Composición Musical 2	Materia de Composición Musical 2 en la Escuela de Cine y Teatro.	3
1171	30	Diseño Urbano 3	Materia de Diseño Urbano 3 en la Escuela de Cine y Teatro.	4
1172	30	Historia del Arte 3	Materia de Historia del Arte 3 en la Escuela de Cine y Teatro.	5
1173	30	Patrimonio Arquitectónico 3	Materia de Patrimonio Arquitectónico 3 en la Escuela de Cine y Teatro.	3
1174	30	Dibujo Artístico 3	Materia de Dibujo Artístico 3 en la Escuela de Cine y Teatro.	4
1175	30	Composición Musical 3	Materia de Composición Musical 3 en la Escuela de Cine y Teatro.	5
1176	30	Diseño Urbano 4	Materia de Diseño Urbano 4 en la Escuela de Cine y Teatro.	3
1177	30	Historia del Arte 4	Materia de Historia del Arte 4 en la Escuela de Cine y Teatro.	4
1178	30	Patrimonio Arquitectónico 4	Materia de Patrimonio Arquitectónico 4 en la Escuela de Cine y Teatro.	5
1179	30	Dibujo Artístico 4	Materia de Dibujo Artístico 4 en la Escuela de Cine y Teatro.	3
1180	30	Composición Musical 4	Materia de Composición Musical 4 en la Escuela de Cine y Teatro.	4
1181	30	Diseño Urbano 5	Materia de Diseño Urbano 5 en la Escuela de Cine y Teatro.	5
1182	30	Historia del Arte 5	Materia de Historia del Arte 5 en la Escuela de Cine y Teatro.	3
1183	30	Patrimonio Arquitectónico 5	Materia de Patrimonio Arquitectónico 5 en la Escuela de Cine y Teatro.	4
1184	30	Dibujo Artístico 5	Materia de Dibujo Artístico 5 en la Escuela de Cine y Teatro.	5
1185	30	Composición Musical 5	Materia de Composición Musical 5 en la Escuela de Cine y Teatro.	3
1186	30	Diseño Urbano 6	Materia de Diseño Urbano 6 en la Escuela de Cine y Teatro.	4
1187	30	Historia del Arte 6	Materia de Historia del Arte 6 en la Escuela de Cine y Teatro.	5
1188	30	Patrimonio Arquitectónico 6	Materia de Patrimonio Arquitectónico 6 en la Escuela de Cine y Teatro.	3
1189	30	Dibujo Artístico 6	Materia de Dibujo Artístico 6 en la Escuela de Cine y Teatro.	4
1190	30	Composición Musical 6	Materia de Composición Musical 6 en la Escuela de Cine y Teatro.	5
1191	30	Diseño Urbano 7	Materia de Diseño Urbano 7 en la Escuela de Cine y Teatro.	3
1192	30	Historia del Arte 7	Materia de Historia del Arte 7 en la Escuela de Cine y Teatro.	4
1193	30	Patrimonio Arquitectónico 7	Materia de Patrimonio Arquitectónico 7 en la Escuela de Cine y Teatro.	5
1194	30	Dibujo Artístico 7	Materia de Dibujo Artístico 7 en la Escuela de Cine y Teatro.	3
1195	30	Composición Musical 7	Materia de Composición Musical 7 en la Escuela de Cine y Teatro.	4
1196	30	Diseño Urbano 8	Materia de Diseño Urbano 8 en la Escuela de Cine y Teatro.	5
1197	30	Historia del Arte 8	Materia de Historia del Arte 8 en la Escuela de Cine y Teatro.	3
1198	30	Patrimonio Arquitectónico 8	Materia de Patrimonio Arquitectónico 8 en la Escuela de Cine y Teatro.	4
1199	30	Dibujo Artístico 8	Materia de Dibujo Artístico 8 en la Escuela de Cine y Teatro.	5
1200	30	Composición Musical 8	Materia de Composición Musical 8 en la Escuela de Cine y Teatro.	3
\.


--
-- Data for Name: semestres; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.semestres (id_semestre, semestre, anio, fecha_inicio, fecha_fin, activo) FROM stdin;
1	2012-1	2012	2012-01-15	2012-06-13	f
2	2012-2	2012	2012-07-15	2012-12-12	f
3	2013-1	2013	2013-01-15	2013-06-14	f
4	2013-2	2013	2013-07-15	2013-12-12	f
5	2014-1	2014	2014-01-15	2014-06-14	f
6	2014-2	2014	2014-07-15	2014-12-12	f
7	2015-1	2015	2015-01-15	2015-06-14	f
8	2015-2	2015	2015-07-15	2015-12-12	f
9	2016-1	2016	2016-01-15	2016-06-13	f
10	2016-2	2016	2016-07-15	2016-12-12	f
11	2017-1	2017	2017-01-15	2017-06-14	f
12	2017-2	2017	2017-07-15	2017-12-12	f
13	2018-1	2018	2018-01-15	2018-06-14	f
14	2018-2	2018	2018-07-15	2018-12-12	f
15	2019-1	2019	2019-01-15	2019-06-14	f
16	2019-2	2019	2019-07-15	2019-12-12	f
17	2020-1	2020	2020-01-15	2020-06-13	f
18	2020-2	2020	2020-07-15	2020-12-12	f
19	2021-1	2021	2021-01-15	2021-06-14	f
20	2021-2	2021	2021-07-15	2021-12-12	f
21	2022-1	2022	2022-01-15	2022-06-14	f
22	2022-2	2022	2022-07-15	2022-12-12	f
23	2023-1	2023	2023-01-15	2023-06-14	f
24	2023-2	2023	2023-07-15	2023-12-12	f
25	2024-1	2024	2024-01-15	2024-06-13	f
26	2024-2	2024	2024-07-15	2024-12-12	f
\.


--
-- Data for Name: universidad; Type: TABLE DATA; Schema: public; Owner: ObGkVgCpKc
--

COPY public.universidad (id_universidad, nombre, direccion, telefono, correo, anio_fundacion, logo_url) FROM stdin;
1	Universidad Tecnológica del Futuro	Avenida del Conocimiento 123, Ciudad Innovación	+1 555-1234-567	contacto@utf.edu	1985	https://www.ejemplo.com/logo_utf.png
\.


--
-- Name: autoridad_entidad_id_relacion_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.autoridad_entidad_id_relacion_seq', 93, true);


--
-- Name: autoridades_id_autoridad_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.autoridades_id_autoridad_seq', 93, true);


--
-- Name: calificaciones_id_calificacion_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.calificaciones_id_calificacion_seq', 1, false);


--
-- Name: escuelas_id_escuela_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.escuelas_id_escuela_seq', 32, true);


--
-- Name: estudiantes_id_estudiante_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.estudiantes_id_estudiante_seq', 101, true);


--
-- Name: facultades_id_facultad_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.facultades_id_facultad_seq', 10, true);


--
-- Name: inscripciones_id_inscripcion_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.inscripciones_id_inscripcion_seq', 1, false);


--
-- Name: materias_id_materia_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.materias_id_materia_seq', 30, true);


--
-- Name: semestres_id_semestre_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.semestres_id_semestre_seq', 1, false);


--
-- Name: universidad_id_universidad_seq; Type: SEQUENCE SET; Schema: public; Owner: ObGkVgCpKc
--

SELECT pg_catalog.setval('public.universidad_id_universidad_seq', 1, true);


--
-- Name: autoridad_entidad autoridad_entidad_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.autoridad_entidad
    ADD CONSTRAINT autoridad_entidad_pkey PRIMARY KEY (id_relacion);


--
-- Name: autoridades autoridades_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.autoridades
    ADD CONSTRAINT autoridades_pkey PRIMARY KEY (id_autoridad);


--
-- Name: calificaciones calificaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.calificaciones
    ADD CONSTRAINT calificaciones_pkey PRIMARY KEY (id_calificacion);


--
-- Name: escuelas escuelas_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.escuelas
    ADD CONSTRAINT escuelas_pkey PRIMARY KEY (id_escuela);


--
-- Name: estudiantes estudiantes_correo_key; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.estudiantes
    ADD CONSTRAINT estudiantes_correo_key UNIQUE (correo);


--
-- Name: estudiantes estudiantes_matricula_key; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.estudiantes
    ADD CONSTRAINT estudiantes_matricula_key UNIQUE (matricula);


--
-- Name: estudiantes estudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.estudiantes
    ADD CONSTRAINT estudiantes_pkey PRIMARY KEY (id_estudiante);


--
-- Name: estudiantes estudiantes_unique_identificacion; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.estudiantes
    ADD CONSTRAINT estudiantes_unique_identificacion UNIQUE (identificacion);


--
-- Name: facultades facultades_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.facultades
    ADD CONSTRAINT facultades_pkey PRIMARY KEY (id_facultad);


--
-- Name: inscripciones inscripciones_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.inscripciones
    ADD CONSTRAINT inscripciones_pkey PRIMARY KEY (id_inscripcion);


--
-- Name: materias materias_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.materias
    ADD CONSTRAINT materias_pkey PRIMARY KEY (id_materia);


--
-- Name: semestres semestres_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.semestres
    ADD CONSTRAINT semestres_pkey PRIMARY KEY (id_semestre);


--
-- Name: inscripciones unique_inscripcion; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.inscripciones
    ADD CONSTRAINT unique_inscripcion UNIQUE (id_estudiante, id_materia, id_semestre);


--
-- Name: universidad universidad_pkey; Type: CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.universidad
    ADD CONSTRAINT universidad_pkey PRIMARY KEY (id_universidad);


--
-- Name: autoridad_entidad autoridad_entidad_id_autoridad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.autoridad_entidad
    ADD CONSTRAINT autoridad_entidad_id_autoridad_fkey FOREIGN KEY (id_autoridad) REFERENCES public.autoridades(id_autoridad) ON DELETE CASCADE;


--
-- Name: autoridad_entidad autoridad_entidad_id_escuela_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.autoridad_entidad
    ADD CONSTRAINT autoridad_entidad_id_escuela_fkey FOREIGN KEY (id_escuela) REFERENCES public.escuelas(id_escuela) ON DELETE CASCADE;


--
-- Name: autoridad_entidad autoridad_entidad_id_facultad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.autoridad_entidad
    ADD CONSTRAINT autoridad_entidad_id_facultad_fkey FOREIGN KEY (id_facultad) REFERENCES public.facultades(id_facultad) ON DELETE CASCADE;


--
-- Name: autoridad_entidad autoridad_entidad_id_universidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.autoridad_entidad
    ADD CONSTRAINT autoridad_entidad_id_universidad_fkey FOREIGN KEY (id_universidad) REFERENCES public.universidad(id_universidad) ON DELETE CASCADE;


--
-- Name: calificaciones calificaciones_id_inscripcion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.calificaciones
    ADD CONSTRAINT calificaciones_id_inscripcion_fkey FOREIGN KEY (id_inscripcion) REFERENCES public.inscripciones(id_inscripcion) ON DELETE CASCADE;


--
-- Name: escuelas escuelas_id_facultad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.escuelas
    ADD CONSTRAINT escuelas_id_facultad_fkey FOREIGN KEY (id_facultad) REFERENCES public.facultades(id_facultad);


--
-- Name: facultades fk_facultad_universidad; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.facultades
    ADD CONSTRAINT fk_facultad_universidad FOREIGN KEY (id_universidad) REFERENCES public.universidad(id_universidad) ON DELETE CASCADE;


--
-- Name: inscripciones inscripciones_id_estudiante_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.inscripciones
    ADD CONSTRAINT inscripciones_id_estudiante_fkey FOREIGN KEY (id_estudiante) REFERENCES public.estudiantes(id_estudiante) ON DELETE CASCADE;


--
-- Name: inscripciones inscripciones_id_materia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.inscripciones
    ADD CONSTRAINT inscripciones_id_materia_fkey FOREIGN KEY (id_materia) REFERENCES public.materias(id_materia) ON DELETE CASCADE;


--
-- Name: inscripciones inscripciones_id_semestre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.inscripciones
    ADD CONSTRAINT inscripciones_id_semestre_fkey FOREIGN KEY (id_semestre) REFERENCES public.semestres(id_semestre) ON DELETE CASCADE;


--
-- Name: materias materias_id_escuela_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ObGkVgCpKc
--

ALTER TABLE ONLY public.materias
    ADD CONSTRAINT materias_id_escuela_fkey FOREIGN KEY (id_escuela) REFERENCES public.escuelas(id_escuela) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

